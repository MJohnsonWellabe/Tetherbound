# Net smoke run f48-actual-2534

Scene: title
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2545 exited=true unexpected_exit=false
- peer 1 (client) pid=2546 exited=true unexpected_exit=false

FAILURES:
- #19 peer 0 f48_assert_altar_build -> FAIL -- Actual paid Altar bootstrap; no earned campaign credit. Full original before carrier differs from actual host writer edge; memory: full original after carrier differs at actual owner BOOL-save edge; disk: full original after carrier differs at actual owner BOOL-save edge; Latest disk differs from co
