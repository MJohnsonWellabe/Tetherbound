# Net smoke run f48-actual-2265

Scene: title
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2279 exited=true unexpected_exit=false
- peer 1 (client) pid=2280 exited=true unexpected_exit=false

FAILURES:
- #20 peer 1 f48_assert -> FAIL -- Exact durable assertions: memory: replay changed inventory; memory: replay changed redesign_character; memory: replay changed satchel_escrow; disk: replay changed inventory; disk: replay changed party; disk: replay changed redesign_character; disk: replay changed satchel_escrow
