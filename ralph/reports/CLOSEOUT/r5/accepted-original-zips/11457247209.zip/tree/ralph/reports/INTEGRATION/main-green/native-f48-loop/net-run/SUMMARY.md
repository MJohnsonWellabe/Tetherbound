# Net smoke run f48-actual-2261

Scene: title
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2272 exited=true unexpected_exit=false
- peer 1 (client) pid=2273 exited=true unexpected_exit=false

FAILURES:
- #21 peer 0 f48_assert_snapshot (Read actual memory/disk carriers before any capture autosave) -> FAIL -- Read-only explicit input source actual_owner_BOOL_edge_full_canonical_after_and_accepted_ACK: memory: complete canonical carrier differs from actual immutable row.after at owner BOOL-save edge; disk: complete canonical carrier differs from actual immutable row.after at owner BOOL-save edge
