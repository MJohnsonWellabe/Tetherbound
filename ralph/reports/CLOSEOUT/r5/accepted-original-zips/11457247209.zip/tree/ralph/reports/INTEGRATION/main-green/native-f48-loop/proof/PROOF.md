# Two-peer proof: F48 genuine before-operation input producer

**Verdict: FAIL** (exit 1)

Scenario: `/home/runner/work/Tetherbound/Tetherbound/ralph/reports/INTEGRATION/main-green/native-f48-loop/coordinator-home/godot/app_userdata/Tetherbound/f48-prepare_inputs-scenario.json`  
Run: `f48-actual-2261`  
Rendered: no (headless)

Original full loop/oracles plus detached actual input snapshots; all24cut tests still required. DISCLOSED initial mechanics fixture: actual retained v28 characters/owned cards; added initial material stock, paid station records and starting pose. No earned campaign claim. Native producer, routes and terrain validation OPEN. See fixture-manifest.json. Original native shared_boss saves retained by the prior integration session. These are disclosed mechanics starter-level-9 sources, not earned redesigned campaign checkpoints. No new character, UID, level, receipt or outcome is synthesized. The existing fixture producer separately discloses initial stock, physical setup and legacy pre-boss flags. Explicit pre-boss legacy mechanics gates removed only in detached initial fixture; original rewards and all personal data retained. INITIAL Kitchen Spice rack attachment is a disclosed mechanics station fixture, not an earned upgrade/payment/transaction; real Master recipe, cooking and feed still required. One initial Basic Orb per actual character is disclosed stock for the real catch producer, never a caught companion or provenance grant. Explicit source-derived INPUT producer routes: actor/owned-ally placement, paused real Alpha RNG, real announced boss join, self-HP aid and ally placement, enemy HP ceiling0. No ordinary survival/balance/campaign credit. Captured source and every actual journal/owner write/ACK must be native; NOT a complete CI bundle.

## Failures

- #21 peer 0 f48_assert_snapshot (Read actual memory/disk carriers before any capture autosave) -> FAIL -- Read-only explicit input source actual_owner_BOOL_edge_full_canonical_after_and_accepted_ACK: memory: complete canonical carrier differs from actual immutable row.after at owner BOOL-save edge; disk: complete canonical carrier differs from actual immutable row.after at owner BOOL-save edge

| # | Peer | Step | Expected | Verdict | Detail |
|---|---|---|---|---|---|
| 1 | 0 | f48_watch_owner_saves — Arm actual saved-edge observation before production admission; no save or ACK | PASS | PASS | Read-only producer actual owner BOOL-save observer |
| 1 | 1 | f48_watch_owner_saves — Arm actual saved-edge observation before production admission; no save or ACK | PASS | PASS | Read-only producer actual owner BOOL-save observer |
| 2 | 0 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 2 | 1 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 3 | 0 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | loaded peer-0 (captured directory (split path)) as slot 0; realm 'meadows' booted as 'world'; character 'character-626300bee616b52bfa1d40ab32fb776a' |
| 4 | 1 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | Restored only authentic portable character through production owner; no world or locator copied |
| 5 | 0 | host | PASS | PASS | hosting udp/28881 as peer 1 |
| 6 | 1 | production_join | PASS | PASS | title returning entry built 'MeadowsPlayground' first, then JoinDriver joined 127.0.0.1:28881 as peer 1176463999 after 52 frames |
| 7 | 0 | expect_peers | PASS | PASS | registry reports 2 peer(s) after 0 frames (0.0 s) |
| 7 | 1 | expect_peers | PASS | PASS | registry reports 2 peer(s) after 0 frames (0.0 s) |
| 8 | 0 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 8 | 1 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 9 | 0 | f48_watch_altar_save — Read-only actual transaction owner BOOL-save edge; no care exclusions or state writes | PASS | PASS | Read-only exact host/owner save edges armed before original paid build input |
| 10 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_open' x1 |
| 11 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 30 physics frames |
| 12 | 0 | f48_button — bootstrap_altar: ordinary input | PASS | PASS | pressed 'ui_accept' x1 |
| 13 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 15 physics frames |
| 14 | 0 | f48_build_cell — bootstrap_altar: ordinary input | PASS | PASS | pressed 'ui_accept' x1 |
| 15 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 30 physics frames |
| 16 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_place' x1 |
| 17 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 180 physics frames |
| 18 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_cancel' x1 |
| 19 | 0 | f48_assert_altar_build | PASS | PASS | Actual paid Altar bootstrap; no earned campaign credit.  |
| 20 | 1 | f48_assert | PASS | PASS | Exact durable assertions: passed |
| 21 | 0 | f48_assert_snapshot — Read actual memory/disk carriers before any capture autosave | PASS | FAIL **(unexpected)** | Read-only explicit input source actual_owner_BOOL_edge_full_canonical_after_and_accepted_ACK: memory: complete canonical carrier differs from actual immutable row.after at owner BOOL-save edge; disk: complete canonical carrier differs from actual immutable row.after at owner BOOL-save edge |

## Captured files

- `f48-altar-save-edges/character-626300bee616b52bfa1d40ab32fb776a/after_host_write_before_delivery.json`
- `f48-altar-save-edges/character-626300bee616b52bfa1d40ab32fb776a/after_owner_write_before_ack.json`
- `f48-observations/f48_assert-2273-145249089.json`
- `f48-observations/f48_assert_altar_build-2272-144853304.json`
- `f48-observations/f48_assert_snapshot-2272-145557771.json`
- `f48-owner-saves/character-626300bee616b52bfa1d40ab32fb776a/owner-26b0e16332ffa0e111e9d15628f017391b258c4b697f3af9663de64afd0e7b1f-1.json`
- `f48-owner-saves/character-626300bee616b52bfa1d40ab32fb776a/owner-ff890e90da64674535fd44676cc4caef7db77f82d32345ee3b773c7c713ec2e6-2.json`
- `f48-owner-saves/character-a79c7bee9128c2ef03d266ce0352c666/owner-874d75f9c231b69c1a2a1c8fd9f43bab962ce0a8e5a9c441e225f72dee134e0a-1.json`
- `f48-owner-saves/character-a79c7bee9128c2ef03d266ce0352c666/owner-874d75f9c231b69c1a2a1c8fd9f43bab962ce0a8e5a9c441e225f72dee134e0a-2.json`
- `f48-owner-saves/character-a79c7bee9128c2ef03d266ce0352c666/owner-fd04f55c49f375b61721ed4ec2a2f428301a16ccde845c14dff26c5abd8d3e2b-3.json`
- `f48-passive/actual-2272.jsonl`
- `f48-passive/actual-2273.jsonl`
- `f48-witnesses/character-626300bee616b52bfa1d40ab32fb776a/initial-bootstrap.json`
- `f48-witnesses/character-a79c7bee9128c2ef03d266ce0352c666/initial-bootstrap.json`
