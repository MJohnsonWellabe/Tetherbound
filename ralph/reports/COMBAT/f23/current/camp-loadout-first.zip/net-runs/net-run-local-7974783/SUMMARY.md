# Net smoke run local-7974783

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2550 exited=true unexpected_exit=false
- peer 1 (client) pid=2551 exited=true unexpected_exit=false

FAILURES:
- guest equips Quake Ring at its camp (camp loadout panel did not open)
- camp equip changes the guest utility and saves its original revision
- host admits the guest's saved loadout before reload
- guest character reload preserves every loadout field and original receipt
- host re-admits the guest's persisted loadout
- guest rejoin preserves the saved loadout and receipt
