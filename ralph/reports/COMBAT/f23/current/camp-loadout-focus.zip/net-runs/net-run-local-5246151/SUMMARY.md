# Net smoke run local-5246151

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2254 exited=true unexpected_exit=false
- peer 1 (client) pid=2255 exited=true unexpected_exit=false

ALL CHECKS PASSED
