# Net smoke run local-4502218

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2295 exited=true unexpected_exit=false
- peer 1 (client) pid=2296 exited=true unexpected_exit=false

FAILURES:
- peer 0 f20_talk: ["natural Grandpa completion receives durable personal acknowledgement"]
