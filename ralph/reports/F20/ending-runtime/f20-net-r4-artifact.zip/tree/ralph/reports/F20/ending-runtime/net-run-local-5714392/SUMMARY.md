# Net smoke run local-5714392

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2400 exited=false unexpected_exit=false
- peer 1 (client) pid=2401 exited=true unexpected_exit=false

FAILURES:
- peer 0 f20_talk: no verdict
