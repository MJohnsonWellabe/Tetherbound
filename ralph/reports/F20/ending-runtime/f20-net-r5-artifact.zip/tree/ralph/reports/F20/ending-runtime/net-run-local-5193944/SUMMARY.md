# Net smoke run local-5193944

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2461 exited=true unexpected_exit=false
- peer 1 (client) pid=2462 exited=false unexpected_exit=false

FATAL: ERROR: smoke budget exceeded
