# Net smoke run local-5562104

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2448 exited=true unexpected_exit=false
- peer 1 (client) pid=2449 exited=false unexpected_exit=false

FAILURES:
- peer 1 f20_return: no verdict
