# Net smoke run local-5498060

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2466 exited=false unexpected_exit=false
- peer 1 (client) pid=2467 exited=true unexpected_exit=false

FAILURES:
- peer 0 f20_talk: no verdict
