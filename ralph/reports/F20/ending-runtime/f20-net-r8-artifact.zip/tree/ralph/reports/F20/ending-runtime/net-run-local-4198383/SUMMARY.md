# Net smoke run local-4198383

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2292 exited=true unexpected_exit=false
- peer 1 (client) pid=2293 exited=false unexpected_exit=false

FAILURES:
- peer 1 f20_return: no verdict
