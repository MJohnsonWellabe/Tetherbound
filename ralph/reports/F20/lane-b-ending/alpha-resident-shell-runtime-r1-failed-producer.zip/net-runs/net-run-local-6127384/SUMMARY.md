# Net smoke run local-6127384

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2476 exited=true unexpected_exit=false
- peer 1 (client) pid=2477 exited=true unexpected_exit=false

FAILURES:
- Resolver records Tidecoil locally: Named Tidecoil body never became resident
- Original client resolver observed the actual named Tidecoil body
- Named residency wait observed the canonical generation before the original terminal fixture
- Resolution reaches the other peer's world store: flag water_named_deep_watch_tidecoil_resolved (world) never set within 600 frames
- Host world truth holds the Tidecoil resolution
- Client claims the unlocked cache through host authority: Resolved cache never streamed in on this peer {  }
- Host records exactly one durable character receipt
- Client mirror holds the resolution
