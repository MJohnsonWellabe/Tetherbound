# Net smoke run local-4538431

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2269 exited=true unexpected_exit=false
- peer 1 (client) pid=2270 exited=true unexpected_exit=false

ALL CHECKS PASSED
