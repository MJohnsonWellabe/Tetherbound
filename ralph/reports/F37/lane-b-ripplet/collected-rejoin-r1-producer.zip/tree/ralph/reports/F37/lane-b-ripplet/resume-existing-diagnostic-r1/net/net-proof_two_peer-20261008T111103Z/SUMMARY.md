# Net smoke run net-20261008T111103Z-2535

Scene: water
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2562 exited=true unexpected_exit=false
- peer 1 (client) pid=2563 exited=true unexpected_exit=false

ALL CHECKS PASSED
