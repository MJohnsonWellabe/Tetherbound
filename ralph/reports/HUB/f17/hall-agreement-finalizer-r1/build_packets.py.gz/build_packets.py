"""Prepare immutable ignored inputs/source receipts; never execute finalize.py."""
from pathlib import Path
import json, hashlib, difflib, re, datetime

ROOT=Path('D:/tetherbound/redesign-hub')
R4=ROOT/'.tmp/hall-agreement-r4'
R5=ROOT/'.tmp/hall-agreement-r5'
OUT=ROOT/'.tmp/hall-agreement-finalizer-r1'
RUN=Path('D:/tetherbound/hall-agreement-native-r4')
HEAD='784b5cee71a4ba42b7fd6b5b3b39bea76b67910e'
SOURCE='0485c7b7337ad2a239e9f591ebf9acafac7c32082e28bd43603e1e8868f6d390'
PEER='1446618f362bc9a0f020cf542837692e08c4ccf1b8ea0c41277f2a73f3c38451'
SOURCE_PATH='.tmp/hall-agreement-r4/proposal/tests/smoke_net_crossing_hall_agreement.gd'
def sha(b): return hashlib.sha256(b).hexdigest()
def utf(b): return b.decode('utf-8',errors='strict')
def get(p):
    b=p.read_bytes(); assert b==p.read_bytes(),('input drift',str(p)); return b
def put(base,relative,b):
    p=base/relative; assert p.resolve().is_relative_to(base.resolve())
    p.parent.mkdir(parents=True,exist_ok=True); assert not p.exists(),('preserve existing packet file',str(p))
    p.write_bytes(b)
def jout(base,relative,x): put(base,relative,(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode('utf-8'))
def bind(origin,relative,label,wanted=None):
    b=get(origin)
    if wanted is not None: assert sha(b)==wanted,('input hash mismatch',str(origin))
    put(OUT,relative,b)
    return {'label':label,'origin':str(origin),'snapshot':relative,'sha256':sha(b),'bytes':len(b)}

opening=ROOT/'.tmp/opening-contact-fix-r1/freeze.json'
opening_seal=get(opening); opening_before=json.loads(utf(opening_seal))
opening_files={e['path']:get(opening.parent/e['path']) for e in opening_before['files']}
for e in opening_before['files']: assert sha(opening_files[e['path']])==e['sha256']
assessment_dir=R4/'independent/runtime-r4/reuse-assessment'
assessment=get(assessment_dir/'review.json'); aj=json.loads(utf(assessment))
assert aj['sealed'] and aj['source']==HEAD and aj['verdict'].startswith('REUSE ELIGIBLE for separate literal F17#5 verdict')
prior=json.loads(utf(get(R4/'independent/runtime-r4/review.json')))
receipt_b=get(RUN/'receipt.json'); receipt=json.loads(utf(receipt_b))
assert sha(receipt_b)==prior['sha256']['raw/receipt.json']
assert receipt['source']==receipt['head_after']==HEAD and receipt['same_source']
assert receipt['source_before']==receipt['source_after'] and len(receipt['source_before'])==37
source=get(ROOT/SOURCE_PATH); assert sha(source)==SOURCE
text=utf(source); assert '\r' not in text
literal=text.split('const PEER_SOURCE := """',1)[1].split('"""',1)[0].encode('utf-8')
assert sha(literal)==PEER
old='\t\tif FileAccess.file_exists(path):\n\t\t\tout[path] = FileAccess.get_sha256(path)'
new='\t\tif not out.has(path) and FileAccess.file_exists(path):\n\t\t\tout[path] = FileAccess.get_sha256(path)'
assert text.count(old)==1
after=text.replace(old,new,1).encode('utf-8')
assert utf(after).replace(new,old,1).encode('utf-8')==source
owned='tests/smoke_net_crossing_hall_agreement.gd'
put(R5,'originals/'+owned,source); put(R5,'proposal/'+owned,after)
patch=''.join(difflib.unified_diff(text.splitlines(keepends=True),utf(after).splitlines(keepends=True),
    fromfile='a/'+owned,tofile='b/'+owned,n=3)).encode('utf-8')
put(R5,'r5-hash-dedup.patch',patch)
# Check exact unified patch context/reconstruction without a Git/Godot invocation.
old_lines=text.splitlines(keepends=True); out=[]; cursor=0; diff=utf(patch).splitlines(keepends=True); i=2
while i<len(diff):
    m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i]); assert m
    start=int(m[1])-1; out.extend(old_lines[cursor:start]); cursor=start; i+=1
    while i<len(diff) and not diff[i].startswith('@@ '):
        line=diff[i]; tag=line[0]; content=line[1:]
        if tag in ' -': assert old_lines[cursor]==content; cursor+=1
        if tag in ' +': out.append(content)
        i+=1
out.extend(old_lines[cursor:]); assert ''.join(out).encode('utf-8')==after
manifest={'schema':'hall-r4-metadata-finalizer-v1','source_head':HEAD,'r4_sha256':SOURCE,'peer_sha256':PEER,
    'worktree':str(ROOT),'original_run':str(RUN),'engine_sha256':receipt['engine_sha256'],
    'outputs':{},'sources':{},'resource_sha256':{},
    'execution_state':'UNEXECUTED PROPOSAL: ROOT + independent source gate required before finalize.py',
    'original_smoke_verdict':'FAIL/native2/budget; four host ENet errors unresolved; never relabel whole smoke',
    'original_source_before':receipt['source_before'],'original_source_after':receipt['source_after']}
manifest['outputs']['receipt.json']=bind(RUN/'receipt.json','inputs/original/receipt.json','R4receipt',sha(receipt_b))
for path,wanted in sorted(receipt['output_sha256'].items()):
    relative=path.replace('\\','/')
    entry=bind(RUN/relative,'inputs/original/'+relative,'R4output '+relative,wanted)
    manifest['outputs'][relative]=entry
hall=json.loads(utf((OUT/'inputs/original/net/HALL_AGREEMENT.json').read_bytes()))
net=json.loads(utf((OUT/'inputs/original/net/NET_RUN.json').read_bytes()))
assert hall['source_sha256']==SOURCE and hall['peer_source_sha256']==PEER and hall['exit_code']==2
assert len(hall['producer_resource_hashes'])==75 and len(hall['dependencies'])==36
deps={p:h for p,h in receipt['source_before'].items() if p!=SOURCE_PATH}
assert deps==hall['dependencies']
for path,wanted in sorted(receipt['source_before'].items()):
    manifest['sources'][path]=bind(ROOT/path,'inputs/source/'+path,'R4source '+path,wanted)
peer_path=hall['peer_runtime_path']; assert peer_path.startswith('res://')
manifest['peer_extension']=bind(ROOT/peer_path[6:],'inputs/peer-extension.gd','actual generated peer14466',PEER)
assert (OUT/'inputs/peer-extension.gd').read_bytes()==literal
manifest['r5_source']=bind(R5/'proposal'/owned,'inputs/r5/'+owned,'unexecuted R5 exact dedup source',sha(after))
manifest['reuse_assessment']=bind(assessment_dir/'review.json','inputs/assessment/review.json','sealed independent reuse assessment',sha(assessment))
for name in ('strict-review.txt','prior-runtime-FAIL.json'):
    bind(assessment_dir/name,'inputs/assessment/'+name,'preserved assessment '+name)
for name in ('preserved-r4-sourcePASS.json','preserved-r4-sourcePASS.txt'):
    bind(R4/'independent/runtime-r4'/name,'inputs/source-gate/'+name,'preserved exact R4 source gate '+name,prior['sha256'][name])
manifest['run_id']=net['run_id']
manifest['resource_sha256']=hall['producer_resource_hashes']
manifest['resource_origins']={p:str((ROOT/p[6:]).resolve()) for p in hall['producer_resource_hashes']}
# Resource SHA execution belongs ONLY to the future finalizer. This preparation
# binds the original exact75 SHA map and checks existence/size, without rehashing assets.
manifest['resource_sizes']={p:(ROOT/p[6:]).stat().st_size for p in hall['producer_resource_hashes']}
manifest['resource_hash_recomputation_performed']=False
native=utf((OUT/'inputs/original/native.txt').read_bytes())
manifest['original_pass_messages']=[line[6:] for line in native.splitlines() if line.startswith('PASS: ')]
assert len(manifest['original_pass_messages'])==263
finalizer=get(OUT/'proposal/finalize.py')
compile(utf(finalizer),str(OUT/'proposal/finalize.py'),'exec') # Syntax only; code object never executed/imported.
manifest['finalizer_sha256']=sha(finalizer)
jout(OUT,'proposal/input-manifest.json',manifest)
input_manifest=get(OUT/'proposal/input-manifest.json')
r5_receipt={'packet_state':'FROZEN IGNORED SOURCE PROPOSAL; unparsed/unrun, independent source gate pending',
    'runtime_source_head':HEAD,'original_sha256':SOURCE,'after_sha256':sha(after),'patch_sha256':sha(patch),
    'owned_path':'tests/smoke_net_crossing_hall_agreement.gd (selected ignored proposal, not tracked)',
    'proposal_path':str(R5/'proposal'/owned),'peer_extension_sha256':PEER,
    'only_change':'out.has(path) short-circuits repeated existing resource hashing before FileAccess.get_sha256',
    'assertions_budgets_steps_inputs_save_reload_functions_unchanged':True,
    'inverse_and_unified_patch_byte_exact':True,'dependency_hashes_before_after':deps,
    'R4_original_smoke_status':'FAIL/native2/budget; unresolved4host ENet errors retained',
    'source_receipt_scope':'Source equality only; no runtime, F17#5 or F49 acceptance',
    'no_engine_Git_tracked_mutations':True}
jout(R5,'source-receipt.json',r5_receipt)
jout(R5,'manifest.json',{'source_head':HEAD,'original':SOURCE,'proposed':sha(after),'patch':sha(patch),
    'peer_extension':PEER,'source_receipt_sha256':sha(get(R5/'source-receipt.json')),
    'status':'FROZEN UNEXECUTED PROPOSAL','only_changed_path':str(R5/'proposal'/owned)})
for path,wanted in receipt['source_before'].items(): assert sha(get(ROOT/path))==wanted
for path,wanted in receipt['output_sha256'].items(): assert sha(get(RUN/path.replace('\\','/')))==wanted
assert get(RUN/'receipt.json')==receipt_b and get(assessment_dir/'review.json')==assessment
assert get(opening)==opening_seal
for path,b in opening_files.items(): assert get(opening.parent/path)==b
execution='"C:/Users/mattj/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe" -B "'+str(OUT/'proposal/finalize.py')+'" --manifest-sha256 '+sha(input_manifest)+' --output-dir "'+str(OUT/'results/r1')+'"'
receipt_final={'packet_state':'FROZEN READY FOR INDEPENDENT28d SOURCE GATE; finalizer NOT EXECUTED',
    'source_head':HEAD,'R4_source_sha256':SOURCE,'peer_sha256':PEER,
    'finalizer_sha256':sha(finalizer),'input_manifest_sha256':sha(input_manifest),
    'python_syntax_compiled_in_memory':True,'finalizer_executed_or_imported':False,
    'recomputed_resource_hashes':False,'expected_unique_resources':75,'dependencies_bound':36,
    'captured_original_outputs':len(receipt['output_sha256']),'captured_actual_producer_records':8,
    'execution_after_source_gate_only':execution,'original_whole_smoke':'FAIL/native2/budget +4unresolvedhostENetERROR',
    'scope':'Separate literal F17#5 fresh-default functional metadata proof only; transport-clean/F49 and acceptance/main-packaging remain OPEN',
    'tracked_source_and_all_original_raw_bytes_unchanged':True,'opening_packet_final_hashes_unchanged':True,
    'no_engine_Git_tracked_mutations':True,
    'standalone_bounds':{'seconds':180,'single_file_bytes':67108864,'read_bytes':536870912,'unique_files':256,'value_nodes':3000000},
    'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
jout(OUT,'source-receipt.json',receipt_final)
for base in (R5,OUT):
    files=[]
    for p in sorted(base.rglob('*')):
        if p.is_file() and p.name!='freeze.json':
            b=get(p); files.append({'path':str(p.relative_to(base)).replace('\\','/'),'sha256':sha(b),'bytes':len(b),'second_read_equal':True})
    jout(base,'freeze.json',{'state':'FROZEN IGNORED UNEXECUTED PROPOSAL','files':files,'source_head':HEAD,
        'no_acceptance_claim':True,'original_R4_smoke_status':'FAIL'})
print(json.dumps({'R5_source':sha(after),'R5_patch':sha(patch),'finalizer':sha(finalizer),
    'input_manifest':sha(input_manifest),'finalizer_executed':False,'resource_hashes_recomputed':False,
    'opening_unchanged':True,'execution_after_source_gate_only':execution},indent=2))
