# Net smoke run hall-agreement-r4-784b

Scene: title
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=15788 exited=true unexpected_exit=false
- peer 1 (client) pid=11600 exited=true unexpected_exit=false

FATAL: ERROR: smoke budget exceeded
