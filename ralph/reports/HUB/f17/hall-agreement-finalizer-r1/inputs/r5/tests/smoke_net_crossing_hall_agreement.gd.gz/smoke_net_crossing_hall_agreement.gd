extends "res://tests/helpers/net_harness.gd"

# peers: 2
# F17#5 selected real-ENet/default-display witness. No state grants or fixtures.
# Unattended UI confirmation/title Load continuations are disclosed in evidence.
# Locked live arches, sealed reserved arches, home open, empty shrine only.
# Mutable portal/shrine states require lawful F18/F19 coverage before claiming them.
const PEER_SOURCE := """extends "res://tools/net/peer_runner.gd"

# Read-only producers and an ordinary host title Load continuation. No fixtures.
var _hall_pin: Dictionary = {}

func _execute_step(msg: Dictionary) -> Dictionary:
	var action := str(msg.get("action", ""))
	var args: Dictionary = msg.get("args", {})
	if action == "production_host":
		var started: Dictionary = await _step_production_host(args)
		if str(started.get("verdict", "")) != "PASS": return started
		return await _hall_wait_host_ready(started)
	if action == "hall_capture":
		return await _hall_capture(args)
	if action == "hall_reload_host":
		return await _hall_reload_host(args)
	if action == "hall_leave_guest":
		return await _hall_leave_guest()
	return await super._execute_step(msg)

func _hall_guard(expected_peers: int = 2) -> Dictionary:
	var game := root.get_node_or_null("Game")
	var sess := _session()
	if game == null or sess == null or current_scene == null:
		return {}
	if not current_scene.has_method("shell_build_complete") or not bool(current_scene.call("shell_build_complete")) or bool(current_scene.get("simulation_only")):
		return {}
	if not bool(sess.call("is_active")) or not bool(sess.call("snapshot_ready")):
		return {}
	var hosting := bool(sess.call("is_host"))
	if str(sess.call("mode")) != ("host" if hosting else "client"):
		return {}
	if not hosting and not bool(sess.call("handshake_snapshot_applied")):
		return {}
	if bool(sess.get("_bootstrap_boundary")):
		return {}
	var registry: RefCounted = sess.call("registry")
	var me := int(sess.call("local_peer_id"))
	var row: Dictionary = registry.call("row", me)
	var local: RefCounted = game.get("local")
	var world: RefCounted = game.get("world")
	var character_id := str(local.get("character_id"))
	if character_id.is_empty() or str(row.get("character_id", "")) != character_id:
		return {}
	if str(row.get("realm", "")) != "meadows" or str(game.get("current_realm")) != "meadows":
		return {}
	if int(sess.call("peer_count")) != expected_peers or (expected_peers == 1 and not hosting):
		return {}
	var transition := sess.get_node_or_null("RealmTransition")
	if transition == null or not (transition.get("transactions") as Dictionary).is_empty():
		return {}
	if not (transition.get("_joining_local") as Dictionary).is_empty():
		return {}
	if not (transition.get("_joining") as Dictionary).is_empty():
		return {}
	var halls := _hall_scene_group("crossing_halls")
	if halls.size() != 1:
		return {}
	var hall: Node = halls[0]
	var display: Dictionary = world.get("redesign_world")
	if (hall.call("display_snapshot") as Dictionary) != display:
		return {}
	var world_id := str(world.get("world_id"))
	if world_id.is_empty():
		return {}
	var ledger_rpc := sess.get_node_or_null("LedgerRpc")
	var ledger: RefCounted = ledger_rpc.get("ledger") if ledger_rpc != null else null
	var saver: RefCounted = game.get("save_system")
	var character_store: RefCounted = saver.call("characters")
	return {"scene_instance": current_scene.get_instance_id(), "hall_instance": hall.get_instance_id(),
		"world_instance": world.get_instance_id(), "world_id": world_id,
		"local_peer_id": me, "character_id": character_id, "hosting": hosting,
		"session_epoch": int(transition.get("epoch")), "map_revision": int(registry.get("revision")),
		"world_revision": int(world.get("revision")), "ledger_seq": int(ledger.get("seq")) if ledger != null else -1,
		"registry_rows": registry.call("rows"), "display": display.duplicate(true),
		"character_load_result": character_store.get("last_load_result").duplicate(true)}

func _hall_wait_host_ready(started: Dictionary) -> Dictionary:
	# Keep SAME production_host in flight through real construction/release.
	# No clock reset or synthetic liveness; a real peer heartbeat follows readiness.
	var deadline: int = Time.get_ticks_msec() + 150000
	var stable: int = 0
	var prior: Dictionary = {}
	while Time.get_ticks_msec() < deadline:
		await physics_frame
		var guard: Dictionary = _hall_guard(1)
		stable = stable + 1 if not guard.is_empty() and guard == prior else 0
		prior = guard
		if stable >= 30:
			_send_heartbeat()
			var result: Dictionary = started.duplicate(true)
			result["host_ready_pin"] = guard.duplicate(true)
			result["detail"] = str(started.get("detail", "")) + "; real mounted world released and admitted host stable30 frames"
			return result
	return {"verdict": "FAIL", "detail": "production host world/admission did not finish real build in150s", "last_ready_guard": prior}

func _hall_scene_group(group: String) -> Array[Node]:
	var out: Array[Node] = []
	for node: Node in get_nodes_in_group(group):
		if current_scene != null and current_scene.is_ancestor_of(node):
			out.append(node)
	return out

func _hall_capture(args: Dictionary) -> Dictionary:
	# Each process earns readiness independently. Host expectations are never inputs.
	var deadline := Time.get_ticks_msec() + 20000
	var stable := 0
	var prior := {}
	while Time.get_ticks_msec() < deadline:
		await physics_frame
		var guard := _hall_guard()
		stable = stable + 1 if not guard.is_empty() and guard == prior else 0
		prior = guard
		if stable >= 30:
			_hall_pin = guard.duplicate(true)
			var data := _hall_producers()
			if data.is_empty() or _hall_guard() != _hall_pin:
				return {"verdict": "FAIL", "detail": "producer snapshot invalidated its own readiness/revision pin"}
			data["pin"] = _hall_pin.duplicate(true)
			data["phase"] = str(args.get("phase", ""))
			data["peer_source_sha256"] = FileAccess.get_sha256(get_script().resource_path)
			data["peer_runtime_path"] = get_script().resource_path
			return {"verdict": "PASS", "detail": "30 independently stable admitted frames; captured real scene producers", "data": data}
	return {"verdict": "FAIL", "detail": "admitted identity/receiver/map/display readiness did not stabilize in 20 s"}

func _hall_producers() -> Dictionary:
	var villages: Array[Node] = []
	_hall_find_village(current_scene, villages)
	var halls := _hall_scene_group("crossing_halls")
	var arches := _hall_scene_group("crossing_hall_arches")
	var pedestals := _hall_scene_group("crossing_hall_pedestals")
	var houses := _hall_scene_group("village_road_houses")
	if villages.size() != 1 or halls.size() != 1 or arches.size() != 8 or pedestals.size() != 8 or houses.size() < 8 or houses.size() > 10:
		return {}
	var layout: Array = []
	_hall_tree(villages[0], "village", layout)
	var arch_rows: Array = []
	for node: Node in arches:
		var sign := node.get_node_or_null("BiomeSign") as Label3D
		var state := node.get_node_or_null("StateSign") as Label3D
		var surface := node.get_node_or_null("PortalSurface") as MeshInstance3D
		if sign == null or state == null or surface == null or surface.mesh == null or surface.material_override == null:
			return {}
		var meshes: Array = []
		_hall_tree(node, "arch", meshes)
		arch_rows.append({"id": str(node.name).trim_prefix("Arch_"), "biome": node.get_meta("biome", ""),
			"state": node.get_meta("arch_state", ""), "sign": sign.text, "state_sign": state.text,
			"sign_visible": sign.is_visible_in_tree(), "state_sign_visible": state.is_visible_in_tree(),
			"surface_visible": surface.is_visible_in_tree(), "material": _hall_material(surface.material_override),
			"nodes": meshes})
	var shrine_rows: Array = []
	for node: Node in pedestals:
		var nodes: Array = []
		_hall_tree(node, "pedestal", nodes)
		shrine_rows.append({"biome": node.get_meta("biome", ""), "relic_displayed": node.get_meta("relic_displayed", null), "nodes": nodes})
	var hall_nodes: Array = []
	_hall_tree(halls[0], "hall", hall_nodes)
	return {"producers": {"village_nodes": layout, "hall_nodes": hall_nodes, "arches": arch_rows, "shrines": shrine_rows},
		"counts": {"villages": villages.size(), "halls": halls.size(), "road_houses": houses.size(), "arches": arches.size(), "pedestals": pedestals.size()}}

func _hall_find_village(node: Node, out: Array[Node]) -> void:
	var script: Script = node.get_script()
	if script != null and script.resource_path == "res://scripts/world/village.gd":
		out.append(node)
	for child: Node in node.get_children():
		_hall_find_village(child, out)

func _hall_tree(node: Node, path: String, out: Array) -> void:
	# Structural paths avoid autogenerated @Node3D instance numbers across peers.
	var row := {"path": path, "class": node.get_class()}
	for key: String in ["village_role", "house_name", "biome", "arch_state", "relic_displayed"]:
		if node.has_meta(key):
			row[key] = node.get_meta(key)
	if node is Node3D:
		row["local_transform"] = _hall_transform(node.transform)
		row["global_transform"] = _hall_transform(node.global_transform)
		row["visible"] = node.visible
		row["visible_in_tree"] = node.is_visible_in_tree()
	if node is Label3D:
		row["text"] = node.text
		row["modulate"] = _hall_color(node.modulate)
		row["font_size"] = node.font_size
	if node is MeshInstance3D and node.mesh != null:
		row["mesh_class"] = node.mesh.get_class()
		row["mesh_resource"] = node.mesh.resource_path
		row["aabb"] = [_hall_vec(node.get_aabb().position), _hall_vec(node.get_aabb().size)]
		row["surface_count"] = node.mesh.get_surface_count()
		row["override"] = _hall_material(node.material_override)
		var materials: Array = []
		for index: int in node.mesh.get_surface_count():
			materials.append(_hall_material(node.get_active_material(index)))
		row["materials"] = materials
	if node is CollisionShape3D and node.shape != null:
		row["shape_class"] = node.shape.get_class()
		row["shape_resource"] = node.shape.resource_path
		row["disabled"] = node.disabled
		if node.shape is BoxShape3D:
			row["size"] = _hall_vec(node.shape.size)
	if node is Light3D:
		row["light_color"] = _hall_color(node.light_color)
		row["energy"] = node.light_energy
		row["shadow"] = node.shadow_enabled
	out.append(row)
	var index := 0
	for child: Node in node.get_children():
		_hall_tree(child, path + "/" + str(index), out)
		index += 1

func _hall_transform(value: Transform3D) -> Array:
	return [_hall_vec(value.basis.x), _hall_vec(value.basis.y), _hall_vec(value.basis.z), _hall_vec(value.origin)]

func _hall_vec(value: Vector3) -> Array:
	return [snappedf(value.x, 0.00001), snappedf(value.y, 0.00001), snappedf(value.z, 0.00001)]

func _hall_color(value: Color) -> Array:
	return [value.r, value.g, value.b, value.a]

func _hall_material(value: Material) -> Dictionary:
	if value == null:
		return {}
	var out := {"class": value.get_class(), "resource": value.resource_path}
	if value is BaseMaterial3D:
		out["albedo"] = _hall_color(value.albedo_color)
		out["emission_enabled"] = value.emission_enabled
		out["emission"] = _hall_color(value.emission)
		out["emission_energy"] = value.emission_energy_multiplier
		out["roughness"] = value.roughness
		out["transparency"] = value.transparency
		out["cull_mode"] = value.cull_mode
		out["albedo_texture"] = value.albedo_texture.resource_path if value.albedo_texture != null else ""
	return out

func _hall_reload_host(args: Dictionary) -> Dictionary:
	var game := root.get_node_or_null("Game")
	var sess := _session()
	if game == null or sess == null or not bool(sess.call("is_host")) or int(sess.call("peer_count")) != 1:
		return {"verdict": "FAIL", "detail": "reload requires the actual host with guest cleanly departed"}
	var old_scene := current_scene.get_instance_id()
	var old_halls := _hall_scene_group("crossing_halls")
	if old_halls.size() != 1:
		return {"verdict": "FAIL", "detail": "missing old Hall before reload"}
	var old_hall := old_halls[0].get_instance_id()
	var old_world_id := str(game.get("world").get("world_id"))
	var slot := int(game.call("autosave_slot"))
	if not bool(game.call("autosave_here")):
		return {"verdict": "FAIL", "detail": "production host autosave_here refused"}
	var saver: RefCounted = game.get("save_system")
	var world_store: RefCounted = saver.call("worlds")
	var disk := str(world_store.call("path_for", old_world_id))
	var before_disk := FileAccess.get_sha256(disk)
	if before_disk.is_empty():
		return {"verdict": "FAIL", "detail": "production split world file absent"}
	var left: Dictionary = await _step_leave({})
	if str(left.get("verdict", "")) != "PASS":
		return left
	before_disk = FileAccess.get_sha256(disk)
	var saved: Variant = JSON.parse_string(FileAccess.get_file_as_string(disk))
	if not saved is Dictionary or not (saved as Dictionary).get("redesign_world") is Dictionary:
		return {"verdict": "FAIL", "detail": "saved host split file has no redesign display payload"}
	var saved_display: Dictionary = (saved as Dictionary).get("redesign_world")
	# Real Load button continuation reads disk and rebuilds the ordinary scene.
	if change_scene_to_file(TITLE_SCENE) != OK:
		return {"verdict": "FAIL", "detail": "could not return host to title"}
	for frame in 120:
		await physics_frame
		if current_scene != null and current_scene.is_in_group("title_screen"):
			break
	if current_scene == null or not current_scene.is_in_group("title_screen"):
		return {"verdict": "FAIL", "detail": "host title did not become current"}
	current_scene.set("_host_port", int(args.get("port", _enet_port)))
	current_scene.call("_load_slot", slot)
	var deadline := Time.get_ticks_msec() + 150000
	while Time.get_ticks_msec() < deadline:
		await physics_frame
		var new_halls := _hall_scene_group("crossing_halls")
		if not _hall_guard(1).is_empty() and new_halls.size() == 1:
			var rebuilt := current_scene.get_instance_id() != old_scene and new_halls[0].get_instance_id() != old_hall
			var same_world := str(game.get("world").get("world_id")) == old_world_id
			var loaded: Dictionary = saver.get("last_load_result")
			var disk_display_matches: bool = saved_display == game.get("world").get("redesign_world")
			if rebuilt and same_world and bool(loaded.get("ok", false)) and disk_display_matches:
				_send_heartbeat()
			return {"verdict": "PASS" if rebuilt and same_world and bool(loaded.get("ok", false)) and disk_display_matches else "FAIL", "detail": "production autosave + title Load; scene and Hall rebuilt from host save", "data": {
				"old_scene_instance": old_scene, "new_scene_instance": current_scene.get_instance_id(),
				"old_hall_instance": old_hall, "new_hall_instance": new_halls[0].get_instance_id(),
				"world_id": old_world_id, "world_disk_sha256": before_disk, "world_disk_path": disk,
				"slot": slot, "rebuilt": rebuilt, "same_world": same_world, "load_result": loaded,
				"saved_display": saved_display, "disk_display_matches": disk_display_matches}}
	return {"verdict": "FAIL", "detail": "production title Load did not rebuild an active Hall in 150 s"}

func _hall_leave_guest() -> Dictionary:
	var game := root.get_node_or_null("Game")
	var sess := _session()
	if game == null or sess == null or bool(sess.call("is_host")) or not bool(sess.call("is_active")):
		return {"verdict": "FAIL", "detail": "guest leave requires the admitted active client"}
	var character_id := str(game.get("local").get("character_id"))
	var left: Dictionary = await _step_leave({})
	if str(left.get("verdict", "")) != "PASS":
		return left
	var saver: RefCounted = game.get("save_system")
	var store: RefCounted = saver.call("characters")
	var path := str(store.call("path_for", character_id))
	var saved: Dictionary = store.call("read", character_id)
	var load_result: Dictionary = store.get("last_load_result")
	var valid: bool = not saved.is_empty() and bool(load_result.get("ok", false)) and str(saved.get("character_id", "")) == character_id
	return {"verdict": "PASS" if valid else "FAIL", "detail": "production client leave saved its own portable character; production reader confirmed disk payload", "data": {
		"character_id": character_id, "character_disk_path": path, "character_disk_sha256": FileAccess.get_sha256(path), "load_result": load_result}}
"""
const DEPENDENCIES := [
	"project.godot", "autoload/game_state.gd", "autoload/world_state.gd", "autoload/player_state.gd",
	"scripts/net/session.gd", "scripts/net/peer_registry.gd", "scripts/mp/join_driver.gd",
	"scripts/net/realm_transition.gd", "scripts/net/realm_receiver_history.gd", "scripts/net/snapshot_transfer.gd",
	"scripts/net/ledger_rpc.gd", "scripts/net/world_ledger.gd", "scripts/save/save_game.gd",
	"scripts/save/world_save.gd", "scripts/save/character_save.gd", "scripts/ui/title_screen.gd",
	"scripts/world/village.gd", "scripts/world/crossing_hall.gd", "scripts/world/building_prefabs.gd",
	"scripts/data/biome_order.gd", "scripts/data/redesign_state.gd", "tests/helpers/net_harness.gd",
	"scripts/data/redesign_data.gd", "data/schema/world_state.json", "data/schema/world_state.schema.json",
	"tests/helpers/net_control_ports.gd", "tools/net/peer_runner.gd", "data/config/village.json",
	"data/config/crossing_hall.json", "data/config/building_prefabs.json", "data/config/terrain_playground.json",
	"data/config/biome_order.json", "data/config/characters.json", "data/config/multiplayer.json",
	"scenes/ui/title_screen.tscn", "scenes/world/meadows_playground.tscn"]
var _hall_peer_path := ""
var _hall_evidence: Dictionary = {"coverage": "fresh lawful default world; host title Load; guest saved identity rejoin",
	"limits": "No earned unlock/hung relic coverage. Empty shrine producer trees only; metadata is not a rendered hung relic proof.",
	"shortcuts": ["unattended title identity confirmations", "title Load button continuation", "read-only actual instantiated producer snapshots"],
	"pairs": {}}

func _initialize() -> void:
	_run()

func _run() -> void:
	await process_frame
	if not _hall_stage_peer():
		quit(2)
		return
	world_build_allowance_floor_s["production_host"] = 150.0
	world_build_allowance_floor_s["production_join"] = 150.0
	world_build_allowance_floor_s["hall_reload_host"] = 150.0
	if not await launch(2, "title"):
		quit(await finish())
		return
	# Four ordinary world builds and bounded readiness barriers fit this selected proof.
	_step_phase_deadline_ms = Time.get_ticks_msec() + 600000.0
	var hello_host: Dictionary = (_peers[0] as Dictionary).get("hello", {})
	var hello_guest: Dictionary = (_peers[1] as Dictionary).get("hello", {})
	check(hello_host.get("user_data_dir", "") != hello_guest.get("user_data_dir", ""), "distinct actual host/guest user profiles")
	_hall_evidence["hello"] = [hello_host, hello_guest]
	_hall_evidence["dependencies"] = _hall_dependencies()
	_hall_evidence["source_sha256"] = FileAccess.get_sha256(get_script().resource_path)
	_hall_evidence["peer_source_sha256"] = PEER_SOURCE.sha256_text()
	_hall_evidence["peer_runtime_path"] = _hall_peer_path
	var port := int(hello_host.get("enet_port", 0))
	if not await _hall_step(0, "production_host", {"port": port, "appearance_id": "trainer", "display_name": "HallHost"}, 9000): return
	if not await _hall_step(1, "production_join", {"host": "127.0.0.1", "port": port,
		"returning_route": false, "character": {"appearance_id": "lyra", "display_name": "HallGuest"}}, 9000): return
	var joined := await _hall_pair("joined")
	if joined.is_empty():
		await _hall_finish()
		return
	var guest_id := str((joined.guest as Dictionary).pin.character_id)
	if not await _hall_step(1, "hall_leave_guest", {}): return
	if not await _hall_step(0, "expect_peers", {"count": 1}): return
	if not await _hall_step(0, "hall_reload_host", {"port": port}, 9000): return
	if not await _hall_step(1, "production_join", {"host": "127.0.0.1", "port": port,
		"returning_route": true, "character": {"character_id": guest_id}}, 9000): return
	var reloaded := await _hall_pair("reloaded")
	if not reloaded.is_empty():
		check(joined.host.producers == reloaded.host.producers, "host rebuilt village/Hall producers persist across disk Load")
		check(joined.guest.producers == reloaded.guest.producers, "guest rebuilt village/Hall producers persist across saved-character rejoin")
		check(joined.host.pin.world_id == reloaded.host.pin.world_id, "same host world identity after production disk Load")
		check(joined.host.pin.character_id == reloaded.host.pin.character_id, "same host character after production disk Load")
		check(guest_id == reloaded.guest.pin.character_id, "same saved guest character admitted after host reload")
		check(bool(reloaded.guest.pin.character_load_result.get("ok", false)), "production title returning-guest reader loaded portable character from disk")
		check(joined.host.pin.scene_instance != reloaded.host.pin.scene_instance, "host scene rebuilt")
		check(joined.host.pin.hall_instance != reloaded.host.pin.hall_instance, "host Hall rebuilt")
		check(joined.guest.pin.scene_instance != reloaded.guest.pin.scene_instance, "guest scene rebuilt on rejoin")
		check(joined.guest.pin.hall_instance != reloaded.guest.pin.hall_instance, "guest Hall rebuilt on rejoin")
	_hall_evidence["producer_resource_hashes"] = {}
	_hall_resource_hashes(_hall_evidence.pairs, _hall_evidence.producer_resource_hashes)
	await _hall_finish()

func _hall_step(peer: int, action: String, args: Dictionary, frames: int = 3000) -> bool:
	var result := await step(peer, action, args, frames)
	var passed := str(result.get("verdict", "")) == "PASS"
	check(passed, "peer %d %s: %s" % [peer, action, str(result.get("detail", ""))])
	if action == "hall_reload_host":
		_hall_evidence["reload"] = result
	if action == "hall_leave_guest":
		_hall_evidence["guest_save"] = result
	if not passed:
		await _hall_finish()
	return passed

func _hall_pair(phase: String) -> Dictionary:
	var captures: Array = []
	for peer: int in [0, 1, 0, 1]:
		var result := await step(peer, "hall_capture", {"phase": phase}, 1800)
		check(str(result.get("verdict", "")) == "PASS", "%s peer %d independent capture: %s" % [phase, peer, result.get("detail", "")])
		if str(result.get("verdict", "")) != "PASS":
			return {}
		var data: Dictionary = result.get("data", {})
		check(data.get("peer_source_sha256", "") == PEER_SOURCE.sha256_text(), "peer %d runtime helper bytes pinned" % peer)
		check(data.get("peer_runtime_path", "") == _hall_peer_path, "peer %d uses this run's exclusive helper" % peer)
		captures.append(data)
	var host: Dictionary = captures[0]
	var guest: Dictionary = captures[1]
	check(host.pin == captures[2].pin and host.producers == captures[2].producers, phase + " host revision/epoch/producer pin survives cross-peer capture")
	check(guest.pin == captures[3].pin and guest.producers == captures[3].producers, phase + " guest revision/epoch/producer pin survives cross-peer capture")
	check(bool(host.pin.hosting) and not bool(guest.pin.hosting), phase + " actual server/client roles")
	check(int(host.pin.local_peer_id) == 1 and int(guest.pin.local_peer_id) > 1, phase + " actual ENet admitted peer IDs")
	check(host.pin.character_id != guest.pin.character_id, phase + " separate admitted stable characters")
	check(host.pin.registry_rows == guest.pin.registry_rows, phase + " replicated admission/realm maps agree")
	check(host.pin.world_id == guest.pin.world_id, phase + " host-authoritative world identity agrees")
	check(host.pin.display == guest.pin.display, phase + " host-authoritative display state agrees")
	check(host.producers == guest.producers, phase + " actual village/Hall transforms, mesh trees, visible text/material/arch/shrine producers agree")
	_hall_defaults(host, phase + " host")
	_hall_defaults(guest, phase + " guest")
	var pair := {"host": host, "guest": guest, "host_recheck": captures[2], "guest_recheck": captures[3]}
	_hall_evidence.pairs[phase] = pair
	_hall_write_evidence()
	return pair

func _hall_defaults(data: Dictionary, label: String) -> void:
	var display: Dictionary = data.pin.display
	check((display.get("portal_unlocks", []) as Array).is_empty(), label + " disclosed fresh locked portal state")
	check((display.get("shrine_display", {}) as Dictionary).is_empty(), label + " disclosed fresh empty shrine state")
	check(not bool(display.get("fifth_arch_stirred", false)), label + " reserved fifth arch remains sealed")
	for arch: Dictionary in data.producers.arches:
		var id := str(arch.id)
		var expected := "open" if id == "home" else "locked" if id in ["tidewake", "cloudreach", "stormwood"] else "sealed"
		check(arch.state == expected, label + " actual " + id + " state " + expected)
		check(arch.state_sign == ("Home arch" if id == "home" else expected.capitalize()), label + " visible state text matches " + id)
		check(bool(arch.sign_visible) and bool(arch.state_sign_visible) and bool(arch.surface_visible), label + " signed visible membrane " + id)
		check(bool(arch.material.get("emission_enabled", false)) == (id == "home"), label + " actual surface emission " + id)
	for shrine: Dictionary in data.producers.shrines:
		check(shrine.relic_displayed == false, label + " empty shrine " + str(shrine.biome))
		var visible_mesh := false
		var visible_label := false
		for row: Dictionary in shrine.nodes:
			visible_mesh = visible_mesh or (row.get("class", "") == "MeshInstance3D" and bool(row.get("visible_in_tree", false)))
			visible_label = visible_label or (row.get("class", "") == "Label3D" and bool(row.get("visible_in_tree", false)) and not str(row.get("text", "")).is_empty())
		check(visible_mesh and visible_label, label + " actual empty pedestal and biome sign " + str(shrine.biome))

func _hall_stage_peer() -> bool:
	var nonce := Crypto.new().generate_random_bytes(12).hex_encode()
	var directory := "res://.tmp/hall-agreement-runtime/" + str(OS.get_process_id()) + "-" + nonce
	if DirAccess.dir_exists_absolute(directory) or DirAccess.make_dir_recursive_absolute(directory) != OK:
		return false
	_hall_peer_path = directory + "/peer.gd"
	if FileAccess.file_exists(_hall_peer_path):
		return false
	var output := FileAccess.open(_hall_peer_path, FileAccess.WRITE)
	if output == null:
		return false
	output.store_string(PEER_SOURCE)
	output.close()
	return FileAccess.get_sha256(_hall_peer_path) == PEER_SOURCE.sha256_text()

func _spawn_peer(i: int, role: String, control_port: int, enet_port: int, scene: String,
		home: String, log_path: String, extra_args: Array) -> int:
	# Only this selected smoke substitutes the extension; normal runners are untouched.
	if _hall_peer_path.is_empty() or FileAccess.get_sha256(_hall_peer_path) != PEER_SOURCE.sha256_text():
		return -1
	var args := ["--headless", "--path", ProjectSettings.globalize_path("res://")]
	if _is_windows():
		args.append_array(["--log-file", log_path])
	args.append_array(["--script", _hall_peer_path, "--", "--role=" + role, "--peer=%d" % i,
		"--control-port=%d" % control_port, "--enet-port=%d" % enet_port, "--scene=" + scene,
		"TB_NET_RUN_ID=" + _run_id])
	args.append_array(extra_args)
	OS.set_environment("XDG_DATA_HOME", home)
	if _is_windows():
		OS.set_environment("APPDATA", home)
	OS.set_environment("TB_NET_RUN_ID", _run_id)
	OS.set_environment("TB_WORLD_SEED", OS.get_environment("TB_NET_WORLD_SEED") if not OS.get_environment("TB_NET_WORLD_SEED").is_empty() else "0")
	if _is_windows():
		return OS.create_process(OS.get_executable_path(), args)
	var parts: Array[String] = [_shq(OS.get_executable_path())]
	for arg: Variant in args:
		parts.append(_shq(str(arg)))
	return OS.create_process("/bin/sh", ["-c", "exec %s >%s 2>&1" % [" ".join(parts), _shq(log_path)]])

func _hall_dependencies() -> Dictionary:
	var out := {}
	for path: String in DEPENDENCIES:
		if FileAccess.file_exists("res://" + path):
			out[path] = FileAccess.get_sha256("res://" + path)
		else:
			out[path] = "ABSENT"
	return out

func _hall_resource_hashes(value: Variant, out: Dictionary) -> void:
	if value is Dictionary:
		for nested: Variant in value.values():
			_hall_resource_hashes(nested, out)
	elif value is Array:
		for nested: Variant in value:
			_hall_resource_hashes(nested, out)
	elif value is String and value.begins_with("res://"):
		var path: String = value.get_slice("::", 0)
		if not out.has(path) and FileAccess.file_exists(path):
			out[path] = FileAccess.get_sha256(path)

func _hall_write_evidence() -> void:
	if _run_dir.is_empty():
		return
	_hall_evidence["failures"] = failures.duplicate()
	var file := FileAccess.open(_run_dir.path_join("HALL_AGREEMENT.json"), FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(_hall_evidence, "\t"))
		file.close()

func _hall_finish() -> void:
	_hall_write_evidence()
	print("F17#5 actual admitted ENet + host title Load + guest saved rejoin; legal fresh locked/empty state only. Nondefault states unproved.")
	var code := await finish()
	_hall_evidence["exit_code"] = code
	_hall_write_evidence()
	quit(code)
