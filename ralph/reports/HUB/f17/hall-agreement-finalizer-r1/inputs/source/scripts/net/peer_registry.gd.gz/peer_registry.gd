extends RefCounted

## Stage B Wave 2 lane 2.A. WHO IS IN THIS SESSION.
##
## Host-authoritative: only the host mutates rows; every change is replicated
## WHOLE (`save_data()` -> `load_data()`), never as a delta. A registry is four
## short rows at most (D95's peer cap is 4), so a delta protocol would cost more
## to get wrong than the whole payload costs to send.
##
## Pure `RefCounted` on purpose, exactly like `world_state.gd` /
## `player_state.gd`: no `Node`, no `multiplayer.`, no signals. `session.gd`
## owns the transport and does the emitting; this file only knows the mapping
##
##     peer id  <->  character id  <->  appearance id  <->  display name  <->  realm
##
## plus the two Wave 4/5 placeholder flags (`sleeping` for D105's sleep vote,
## `downed` for the revive window). They are stored and replicated from today so
## the later waves add behaviour rather than a new field on the wire.
##
## ## Peer ids are not small
##
## `ralph/reports/MP-0C-SPIKE-ENET-0905/REPORT.md` finding 2: ENet hands clients
## large random 32-bit ids (`2098775056`, `1519229912`); only the listen server
## is a small number (1). Nothing here assumes an order, a range, or a density
## -- rows are keyed by the real id and `rows()` sorts by it purely so two peers
## hash the same list in the same order.

## The host's own id under Godot's high-level multiplayer. Not a guess: the
## server end of an `ENetMultiplayerPeer` is always 1.
const HOST_PEER_ID := 1

## peer_id:int -> row Dictionary. Never handed out by reference; every accessor
## duplicates, so a caller cannot mutate the registry by holding a row.
var _rows: Dictionary = {}

## Host-only reconnect seats (MULTIPLAYER §1.1/§5, `session.reconnect_window_s`).
## character_id:String -> expiry in `Time.get_ticks_msec()` milliseconds.
## When an admitted joiner's connection drops, its character keeps a seat for
## the window, so a friend who lost their connection is not locked out of a
## session that filled while they were away. Reservations are not rows: they
## are not replicated, not in `fingerprint()`, and no gameplay code sees them.
## They only count against capacity in `admission_verdict()`.
var _reservations: Dictionary = {}

## Bumped on every mutation, the same "did anything move" counter
## `world_state.gd` keeps. `session.gd` replicates when this changes.
var revision: int = 0


## A row with every field present, whatever the caller left out. One shape,
## always -- a replicated row with a missing key is the kind of thing that
## reads fine on the host and crashes a client three waves later.
static func make_row(peer_id: int, character_id: String = "", display_name: String = "",
		realm: String = "meadows", appearance_id: String = "trainer") -> Dictionary:
	return {
		"peer_id": peer_id,
		"character_id": character_id,
		"display_name": display_name,
		"appearance_id": appearance_id if not appearance_id.is_empty() else "trainer",
		"realm": realm,
		"sleeping": false,
		"downed": false,
	}


## Decide whether a transport peer may become a live session member. This is
## deliberately pure: Session asks before it mutates this registry, prepares a
## realm transition, or sends the authoritative world snapshot.
##
## Stable character ids already have several valid forms (`peer-*`, migrated
## `legacy-slot-*`, and ids from portable saves), so admission does not invent a
## GUID or platform-account format. It enforces the invariant the authority
## consumers already rely on: one nonempty, edge-trimmed String belongs to one
## live peer. A reconnect is legal after the old peer row has been removed.
##
## `now_ms` lets expired reconnect seats lapse at the moment of the decision;
## a negative value reads the clock. A character holding a seat may take it
## even when every other seat is filled or held.
func admission_verdict(peer_id: int, raw_character_id: Variant, max_peers: int,
		now_ms: int = -1) -> Dictionary:
	if peer_id <= HOST_PEER_ID:
		return _refuse("invalid_peer", "The joining connection could not be identified.")
	if not raw_character_id is String:
		return _refuse("invalid_character", "Choose a valid portable character before joining.")
	var character_id: String = raw_character_id
	if character_id.is_empty() or character_id.strip_edges() != character_id:
		return _refuse("invalid_character", "Choose a valid portable character before joining.")
	if _rows.has(peer_id):
		return _refuse("peer_already_admitted", "This connection is already in the session.")
	var holder := peer_for_character(character_id)
	if holder != 0:
		return _refuse("character_in_use", "That character is already connected to this world.")
	expire_reservations(now_ms)
	var cap := maxi(1, max_peers)
	var held_for_others := _reservations.size() - (1 if _reservations.has(character_id) else 0)
	if _rows.size() + held_for_others >= cap:
		if held_for_others > 0 and _rows.size() < cap:
			return _refuse("session_full",
				"This session is full (%d/%d). A seat is being held for a player who is reconnecting; try again in a couple of minutes."
				% [_rows.size() + held_for_others, cap])
		return _refuse("session_full", "This session is full (%d/%d)." % [_rows.size(), cap])
	return {"ok": true, "code": "", "reason": ""}


## Hold a seat for `character_id` until `expires_ms`. Host-only bookkeeping;
## see `_reservations`. Empty ids and live characters are not reserved.
func reserve(character_id: String, expires_ms: int) -> bool:
	if character_id.is_empty() or peer_for_character(character_id) != 0:
		return false
	_reservations[character_id] = expires_ms
	return true


func has_reservation(character_id: String, now_ms: int = -1) -> bool:
	expire_reservations(now_ms)
	return _reservations.has(character_id)


func reservation_count(now_ms: int = -1) -> int:
	expire_reservations(now_ms)
	return _reservations.size()


func expire_reservations(now_ms: int = -1) -> void:
	if _reservations.is_empty():
		return
	var now := now_ms if now_ms >= 0 else Time.get_ticks_msec()
	for character_id: String in _reservations.keys():
		if now >= int(_reservations[character_id]):
			_reservations.erase(character_id)


func _refuse(code: String, reason: String) -> Dictionary:
	return {"ok": false, "code": code, "reason": reason}


## Add or overwrite a peer's row. Returns the stored row, or an empty
## Dictionary when another live peer already owns the character identity.
## Session normally calls `admission_verdict()` first; this final guard keeps a
## direct caller from evicting the host or another admitted peer.
func add(peer_id: int, character_id: String = "", display_name: String = "",
		realm: String = "meadows", appearance_id: String = "trainer") -> Dictionary:
	if not character_id.is_empty():
		var previous := peer_for_character(character_id)
		if previous != 0 and previous != peer_id:
			return {}
	var row := make_row(peer_id, character_id, display_name, realm, appearance_id)
	_rows[peer_id] = row
	# A returning character takes its own held seat.
	_reservations.erase(character_id)
	revision += 1
	return row.duplicate(true)


func remove(peer_id: int) -> bool:
	if not _rows.has(peer_id):
		return false
	_rows.erase(peer_id)
	revision += 1
	return true


func clear() -> void:
	_rows.clear()
	_reservations.clear()
	revision += 1


func has(peer_id: int) -> bool:
	return _rows.has(peer_id)


func size() -> int:
	return _rows.size()


func row(peer_id: int) -> Dictionary:
	if not _rows.has(peer_id):
		return {}
	return (_rows[peer_id] as Dictionary).duplicate(true)


## Every row, ordered by peer id. The order is the point: two peers comparing
## registries compare `fingerprint()`, and an unordered `Dictionary.values()`
## would hash differently on two processes holding identical data.
func peer_ids() -> Array:
	var ids: Array = _rows.keys()
	ids.sort()
	return ids


func rows() -> Array:
	var out: Array = []
	for id in peer_ids():
		out.append((_rows[id] as Dictionary).duplicate(true))
	return out


## The peer currently holding `character_id`, or 0 -- never -1: `0` is
## `MultiplayerPeer`'s own "no peer" value and the only id ENet will never
## assign, so it is the honest sentinel here too.
func peer_for_character(character_id: String) -> int:
	if character_id.is_empty():
		return 0
	for id: int in _rows.keys():
		if str((_rows[id] as Dictionary).get("character_id", "")) == character_id:
			return id
	return 0


func set_realm(peer_id: int, realm: String) -> bool:
	return _set_field(peer_id, "realm", realm)


## `sleeping` (D105's vote) / `downed` (Wave 5). Nothing in Wave 2 reads them;
## they exist so the wire shape does not change when those waves land.
func set_flag(peer_id: int, key: String, value: bool) -> bool:
	if key != "sleeping" and key != "downed":
		return false
	return _set_field(peer_id, key, value)


func _set_field(peer_id: int, key: String, value: Variant) -> bool:
	if not _rows.has(peer_id):
		return false
	var r: Dictionary = _rows[peer_id]
	if r.get(key) == value:
		return false
	r[key] = value
	revision += 1
	return true


## The whole registry, as it goes on the wire and into a report.
func save_data() -> Dictionary:
	return {"revision": revision, "rows": rows()}


## Replace everything. Tolerant of every missing key, the same contract
## `world_state.gd::load_data()` gives `save_game.gd`: a malformed replication
## payload leaves an EMPTY registry rather than a half-applied one, because a
## half-applied registry is indistinguishable from a real disagreement.
func load_data(data: Dictionary) -> void:
	_rows.clear()
	var raw: Variant = data.get("rows", [])
	if typeof(raw) == TYPE_ARRAY:
		for entry: Variant in (raw as Array):
			if typeof(entry) != TYPE_DICTIONARY:
				continue
			var e: Dictionary = entry
			var id := int(e.get("peer_id", 0))
			if id == 0:
				continue
			var r := make_row(id, str(e.get("character_id", "")),
				str(e.get("display_name", "")), str(e.get("realm", "meadows")),
				str(e.get("appearance_id", "trainer")))
			r["sleeping"] = bool(e.get("sleeping", false))
			r["downed"] = bool(e.get("downed", false))
			_rows[id] = r
	revision = int(data.get("revision", revision + 1))


## What two peers compare to say "our registries agree". Deliberately NOT
## `revision`: two peers can hold identical rows having taken different numbers
## of steps to get there (the host counted its own join; a client that joined
## late did not), and comparing bookkeeping instead of content would report a
## disagreement that is not one. `hash()` of the ordered rows is the content.
func fingerprint() -> int:
	return hash(JSON.stringify(rows(), "", true))
