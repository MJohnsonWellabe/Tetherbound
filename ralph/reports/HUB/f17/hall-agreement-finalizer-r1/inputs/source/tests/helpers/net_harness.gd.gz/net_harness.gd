extends SceneTree

## MP net harness coordinator. Stage B Wave 0 lane 0.F.
## docs/specs/MP_NET_HARNESS_CONTRACT.md §2-§8.
##
## Not run directly. A `tests/smoke_net_*.gd` coordinator EXTENDS this file by
## path, the way `scripts/ui/tab_map.gd` extends `scripts/ui/menu_tab.gd`:
##
##   extends "res://tests/helpers/net_harness.gd"
##   # peers: 2
##   func _initialize() -> void:
##       _run()   # fire-and-forget coroutine, same pattern as every SceneTree
##                # harness in this repo (see tools/net/_spike_enet.gd)
##
##   func _run() -> void:
##       if not await launch(2, "world"):
##           quit(await finish())
##           return
##       check(await probe(0, "input_context") == "world", "peer 0 booted into the world")
##       ...
##       quit(await finish())
##
## ## What this owns (contract §2)
##
## Launching one `tools/net/peer_runner.gd` process per peer, each with its
## own `XDG_DATA_HOME`, ENet port and control port (isolation is
## non-negotiable -- the `tools/flake_rate.sh` rule: one machine, many runs, no
## shared `user://`); serving the TCP control channel peers connect OUT to
## (the coordinator is the `TCPServer`); sequencing `step`/`probe` and reading
## `hello`/`verdict`/`value`/`heartbeat`/`log`; running the desync detector
## (§7); and writing `NET_RUN.json`/`SUMMARY.md` into the run directory.
##
## Peers are launched with `OS.create_process` from here (contract §2's first
## option), following spike item 6 (`ralph/reports/MP-0C-SPIKE-ENET-0905/REPORT.md`).
## POSIX uses `/bin/sh -c` for log redirection while Windows invokes Godot's
## executable directly, assigns each child a distinct APPDATA root, and lets
## `--log-file` write the per-peer log.
##
## ## Wire format
##
## Newline-delimited JSON, one object per line, both directions. Every object
## carries a `"type"` field naming which row of contract §3's tables it is
## (`hello`, `step`, `verdict`, `probe`, `value`, `heartbeat`, `log`, `quit`).

const PEER_RUNNER := preload("res://tools/net/peer_runner.gd")
const CONTROL_PORTS := preload("res://tests/helpers/net_control_ports.gd")

const DEFAULT_STEP_BUDGET_FRAMES := 3000
## Contract §8 as amended (`f090076c`): hello and the step phase are budgeted
## SEPARATELY -- a cold Meadows boot is ~85 s per peer (spike S2,
## `ralph/reports/MP-0D-SPIKE-HOSTCOST-0905/`), both booting concurrently on
## one runner, so 180 s covers hello with real margin; the smoke's own STEPS
## get their own 300 s clock starting only once hello is done, so a slow boot
## cannot eat into the budget a smoke's assertions actually need.
const DEFAULT_HELLO_BUDGET_S := 180.0
const DEFAULT_SMOKE_STEP_BUDGET_S_2PEER := 300.0
const DEFAULT_SMOKE_STEP_BUDGET_S_WIDE := 1500.0
const DEFAULT_HEARTBEAT_FRAMES := 60
const DEFAULT_DESYNC_FRAMES := 240
const DEFAULT_NEAR_REST_M := 1.5
const DEFAULT_NEAR_MOTION_M := 4.0
const ENET_BASE_PORT := 27801
## Contract §3: "A peer whose heartbeat stops for 15s wall clock is
## `ERROR: peer silent`".
const HEARTBEAT_SILENT_TIMEOUT_S := 15.0
## A production world-first join may spend one blocking frame rebuilding the
## Meadows (S2 measured ~85 s). Only that named in-flight action gets this
## allowance; its ordinary command deadline remains the harder outer bound.
const PRODUCTION_JOIN_BUILD_ALLOWANCE_S := 90.0
## A realm crossing is the same kind of work: the peer rebuilds a whole world
## scene (crossing back into the Meadows included) in blocking frames, and on
## a slow runner that exceeds the 15 s detector although the peer is working.
## Measured: smoke_net_split_realms went "peer silent" on the return crossing
## on a 4-core container, identically on main and on a lane branch. Only these
## named in-flight actions defer the detector; each step's own deadline stays
## the outer bound. The measured return crossing took 87.8 s and 89.1 s, so a
## crossing gets its own figure with headroom rather than the join's 90 s.
const REALM_CROSSING_BUILD_ALLOWANCE_S := 150.0
const WORLD_BUILD_ALLOWANCE_S := {
	"production_join": PRODUCTION_JOIN_BUILD_ALLOWANCE_S,
	"enter_realm": REALM_CROSSING_BUILD_ALLOWANCE_S,
}
## Contract §6's own budgets are frame-denominated per PEER; the coordinator
## itself only ever waits in wall-clock (it does not tick the peer's physics),
## so every frame budget below is converted at this nominal rate plus a fixed
## slack, matching §3's own "budget_frames (plus 5s of wall clock)" rule.
const NOMINAL_MS_PER_PHYSICS_FRAME := 1000.0 / 60.0
const WALL_SLACK_MS := 5000.0

## The live tolerance, which a smoke may raise BEFORE `launch()`. Fifteen
## seconds is right for a peer that is only ever asked to walk and press
## things: silence that long means it died or hung.
##
## It is wrong for a peer that changes scene AFTER hello.
## `tests/smoke_net_join_by_address.gd`'s joiner reaches the world the way a
## player does -- from the title screen, once the host's snapshot lands -- and
## building the Meadows is ONE blocking frame that spike S2
## (`ralph/reports/MP-0D-SPIKE-HOSTCOST-0905/`) measured at ~85 s. That peer is
## working, not hung, and the detector cannot tell the difference from outside;
## the smoke that knows it is about to happen says so. Every smoke that does
## not touch this keeps §3's number exactly.
##
## `_init_budgets()` deliberately does not reset this: it runs inside
## `launch()`, which is after the only useful moment to set it.
var heartbeat_silence_tolerance_s := HEARTBEAT_SILENT_TIMEOUT_S
## Per-action floors a smoke may set BEFORE `launch()` to lengthen a named
## world-build allowance above WORLD_BUILD_ALLOWANCE_S. Empty by default, so no
## existing smoke changes. The proof runner uses it: a production join that
## builds Cloudreach from the title took ~110 s on a 4-vCPU box (F06#5).
var world_build_allowance_floor_s: Dictionary = {}

var failures: Array[String] = []
var _peers: Array = []
var _run_dir := ""
var _run_id := ""
var _scene_for_run := ""
var _peer_count_for_run := 0
var _budgets := {}
var _next_step_id := 0
## Set once, the first time the run becomes unrecoverable (a peer died
## unexpectedly, went heartbeat-silent, sent an ERROR verdict, produced no
## state hash, or the smoke's own step-phase budget ran out). Every wait loop
## below checks it and bails rather than spinning out its own budget once the
## run is already dead.
var _fatal_reason := ""
## Wall-clock deadline for every STEP the smoke issues after `launch()`'s own
## hello wait succeeds (contract §8 amended, item 9's "enforce the per-smoke
## step wall clock"). 0 until `launch()` sets it.
var _step_phase_deadline_ms := 0.0

## Contract §9. `{delay_ms, jitter_ms, loss_pct}` when this run routes every
## joiner through `tools/net/udp_proxy.gd`, `{}` when it does not.
##
## Set from the environment (`TB_NET_CONDITIONS="delay=150,jitter=30,loss=1"`)
## so ANY existing smoke can be re-run under latency without editing the
## smoke -- which is exactly what lane 7.A needs: the jitter verdict has to be
## the same file's verdict, run twice, or it is not a comparison. A smoke may
## also set `net_conditions` itself before `launch()`.
var net_conditions: Dictionary = {}
## target ENet port -> {pid, listen_port}. One proxy per host port; a run with
## three joiners dialling one host shares one proxy, the way three clients on
## a real link share one link.
var _proxies: Dictionary = {}
var _proxy_listen_next := 0
var _children_terminated := false
var _control_servers: Array = []
## Smoke-owned diagnostic fragments that must not appear in any peer log.
## Register these before a run can take an early finish path; `finish()` scans
## after child teardown so buffered Godot errors are included in the verdict.
var _forbidden_peer_log_checks: Array[Dictionary] = []


## MainLoop's last synchronous teardown seam. Smoke scripts normally call
## `finish()`, but a script error, coordinator failure, or external SIGTERM can
## end the tree before their coroutine reaches it. Killing known child PIDs here
## keeps local/direct harness runs from leaving peer Godot processes behind;
## CI additionally contains the entire runner tree in its own process group so
## hard cancellation does not depend on Godot getting this callback.
func _finalize() -> void:
	_terminate_child_processes()


## `TB_NET_CONDITIONS="delay=150,jitter=30,loss=1"`. Any missing field is 0,
## and an empty/absent variable leaves `net_conditions` exactly as the smoke
## left it, so an explicit in-smoke setting is never silently erased.
func _read_net_conditions_env() -> void:
	var raw := OS.get_environment("TB_NET_CONDITIONS").strip_edges()
	if raw.is_empty():
		return
	var parsed := {}
	for token in raw.split(",", false):
		var pair := str(token).split("=", true, 1)
		if pair.size() != 2:
			continue
		var key := pair[0].strip_edges().to_lower()
		var value := float(pair[1].strip_edges())
		match key:
			"delay", "delay_ms": parsed["delay_ms"] = value
			"jitter", "jitter_ms": parsed["jitter_ms"] = value
			"loss", "loss_pct": parsed["loss_pct"] = value
	if parsed.is_empty():
		return
	net_conditions = {
		"delay_ms": float(parsed.get("delay_ms", 0.0)),
		"jitter_ms": float(parsed.get("jitter_ms", 0.0)),
		"loss_pct": float(parsed.get("loss_pct", 0.0)),
	}


func _init_budgets() -> void:
	_budgets = {
		"step_budget_frames": DEFAULT_STEP_BUDGET_FRAMES,
		"hello_budget_s": DEFAULT_HELLO_BUDGET_S,
		"smoke_step_budget_s_2peer": DEFAULT_SMOKE_STEP_BUDGET_S_2PEER,
		"smoke_step_budget_s_wide": DEFAULT_SMOKE_STEP_BUDGET_S_WIDE,
		"heartbeat_frames": DEFAULT_HEARTBEAT_FRAMES,
		"desync_frames": DEFAULT_DESYNC_FRAMES,
		"near_tolerance_rest_m": DEFAULT_NEAR_REST_M,
		"near_tolerance_motion_m": DEFAULT_NEAR_MOTION_M,
	}
	var cfg_path := "res://data/config/multiplayer.json"
	if not FileAccess.file_exists(cfg_path):
		return
	var f := FileAccess.open(cfg_path, FileAccess.READ)
	if f == null:
		return
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) == TYPE_DICTIONARY and (parsed as Dictionary).has("test_budgets"):
		var tb: Dictionary = (parsed as Dictionary)["test_budgets"]
		for k in tb.keys():
			# `_comment*` keys are this repo's own JSON-doesn't-support-comments
			# convention (see data/config/spawn_tables.json) -- not a budget.
			if str(k).begins_with("_comment"):
				continue
			_budgets[k] = tb[k]


# =====================================================================
# launch()
# =====================================================================

## Starts `peer_count` `tools/net/peer_runner.gd` processes (peer 0 = host,
## every other index = client), each with `--scene=<scene>`, waits for every
## one of them to connect and say `hello`. Returns false (with `failures`
## appended) on any launch problem; a caller that gets false should call
## `finish()` and quit rather than try to drive a peer that never came up.
## `per_peer_args` (lane 2.B) adds tokens to ONE peer's argv, keyed by index,
## on top of `extra_args`, which every peer gets. It exists because a
## command-line flag is fixed at process start: a joiner that reaches the
## session through `--mp-join <host>:<port>` (the path a player and
## `tools/owner/`'s launcher take) has to carry the HOST's port in the argv it
## boots with, which is long before any `hello` could report it -- see
## `enet_port_for()`. Empty by default, so every smoke written before it is
## byte-for-byte unchanged.
func launch(peer_count: int, scene: String, extra_args: Array = [],
		per_peer_args: Dictionary = {}) -> bool:
	_init_budgets()
	_read_net_conditions_env()
	_scene_for_run = scene
	_peer_count_for_run = peer_count

	_run_id = run_id()

	_run_dir = _resolve_run_dir()
	DirAccess.make_dir_recursive_absolute(_run_dir)
	_isolate_coordinator()

	# ENet still needs a predictable port before child argv is built. TCP control
	# ports do not: reserve OS-selected listeners atomically, before any child.
	# A run-id hash is not a reservation and can name an occupied ephemeral port
	# (CI 34236551038 failed on 34022 before peer 1 launched). Exact overrides remain
	# available via TB_NET_CONTROL_BASE/TB_NET_ENET_BASE and fail closed.
	var offset := _port_offset_from_run_id(_run_id)
	var control_base := _env_int("TB_NET_CONTROL_BASE", 0)
	var enet_base := _env_int("TB_NET_ENET_BASE", ENET_BASE_PORT + offset)
	# Contract §9's proxies live inside this run's own port stride (20 wide,
	# see `_port_offset_from_run_id`), above the four ENet ports it can hand
	# out, so a latency run never collides with a concurrent clean one.
	_proxy_listen_next = enet_base + 10
	if not net_conditions.is_empty():
		print("coordinator: net_conditions active -- delay %.0f ms, jitter %.0f ms, loss %.1f%% (contract §9)"
			% [float(net_conditions.get("delay_ms", 0.0)),
			   float(net_conditions.get("jitter_ms", 0.0)),
			   float(net_conditions.get("loss_pct", 0.0))])

	_peers.clear()
	var controls := CONTROL_PORTS.reserve(peer_count, control_base)
	if not bool(controls.ok):
		var why := "coordinator: " + str(controls.reason)
		failures.append(why)
		_fatal_reason = why
		return false
	_control_servers = controls.servers
	for i in peer_count:
		var control_port := int(controls.ports[i])
		var server: TCPServer = _control_servers[i]
		var home := _run_dir.path_join("home-%d" % i)
		DirAccess.make_dir_recursive_absolute(home)
		var role := "host" if i == 0 else "client"
		var log_path := _run_dir.path_join("peer-%d.log" % i)
		var args_for_peer: Array = extra_args.duplicate()
		var mine: Variant = per_peer_args.get(i, [])
		if mine is Array:
			args_for_peer.append_array(mine as Array)
		var pid := _spawn_peer(i, role, control_port, enet_base + i, scene, home, log_path, args_for_peer)
		# `_spawn_peer` points XDG_DATA_HOME/APPDATA at the peer's home for the
		# child; point THIS process back at its own before anything saves.
		_isolate_coordinator()
		if pid <= 0:
			var why2 := "coordinator: OS.create_process failed for peer %d" % i
			failures.append(why2)
			_fatal_reason = why2
			return false
		print("coordinator: launched peer %d (%s) pid=%d control_port=%d home=%s log=%s" %
			[i, role, pid, control_port, home, log_path])
		_peers.append({
			"index": i, "role": role, "server": server, "sock": null, "rx_buf": "",
			"pid": pid, "home": home, "log_path": log_path, "control_port": control_port,
			"hashes": [], "hello": null, "exited": false, "unexpected_exit": false,
			"quit_sent": false, "last_heartbeat_t": 0.0, "last_heartbeat": null,
			"heartbeat_deferred_until_s": 0.0,
			"last_verdict": null, "last_value": null,
		})

	var hello_budget_s: float = float(_budgets.get("hello_budget_s", DEFAULT_HELLO_BUDGET_S))
	var deadline := Time.get_ticks_msec() + hello_budget_s * 1000.0
	while true:
		await process_frame
		_pump_once()
		if not _fatal_reason.is_empty():
			if not failures.has(_fatal_reason):
				failures.append(_fatal_reason)
			return false
		var all_hello := true
		for p in _peers:
			if (p as Dictionary).get("hello") == null:
				all_hello = false
				break
		if all_hello:
			print("coordinator: all %d peer(s) said hello" % peer_count)
			var step_budget_s: float = float(_budgets.get(
				"smoke_step_budget_s_2peer" if peer_count <= 2 else "smoke_step_budget_s_wide",
				DEFAULT_SMOKE_STEP_BUDGET_S_2PEER if peer_count <= 2 else DEFAULT_SMOKE_STEP_BUDGET_S_WIDE))
			_step_phase_deadline_ms = Time.get_ticks_msec() + step_budget_s * 1000.0
			return true
		if Time.get_ticks_msec() > deadline:
			var why3 := "ERROR: not every peer said hello within %.0f s" % hello_budget_s
			failures.append(why3)
			_fatal_reason = why3 # item 1: hello timeout is a harness fault, exit 2
			return false
	return false # unreachable; satisfies static return-path analysis on `while true`


## This run's id, resolved once. `launch()` reads it through here so a smoke
## may ask BEFORE launching -- `enet_port_for()` needs it, and a smoke that
## computed its own would get a different answer every call for a run with no
## TB_NET_RUN_ID in the environment.
func run_id() -> String:
	if _run_id.is_empty():
		_run_id = OS.get_environment("TB_NET_RUN_ID")
		if _run_id.is_empty():
			_run_id = "local-%d" % Time.get_ticks_usec()
	return _run_id


## The ENet port `launch()` WILL hand peer `index`. The same derivation
## `launch()` itself uses, called from one place rather than restated, because
## a second formula here is a smoke that puts a port nothing is listening on
## into a joiner's command line and then reports a join failure that is really
## an arithmetic failure.
func enet_port_for(index: int) -> int:
	return _env_int("TB_NET_ENET_BASE", ENET_BASE_PORT + _port_offset_from_run_id(run_id())) + index


## Item 13 (review): a small, deterministic, bounded offset from the run id so
## concurrent runs land in different port ranges without a human passing
## --port by hand. Stride 20 leaves room for up to 4 peers per run before the
## next run's range begins; modulo 400 keeps the whole span (base..base+8000)
## comfortably inside the ephemeral port range.
func _port_offset_from_run_id(run_id: String) -> int:
	return (absi(hash(run_id)) % 400) * 20


## The coordinator process has its own `Game` autoload. `_spawn_peer` sets
## XDG_DATA_HOME/APPDATA for each child, and those are this process's own env
## vars too: left there, this process's `user://` WAS the last peer's home, and
## its blank Game's fallback autosave (every 180 s, as a session-less "host")
## rewrote that peer's slot_0 with a freshly minted character -- the measured
## cause of a guest rejoining as a blank character (F05 WO4, grant on #221).
## So: a private home under the run dir (never the developer's real one), and
## the coordinator's Game gives up world-save ownership so it never autosaves.
func _isolate_coordinator() -> void:
	var own_home := _run_dir.path_join("home-coordinator")
	DirAccess.make_dir_recursive_absolute(own_home)
	OS.set_environment("XDG_DATA_HOME", own_home)
	if _is_windows():
		OS.set_environment("APPDATA", own_home)
	var game := root.get_node_or_null(^"Game")
	if game != null and game.has_method("relinquish_world_save_ownership"):
		game.call("relinquish_world_save_ownership")


func _spawn_peer(i: int, role: String, control_port: int, enet_port: int, scene: String,
		home: String, log_path: String, extra_args: Array) -> int:
	var exe := OS.get_executable_path()
	var project_path := ProjectSettings.globalize_path("res://")
	var args := [
		"--headless", "--path", project_path,
	]
	if _is_windows():
		# Godot 4.7 has no --user-data-dir command line option. On Windows its
		# supported user-data lookup honors APPDATA, so set a fresh APPDATA root
		# before creating this child. The peer's OS.get_user_data_dir() is then
		# `<home>/Godot/app_userdata/Tetherbound`, before Game can touch user://.
		# `--log-file` keeps the returned PID attached to Godot, never a wrapper.
		args.append_array(["--log-file", log_path])
	args.append_array([
		"--script", "res://tools/net/peer_runner.gd", "--",
		"--role=%s" % role, "--peer=%d" % i,
		"--control-port=%d" % control_port, "--enet-port=%d" % enet_port,
		"--scene=%s" % scene,
		# A literal argv token, not only an env var: `run_net_smoke.sh`'s
		# orphan sweep uses `pgrep -f "TB_NET_RUN_ID=<id>"`, and `pgrep -f`
		# matches a process's COMMAND LINE, not its environment.
		"TB_NET_RUN_ID=%s" % _run_id,
	])
	for extra in extra_args:
		args.append(str(extra))
	# Spike item 6: OS.set_environment() before OS.create_process() reaches the
	# child. Isolation per peer (contract §2): its own XDG_DATA_HOME.
	OS.set_environment("XDG_DATA_HOME", home)
	if _is_windows():
		OS.set_environment("APPDATA", home)
	OS.set_environment("TB_NET_RUN_ID", _run_id)
	# `data/config/spawn_tables.json`'s `roll_new_worlds` ships true (owner
	# directive D-0830-1), so a fresh New Game rolls itself a random
	# `world_seed` unless pinned -- exactly the reason
	# `tools/gate_f/operator_harness.gd::_pin_world_seed()` exists. Two
	# independently-booted peers with no Session to negotiate a shared seed
	# yet (contract §1) would otherwise disagree on their very first
	# heartbeat for a reason that has nothing to do with the harness: measured
	# live before this line existed (490178442 vs 736055304, one `world_seed`
	# key, nothing else). Every peer in a run is pinned to the SAME value --
	# the authored world, seed 0, matching Gate F's own default -- so the
	# desync detector is proving what contract §1 says Wave 0 can prove
	# ("two Meadows worlds ... prove the instrument"), not failing on a
	# divergence Wave 2's Session is what will actually fix.
	OS.set_environment("TB_WORLD_SEED", OS.get_environment("TB_NET_WORLD_SEED") if not OS.get_environment("TB_NET_WORLD_SEED").is_empty() else "0")
	if _is_windows():
		return OS.create_process(exe, args)
	var parts: Array[String] = [_shq(exe)]
	for a in args:
		parts.append(_shq(str(a)))
	# `exec` replaces the /bin/sh process image with godot IN PLACE (same
	# pid), rather than forking godot as sh's child and waiting on it. Without
	# it, the pid OS.create_process() returns is the SHELL's, and
	# OS.kill()/OS.is_process_running() on it would only ever touch the shell
	# -- leaving the real godot process an orphan, reparented to init, exactly
	# the leak this run's own zombie guard (`tools/net/run_net_smoke.sh`'s
	# `pgrep -f "TB_NET_RUN_ID=..."` sweep) would otherwise have to paper
	# over silently. With `exec`, the coordinator's own pid bookkeeping is
	# correct on its own.
	var shell_cmd := "exec %s >%s 2>&1" % [" ".join(parts), _shq(log_path)]
	return OS.create_process("/bin/sh", ["-c", shell_cmd])


func _shq(s: String) -> String:
	return "'" + s.replace("'", "'\\''") + "'"


func _env_int(name: String, default: int) -> int:
	var v := OS.get_environment(name)
	return int(v) if not v.is_empty() else default


func _resolve_run_dir() -> String:
	var out := OS.get_environment("TB_NET_OUT_DIR")
	if not out.is_empty():
		return out
	# Item 13 (review): the fallback default (no run_net_smoke.sh, which
	# always sets TB_NET_OUT_DIR itself) folds `_run_id` in too -- two bare
	# invocations in the same wall-clock second used to collide on the
	# timestamp alone; `_run_id` is already unique per invocation (env or the
	# microsecond fallback above it).
	var safe_id := _run_id.replace("/", "_").replace(":", "_").replace(" ", "_")
	if _is_windows():
		return OS.get_user_data_dir().path_join("net-runs").path_join("net-run-%s" % safe_id)
	return "/tmp/net-run-%s" % safe_id


func _is_windows() -> bool:
	return OS.get_name() == "Windows"


# =====================================================================
# control-channel pump -- runs opportunistically every time anything below
# awaits a frame, servicing every peer's socket (accept, read, dispatch).
# =====================================================================

## Item 9 (review): the smoke's own step-phase wall clock (contract §8
## amended), enforced in ONE place -- `_pump_once()` runs inside every wait
## loop in this file (`step`, `probe`, `race`, `assert_all_hashes_equal`,
## `expect_desync_free`), so checking it here covers all of them without a
## duplicate deadline check in each.
func _check_step_budget() -> void:
	if _step_phase_deadline_ms <= 0.0 or not _fatal_reason.is_empty():
		return
	if Time.get_ticks_msec() > _step_phase_deadline_ms:
		_fatal_reason = "ERROR: smoke budget exceeded"
		print("coordinator: %s" % _fatal_reason)


func _pump_once() -> void:
	_check_step_budget()
	for entry in _peers:
		var p: Dictionary = entry
		if bool(p.get("exited", false)):
			continue
		var server: TCPServer = p.get("server")
		if server != null and p.get("sock") == null and server.is_connection_available():
			p["sock"] = server.take_connection()
		var sock: StreamPeerTCP = p.get("sock")
		if sock != null:
			sock.poll()
			if sock.get_status() == StreamPeerTCP.STATUS_CONNECTED:
				var n := sock.get_available_bytes()
				if n > 0:
					var res: Array = sock.get_data(n)
					if int(res[0]) == OK:
						p["rx_buf"] = str(p.get("rx_buf", "")) + (res[1] as PackedByteArray).get_string_from_utf8()
				while true:
					var buf: String = str(p.get("rx_buf", ""))
					var idx := buf.find("\n")
					if idx < 0:
						break
					var line := buf.substr(0, idx)
					p["rx_buf"] = buf.substr(idx + 1)
					_handle_peer_line(p, line)
		_check_liveness(p)


func _handle_peer_line(p: Dictionary, line: String) -> void:
	var msg = JSON.parse_string(line)
	if typeof(msg) != TYPE_DICTIONARY:
		return
	var kind := str((msg as Dictionary).get("type", ""))
	match kind:
		"hello":
			p["hello"] = msg
			# Item 10 (review): the reference point a silence check needs
			# BEFORE the first heartbeat has ever arrived -- `last_heartbeat_t`
			# stays 0.0 until then, and a peer that said hello and then never
			# heartbeats at all must still trip the 15 s guard.
			p["hello_at"] = Time.get_ticks_msec() / 1000.0
			print("coordinator: peer %d hello: %s" % [int(p["index"]), JSON.stringify(msg)])
		"verdict":
			p["last_verdict"] = msg
			# Item 1 (review): an ERROR verdict from a peer is a harness fault
			# per contract §4 ("stops the run"), not a check the caller can
			# choose to treat as a mere FAIL -- so this sets `_fatal_reason`
			# itself, independent of whatever `step()`'s own caller does with
			# the returned Dictionary.
			if str((msg as Dictionary).get("verdict", "")) == "ERROR":
				var why := "ERROR: peer %d reported ERROR: %s" % [int(p["index"]), str((msg as Dictionary).get("detail", ""))]
				print("coordinator: %s" % why)
				if _fatal_reason.is_empty():
					_fatal_reason = why
		"value":
			p["last_value"] = msg
		"heartbeat":
			p["last_heartbeat_t"] = Time.get_ticks_msec() / 1000.0
			p["last_heartbeat"] = msg
			# Item 2 (review): `null` means the peer could not produce a hash
			# at all (peer_runner.gd::_compute_state_hash's own contract) --
			# never coerce that into the legal hash value 0. A missing key
			# (an old peer build, or a malformed message) is treated the same
			# way: absence is not zero either.
			if not (msg as Dictionary).has("state_hash") or (msg as Dictionary)["state_hash"] == null:
				var why2 := "ERROR: state hash unavailable (peer %d)" % int(p["index"])
				print("coordinator: %s" % why2)
				if _fatal_reason.is_empty():
					_fatal_reason = why2
			else:
				var hashes: Array = p.get("hashes", [])
				hashes.append(int((msg as Dictionary)["state_hash"]))
				while hashes.size() > 3:
					hashes.pop_front()
				p["hashes"] = hashes
		"log":
			print("peer[%d] log[%s]: %s" % [int(p["index"]), str((msg as Dictionary).get("level", "")),
				str((msg as Dictionary).get("text", ""))])
		_:
			print("coordinator: peer %d sent unknown message type '%s'" % [int(p["index"]), kind])


func _check_liveness(p: Dictionary) -> void:
	var pid := int(p.get("pid", -1))
	if pid > 0 and not bool(p.get("exited", false)) and not OS.is_process_running(pid):
		p["exited"] = true
		if not bool(p.get("quit_sent", false)):
			p["unexpected_exit"] = true
			# Contract §3's own wording is `ERROR: peer exited <code>`. This
			# harness cannot recover a real exit code for a child launched
			# via `OS.create_process` and reaped only by polling
			# `OS.is_process_running` (no waitpid-style status here) -- see
			# the lane report's limitations section. The peer index stands in
			# for the code; "peer exited" is kept verbatim so a caller
			# matching on that substring (this repo's own negative control,
			# `tests/smoke_net_peer_death.gd`) still finds it.
			var reason := "ERROR: peer exited (peer %d, pid %d)" % [int(p["index"]), pid]
			print("coordinator: %s" % reason)
			if _fatal_reason.is_empty():
				_fatal_reason = reason
	if bool(p.get("hello") != null) and not bool(p.get("exited", false)):
		var last: float = float(p.get("last_heartbeat_t", 0.0))
		# Item 10 (review): `last > 0.0` alone means a peer that said hello and
		# then NEVER heartbeated at all (last_heartbeat_t stays its 0.0
		# default forever) can never trip this guard -- it would just sit
		# silently until whatever OUTER budget eventually times the run out,
		# reporting the wrong reason. Fall back to `hello_at` as the reference
		# point when no heartbeat has ever arrived.
		var reference: float = last if last > 0.0 else float(p.get("hello_at", 0.0))
		var now_s := Time.get_ticks_msec() / 1000.0
		var deferred_until_s := float(p.get("heartbeat_deferred_until_s", 0.0))
		if reference > 0.0 and heartbeat_is_silent(now_s, reference, deferred_until_s,
				heartbeat_silence_tolerance_s):
			var reason2 := "ERROR: peer silent (peer %d, no heartbeat for >%.0f s)" % [int(p["index"]), heartbeat_silence_tolerance_s]
			if _fatal_reason.is_empty():
				_fatal_reason = reason2
				print("coordinator: %s" % reason2)


## Pure so the reconnect smoke can prove that the named allowance postpones
## the guard only until its deadline, then the ordinary 15-second rule wins.
static func heartbeat_is_silent(now_s: float, reference_s: float,
		deferred_until_s: float, tolerance_s: float) -> bool:
	return now_s > deferred_until_s and now_s - reference_s > tolerance_s


func _send_to(p: Dictionary, msg: Dictionary) -> void:
	var sock: StreamPeerTCP = p.get("sock")
	if sock == null:
		return
	sock.poll()
	if sock.get_status() != StreamPeerTCP.STATUS_CONNECTED:
		return
	sock.put_data((JSON.stringify(msg) + "\n").to_utf8_buffer())


# =====================================================================
# Coordinator API (contract §6)
# =====================================================================

## One step, on one peer; awaits its `verdict`. `budget` in physics frames
## (contract §4 default 3000) -- converted to the wall-clock bound the
## coordinator itself can actually wait on (contract §3: "budget_frames plus
## 5s of wall clock").
## Start (or reuse) a `tools/net/udp_proxy.gd` in front of `target_port` and
## return the port a joiner should dial instead. 0 if it could not be started.
##
## The proxy is a separate headless process for the same reason the peers are:
## it must keep pumping while the coordinator is blocked, and a coordinator
## that relayed packets from inside its own `_pump_once()` would inject its own
## scheduling into the very thing it is measuring.
func _proxy_for(target_port: int) -> int:
	if _proxies.has(target_port):
		return int((_proxies[target_port] as Dictionary).get("listen_port", 0))
	var listen_port := _proxy_listen_next
	_proxy_listen_next += 1
	var exe := OS.get_executable_path()
	var args := [
		"--headless", "--path", ProjectSettings.globalize_path("res://"),
	]
	var log_path := _run_dir.path_join("udp-proxy-%d.log" % listen_port)
	if _is_windows():
		args.append_array(["--log-file", log_path])
	args.append_array([
		"--script", "res://tools/net/udp_proxy.gd", "--",
		"--listen-port=%d" % listen_port,
		"--target-host=127.0.0.1", "--target-port=%d" % target_port,
		"--delay-ms=%.0f" % float(net_conditions.get("delay_ms", 0.0)),
		"--jitter-ms=%.0f" % float(net_conditions.get("jitter_ms", 0.0)),
		"--loss-pct=%.2f" % float(net_conditions.get("loss_pct", 0.0)),
		# Same literal argv token every peer carries, so `run_net_smoke.sh`'s
		# `pgrep -f "TB_NET_RUN_ID=<id>"` sweep reaps the proxy too.
		"TB_NET_RUN_ID=%s" % _run_id,
	])
	var pid := 0
	if _is_windows():
		pid = OS.create_process(exe, args)
	else:
		var parts: Array[String] = [_shq(exe)]
		for a in args:
			parts.append(_shq(str(a)))
		pid = OS.create_process("/bin/sh", ["-c",
			"exec %s >%s 2>&1" % [" ".join(parts), _shq(log_path)]])
	if pid <= 0:
		return 0
	_proxies[target_port] = {"pid": pid, "listen_port": listen_port, "log": log_path}
	print("coordinator: udp_proxy pid=%d relaying 127.0.0.1:%d -> 127.0.0.1:%d (log %s)"
		% [pid, listen_port, target_port, log_path])
	# Wait for the bind rather than assuming it. A second headless Godot takes
	# a second or two to reach `_initialize()`, and a joiner that starts
	# dialling a port nothing is listening on yet is relying on ENet's connect
	# retries to cover a startup race -- which works right up until the box is
	# loaded and it does not, and the failure reads as "the join timed out"
	# rather than "the proxy was not up".
	#
	# The probe is a bind attempt from here: while the port is free THIS
	# process can take it, and the frame it cannot is the frame the proxy has
	# it. The socket is closed immediately either way.
	var deadline := Time.get_ticks_msec() + 15000
	while Time.get_ticks_msec() < deadline:
		var probe_sock := PacketPeerUDP.new()
		var free := probe_sock.bind(listen_port) == OK
		probe_sock.close()
		if not free:
			print("coordinator: udp_proxy bound udp/%d" % listen_port)
			return listen_port
		await process_frame
		_pump_once()
	print("coordinator: udp_proxy never bound udp/%d within 15 s; see %s" % [listen_port, log_path])
	return 0


func step(peer: int, action: String, args := {}, budget: int = -1) -> Dictionary:
	if budget < 0:
		budget = int(_budgets.get("step_budget_frames", DEFAULT_STEP_BUDGET_FRAMES))
	# Contract §9: "Clients join the proxy port instead of the host's."
	# Interposed HERE rather than by rewriting the host's `hello` -- every
	# smoke reads `hello.enet_port` for BOTH the `host` step's bind and the
	# `join` step's dial, so a rewritten hello would put the proxy's port
	# under the listen server and there would be nothing to forward to.
	# Rewriting only the join argument leaves every existing smoke correct
	# under latency with no edit to the smoke.
	if action in ["join", "production_join"] and not net_conditions.is_empty():
		args = (args as Dictionary).duplicate(true)
		var target := int(args.get("port", 0))
		if target > 0:
			var listen := await _proxy_for(target)
			if listen > 0:
				args["port"] = listen
			else:
				_fatal_reason = "ERROR: could not start udp_proxy for target port %d" % target
	var p: Dictionary = _peers[peer]
	var id := "s%d" % _next_step_id
	_next_step_id += 1
	p["last_verdict"] = null
	var build_allowance_s := maxf(world_build_allowance_s(action),
		float(world_build_allowance_floor_s.get(action, 0.0)))
	if build_allowance_s > 0.0:
		p["heartbeat_deferred_until_s"] = Time.get_ticks_msec() / 1000.0 + build_allowance_s
	_send_to(p, {"type": "step", "id": id, "action": action, "args": args, "budget_frames": budget})
	var deadline := Time.get_ticks_msec() + float(budget) * NOMINAL_MS_PER_PHYSICS_FRAME + WALL_SLACK_MS
	while true:
		await process_frame
		_pump_once()
		var v = p.get("last_verdict")
		if v != null and str((v as Dictionary).get("id", "")) == id:
			_complete_step_heartbeat_allowance(p, action, v as Dictionary,
				Time.get_ticks_msec() / 1000.0)
			return v
		if not _fatal_reason.is_empty():
			p["heartbeat_deferred_until_s"] = 0.0
			return {"id": id, "verdict": "ERROR", "detail": _fatal_reason, "frames_used": 0}
		if bool(p.get("exited", false)):
			p["heartbeat_deferred_until_s"] = 0.0
			return {"id": id, "verdict": "ERROR", "detail": "peer %d exited before a verdict for '%s'"
				% [peer, action], "frames_used": 0}
		if Time.get_ticks_msec() > deadline:
			p["heartbeat_deferred_until_s"] = 0.0
			return {"id": id, "verdict": "FAIL", "detail": "no verdict", "frames_used": 0}
	return {} # unreachable; satisfies static return-path analysis on `while true`


## Seconds a named world-building step may run without heartbeats, or 0.
static func world_build_allowance_s(action: String) -> float:
	return float(WORLD_BUILD_ALLOWANCE_S.get(action, 0.0))


## End the named world-build allowance when its real step verdict arrives.
## A successful world-building step (production join or realm crossing) is
## itself fresh proof that the peer's control loop returned from the build, so the ordinary 15-second watchdog starts at
## that completion rather than at the last heartbeat sent before the build.
## FAIL/ERROR verdicts and unrelated actions do not receive that liveness
## credit; all completion paths still remove any in-flight allowance.
static func _complete_step_heartbeat_allowance(p: Dictionary, action: String,
		verdict: Dictionary, completed_at_s: float) -> void:
	if world_build_allowance_s(action) > 0.0 and str(verdict.get("verdict", "")) == "PASS":
		p["last_heartbeat_t"] = completed_at_s
	p["heartbeat_deferred_until_s"] = 0.0


## Runs `list` (each `{action, args, budget_frames}`) sequentially on `peer`.
func steps(peer: int, list: Array) -> Array:
	var out: Array = []
	for item in list:
		var d: Dictionary = item
		var budget := int(d["budget_frames"]) if d.has("budget_frames") else -1
		out.append(await step(peer, str(d.get("action", "")), d.get("args", {}), budget))
	return out


## `list` of `{peer, action, args, budget_frames}` issued in ONE coordinator
## frame -- contract §6's honest limit: proves "no duplication regardless of
## order", not true simultaneity (that needs the pure ledger/arbiter unit
## tests named in the contract). Returns `[{peer, verdict}, ...]` once every
## entry has a verdict or the shared deadline passes.
func race(list: Array) -> Array:
	# Item 11 (review): `p["last_verdict"]` is ONE slot per peer, not a queue
	# keyed by step id -- two entries addressing the SAME peer in one race can
	# have the second verdict overwrite the first before this function ever
	# observes it, silently losing a verdict rather than mismatching one.
	# Rejected as a harness ERROR until verdicts are tracked per id (contract
	# §6's own carry-over, not this lane's to fix here).
	var seen_peers := {}
	for item0 in list:
		var peer_idx0 := int((item0 as Dictionary).get("peer"))
		if seen_peers.has(peer_idx0):
			var why := "ERROR: race() cannot address peer %d twice in one call until verdicts are keyed by id" % peer_idx0
			print("coordinator: %s" % why)
			if _fatal_reason.is_empty():
				_fatal_reason = why
			var err_out: Array = []
			for item1 in list:
				err_out.append({"peer": (item1 as Dictionary).get("peer"),
					"verdict": {"verdict": "ERROR", "detail": why}})
			return err_out
		seen_peers[peer_idx0] = true

	var ids: Array = []
	var default_budget := int(_budgets.get("step_budget_frames", DEFAULT_STEP_BUDGET_FRAMES))
	var max_budget := default_budget
	for item in list:
		var d: Dictionary = item
		var peer_idx := int(d.get("peer"))
		var p: Dictionary = _peers[peer_idx]
		var id := "r%d" % _next_step_id
		_next_step_id += 1
		var budget := int(d.get("budget_frames", default_budget))
		max_budget = maxi(max_budget, budget)
		p["last_verdict"] = null
		_send_to(p, {"type": "step", "id": id, "action": str(d.get("action", "")),
			"args": d.get("args", {}), "budget_frames": budget})
		ids.append({"peer": peer_idx, "id": id})
	var out: Array = []
	var seen := {}
	var deadline := Time.get_ticks_msec() + float(max_budget) * NOMINAL_MS_PER_PHYSICS_FRAME + WALL_SLACK_MS
	while out.size() < ids.size():
		await process_frame
		_pump_once()
		for entry in ids:
			var key: String = str(entry["id"])
			if seen.has(key):
				continue
			var p2: Dictionary = _peers[int(entry["peer"])]
			var v = p2.get("last_verdict")
			if v != null and str((v as Dictionary).get("id", "")) == key:
				seen[key] = true
				out.append({"peer": entry["peer"], "verdict": v})
		if not _fatal_reason.is_empty() or Time.get_ticks_msec() > deadline:
			for entry in ids:
				var key2: String = str(entry["id"])
				if not seen.has(key2):
					seen[key2] = true
					out.append({"peer": entry["peer"],
						"verdict": {"verdict": "ERROR", "detail": _fatal_reason if not _fatal_reason.is_empty() else "no verdict"}})
			break
	return out


## Reads `what` off `peer` (contract §5) and returns its `value`.
func probe(peer: int, what: String, args := {}) -> Variant:
	var p: Dictionary = _peers[peer]
	var id := "p%d" % _next_step_id
	_next_step_id += 1
	p["last_value"] = null
	_send_to(p, {"type": "probe", "id": id, "what": what, "args": args})
	var deadline := Time.get_ticks_msec() + 20000.0
	while true:
		await process_frame
		_pump_once()
		var v = p.get("last_value")
		if v != null and str((v as Dictionary).get("id", "")) == id:
			return (v as Dictionary).get("value")
		if not _fatal_reason.is_empty() or bool(p.get("exited", false)):
			return null
		if Time.get_ticks_msec() > deadline:
			return null
	return null # unreachable; satisfies static return-path analysis on `while true`


## Contract §7: true once a hash appears in every peer's last-three-heartbeat
## window within `budget_frames` (converted to wall clock as `step()` does).
func assert_all_hashes_equal(budget_frames: int = 300) -> bool:
	var deadline := Time.get_ticks_msec() + float(budget_frames) * NOMINAL_MS_PER_PHYSICS_FRAME + WALL_SLACK_MS
	while Time.get_ticks_msec() < deadline:
		await process_frame
		_pump_once()
		if not _fatal_reason.is_empty():
			failures.append("state hash check aborted: %s" % _fatal_reason)
			return false
		if _hashes_agree():
			return true
	failures.append("state hashes never agreed across peers within %d frames" % budget_frames)
	_dump_desync()
	return false


func _hashes_agree() -> bool:
	if _peers.is_empty():
		return false
	var windows: Array = []
	for entry in _peers:
		var p: Dictionary = entry
		var h: Array = p.get("hashes", [])
		if h.is_empty():
			return false
		windows.append(h)
	var first: Array = windows[0]
	for h in first:
		var common := true
		for w in windows:
			if not (w as Array).has(h):
				common = false
				break
		if common:
			return true
	return false


## Contract §7: watches for `seconds` of real play; a divergence sustained for
## `desync_frames` (config, default 240) fails. Returns true if no such
## sustained divergence occurred.
func expect_desync_free(seconds: float) -> bool:
	var frames := int(round(seconds * 60.0))
	var divergent_frames := 0
	var desync_ceiling := int(_budgets.get("desync_frames", DEFAULT_DESYNC_FRAMES))
	for i in frames:
		await process_frame
		_pump_once()
		if not _fatal_reason.is_empty():
			failures.append("desync watch aborted: %s" % _fatal_reason)
			return false
		if _hashes_agree():
			divergent_frames = 0
		else:
			divergent_frames += 1
			if divergent_frames >= desync_ceiling:
				failures.append("desync: no common state_hash across peers for %d consecutive frames" % divergent_frames)
				_dump_desync()
				return false
	return true


## Contract §7: on a confirmed divergence, dump each peer's own state so the
## diff is in the evidence. Wave 0's `peer_runner.gd` does not yet implement
## the `save_dict` probe (only `position`/`input_context`/`state_hash`/
## `session` -- item 1's minimum), so this records the hash windows that
## proved the divergence instead of a full dictionary diff; noted as a
## limitation in the lane report.
func _dump_desync() -> void:
	var doc := {"run_id": _run_id, "peers": []}
	for entry in _peers:
		var p: Dictionary = entry
		(doc["peers"] as Array).append({"index": p.get("index"), "hashes": p.get("hashes", []),
			"last_heartbeat": p.get("last_heartbeat")})
	var f := FileAccess.open(_run_dir.path_join("desync.json"), FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(doc, "\t"))
		f.close()


func check(condition: bool, message: String) -> void:
	if not condition:
		failures.append(message)
	print(("PASS: " if condition else "FAIL: ") + message)


func require_peer_logs_without(patterns: Array, label: String) -> void:
	_forbidden_peer_log_checks.append({
		"patterns": patterns.duplicate(),
		"label": label,
	})


func _check_forbidden_peer_logs() -> void:
	for requested: Dictionary in _forbidden_peer_log_checks:
		var matches := 0
		var details: Array[String] = []
		for entry in _peers:
			var peer: Dictionary = entry
			var path := str(peer.get("log_path", ""))
			var log_file := FileAccess.open(path, FileAccess.READ)
			if log_file == null:
				matches += 1
				details.append("peer %s log unavailable" % str(peer.get("index", "?")))
				continue
			var contents := log_file.get_as_text()
			log_file.close()
			for pattern_value in requested.get("patterns", []):
				var pattern := str(pattern_value)
				var count := contents.count(pattern)
				if count > 0:
					matches += count
					details.append("peer %s: %s x%d" % [
						str(peer.get("index", "?")), pattern, count])
		var label := str(requested.get("label", "peer logs contain no forbidden diagnostics"))
		check(matches == 0, "%s%s" % [label,
			"" if details.is_empty() else " (%s)" % "; ".join(details)])


## Sends `quit` to every still-connected peer, waits (briefly) for clean exit,
## kills stragglers, writes NET_RUN.json/SUMMARY.md, and returns the exit code
## (contract §6): 2 if the run died on a harness fault (a peer exited
## unexpectedly, or went silent), 1 if any `check`/assert failed, else 0.
func finish() -> int:
	for entry in _peers:
		var p: Dictionary = entry
		if not bool(p.get("exited", false)):
			p["quit_sent"] = true
			_send_to(p, {"type": "quit", "code": 0})
	var deadline := Time.get_ticks_msec() + 5000
	while Time.get_ticks_msec() < deadline:
		await process_frame
		_pump_once()
		var all_exited := true
		for entry2 in _peers:
			if not bool((entry2 as Dictionary).get("exited", false)):
				all_exited = false
				break
		if all_exited:
			break
	_terminate_child_processes()
	_check_forbidden_peer_logs()

	_write_run_json()
	_write_summary()

	if not _fatal_reason.is_empty():
		if not failures.has(_fatal_reason):
			failures.append(_fatal_reason)
		print("FAIL: %s" % _fatal_reason)
		return 2
	if not failures.is_empty():
		for f in failures:
			print("FAIL: %s" % f)
		return 1
	print("ALL CHECKS PASSED")
	return 0


func _terminate_child_processes() -> void:
	if _children_terminated:
		return
	_children_terminated = true
	CONTROL_PORTS.release(_control_servers)
	for entry in _peers:
		var peer: Dictionary = entry
		var pid := int(peer.get("pid", -1))
		if pid > 0 and OS.is_process_running(pid):
			OS.kill(pid)
	for key in _proxies.keys():
		var proxy: Dictionary = _proxies[key]
		var proxy_pid := int(proxy.get("pid", -1))
		if proxy_pid > 0 and OS.is_process_running(proxy_pid):
			OS.kill(proxy_pid)


func _write_run_json() -> void:
	var peers_out := []
	for entry in _peers:
		var p: Dictionary = entry
		peers_out.append({
			"index": p.get("index"), "role": p.get("role"), "pid": p.get("pid"),
			"control_port": p.get("control_port"), "hello": p.get("hello"),
			"exited": p.get("exited"), "unexpected_exit": p.get("unexpected_exit"),
			"last_heartbeat": p.get("last_heartbeat"), "hashes": p.get("hashes", []),
		})
	var doc := {
		"run_id": _run_id, "scene": _scene_for_run, "peers": peers_out,
		"failures": failures, "fatal": _fatal_reason,
		# Contract §7 as amended (`f090076c`): one key, the allowlist actually
		# hashed. `EXCLUDED_KEYS` is printed alongside it as the record of
		# what was deliberately left out, not a second mechanism.
		"state_hash_hashed_keys": PEER_RUNNER.HASHED_KEYS,
		"state_hash_excluded_keys": PEER_RUNNER.EXCLUDED_KEYS,
		"budgets": _budgets,
		# Contract §9: the jitter verdict is only comparable to the clean one
		# if the run says which it was. `{}` is the clean run.
		"net_conditions": net_conditions,
		"proxies": _proxies.values(),
	}
	var f := FileAccess.open(_run_dir.path_join("NET_RUN.json"), FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(doc, "\t"))
		f.close()


func _write_summary() -> void:
	var lines := ["# Net smoke run %s" % _run_id, "", "Scene: %s" % _scene_for_run,
		"Peers: %d" % _peers.size(),
		"Net conditions: %s" % ("clean (no proxy)" if net_conditions.is_empty()
			else "delay %.0f ms / jitter %.0f ms / loss %.1f%%" % [
				float(net_conditions.get("delay_ms", 0.0)),
				float(net_conditions.get("jitter_ms", 0.0)),
				float(net_conditions.get("loss_pct", 0.0))]),
		""]
	for entry in _peers:
		var p: Dictionary = entry
		lines.append("- peer %d (%s) pid=%s exited=%s unexpected_exit=%s" % [
			p.get("index"), p.get("role"), str(p.get("pid")), str(p.get("exited")),
			str(p.get("unexpected_exit"))])
	lines.append("")
	if not _fatal_reason.is_empty():
		lines.append("FATAL: %s" % _fatal_reason)
	elif failures.is_empty():
		lines.append("ALL CHECKS PASSED")
	else:
		lines.append("FAILURES:")
		for f2 in failures:
			lines.append("- %s" % f2)
	var f := FileAccess.open(_run_dir.path_join("SUMMARY.md"), FileAccess.WRITE)
	if f:
		f.store_string("\n".join(lines) + "\n")
		f.close()
