"""Bounded R4 metadata proof. Execute only after ROOT/independent source gate.

Never launches Godot, rewrites inputs, or changes the original smoke verdict.
The caller must supply the independently reviewed input-manifest SHA256.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import time

HEAD = "784b5cee71a4ba42b7fd6b5b3b39bea76b67910e"
R4 = "0485c7b7337ad2a239e9f591ebf9acafac7c32082e28bd43603e1e8868f6d390"
PEER = "1446618f362bc9a0f020cf542837692e08c4ccf1b8ea0c41277f2a73f3c38451"
HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parent
MAX_SECONDS = 180
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TOTAL_READ_BYTES = 512 * 1024 * 1024
MAX_FILES = 256
MAX_VALUE_NODES = 3000000
ARCH_IDS = ("home", "tidewake", "cloudreach", "stormwood", "biome5", "biome6", "biome7", "biome8")
BIOMES = ("meadows",) + ARCH_IDS[1:]
LIMITS = [
    "Headless same-OS ENet/LAN loopback and scene rebuild, not process/OS restart.",
    "Only lawful fresh home-open/live-locked/reserved-sealed arches and empty shrines.",
    "Unattended title identity confirmations and title Load continuation; no normal UI/controller or Steam/invite proof.",
    "Producer metadata is not a rendered/code-blind visual or hung-relic proof; F18/F19 mutable states unproved.",
    "Four host ENet errors remain unresolved; no harmless-baseline classification, transport-clean/F49 remain OPEN.",
    "Serialized negative World RefCounted instance values exceed exact JSON/binary64 identity precision; no exact identity claim for them.",
    "R4 whole smoke remains FAIL/native2/budget. R5 source is unexecuted; no smoke assertion or timer is waived.",
    "Separate metadata proof requires independent acceptance/packaging/main-source equivalence; no automatic criterion/status edits.",
]


class Refusal(Exception):
    pass


def require(condition, reason):
    if not condition:
        raise Refusal(reason)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, "duplicate JSON object key")
            out[key] = value
        return out
    def constant(value):
        raise Refusal("nonfinite JSON constant: " + value)
    return json.loads(raw.decode("utf-8", errors="strict"), object_pairs_hook=pairs, parse_constant=constant)


def exact_integer(value, minimum=0):
    require(type(value) in (int, float), "identity/revision is not a JSON number")
    require(math.isfinite(value) and minimum <= value < 2**53 and value == int(value),
            "identity/revision outside exact nonnegative integer range")
    return int(value)


def contained(base, value):
    path = Path(value).resolve()
    require(path.is_relative_to(base.resolve()), "path escapes pinned input root")
    return path


class FrozenReads:
    def __init__(self):
        self.deadline = time.monotonic() + MAX_SECONDS
        self.total = 0
        self.files = {}

    def budget(self):
        require(time.monotonic() <= self.deadline, "standalone metadata budget exceeded")

    def raw(self, path):
        self.budget()
        path = Path(path).resolve()
        if path in self.files:
            return self.files[path][0]
        require(len(self.files) < MAX_FILES, "metadata file-count bound exceeded")
        stat = path.stat()
        require(path.is_file() and stat.st_size <= MAX_FILE_BYTES, "metadata file-size bound exceeded")
        raw = path.read_bytes()
        self.total += len(raw)
        require(self.total <= MAX_TOTAL_READ_BYTES, "metadata byte-read bound exceeded")
        after = path.stat()
        require((stat.st_size, stat.st_mtime_ns, stat.st_ino, stat.st_dev) ==
                (after.st_size, after.st_mtime_ns, after.st_ino, after.st_dev), "input changed during read")
        require(len(raw) == stat.st_size, "input size changed during read")
        self.files[path] = (raw, digest(raw))  # One SHA per canonical file, including each resource.
        self.budget()
        return raw

    def match(self, path, wanted):
        require(type(wanted) is str and re.fullmatch("[0-9a-f]{64}", wanted), "invalid expected SHA256")
        raw = self.raw(path)
        require(self.files[Path(path).resolve()][1] == wanted, "SHA256 mismatch: " + str(path))
        return raw

    def unchanged(self):
        # Compare final bytes, without hashing resources a second time.
        for path, (before, _) in self.files.items():
            self.budget()
            require(path.stat().st_size <= MAX_FILE_BYTES, "final input size bound exceeded")
            after = path.read_bytes()
            self.total += len(after)
            require(self.total <= MAX_TOTAL_READ_BYTES, "final byte-read bound exceeded")
            require(after == before, "source/input/resource drift: " + str(path))
        self.budget()


def prove(manifest_sha):
    reads = FrozenReads()
    manifest = json_bytes(reads.match(HERE / "input-manifest.json", manifest_sha))
    require(manifest["schema"] == "hall-r4-metadata-finalizer-v1", "wrong manifest schema")
    require(manifest["source_head"] == HEAD and manifest["r4_sha256"] == R4 and
            manifest["peer_sha256"] == PEER, "wrong fixed R4 source pins")
    reads.match(HERE / "finalize.py", manifest["finalizer_sha256"])
    root = Path(manifest["worktree"]).resolve()
    original_root = Path(manifest["original_run"]).resolve()
    checks = []
    def check(condition, label):
        reads.budget()
        require(condition, label)
        checks.append(label)

    def bound(entry, origin_root):
        snapshot = contained(PACKAGE, PACKAGE / entry["snapshot"])
        origin = contained(origin_root, entry["origin"])
        raw = reads.match(snapshot, entry["sha256"])
        check(reads.match(origin, entry["sha256"]) == raw, "original/snapshot bytes: " + entry["label"])
        return raw

    raw_outputs = {key: bound(entry, original_root) for key, entry in sorted(manifest["outputs"].items())}
    receipt = json_bytes(raw_outputs["receipt.json"])
    hall = json_bytes(raw_outputs["net/HALL_AGREEMENT.json"])
    net = json_bytes(raw_outputs["net/NET_RUN.json"])
    native = raw_outputs["native.txt"].decode("utf-8", errors="strict")
    check(receipt["source"] == HEAD and receipt["head_after"] == HEAD and receipt["same_source"] is True,
          "R4 source before/after HEAD unchanged")
    check(receipt["engine_sha256"] == manifest["engine_sha256"], "recorded exact R4 engine identity retained")
    before = receipt["source_before"]
    check(before == receipt["source_after"] and len(before) == 37, "all 37 runtime source hashes unchanged")
    source_key = ".tmp/hall-agreement-r4/proposal/tests/smoke_net_crossing_hall_agreement.gd"
    deps = {p: h for p, h in before.items() if p != source_key}
    check(len(deps) == 36 and before[source_key] == R4 and deps == hall["dependencies"],
          "36 exact dependency hashes + coordinator0485")
    expected_outputs = {p.replace("\\", "/"): h for p, h in receipt["output_sha256"].items()}
    manifest_outputs = {p: e["sha256"] for p, e in manifest["outputs"].items() if p != "receipt.json"}
    check(expected_outputs == manifest_outputs, "complete original output hash map, no omitted raw output")
    runs = {r["label"]: r for r in receipt["runs"]}
    check(set(runs) == {"parser", "native"} and runs["parser"]["native_exit"] == 0 and
          runs["parser"]["errors"] == [] and runs["native"]["native_exit"] == 2,
          "original parser/native results retained, native2 never relabelled")
    for label in ("parser", "native"):
        check(digest(raw_outputs[label + ".txt"]) == runs[label]["raw_sha256"], "original " + label + " receipt/raw binding")
    check(hall["exit_code"] == 2 and hall["failures"] == ["ERROR: smoke budget exceeded"] and
          net["fatal"] == "ERROR: smoke budget exceeded" and net["failures"] == [],
          "whole smoke remains failed-budget witness")
    pass_messages = [line[6:] for line in native.splitlines() if line.startswith("PASS: ")]
    check(len(pass_messages) == 263 and pass_messages == manifest["original_pass_messages"],
          "all original 263 PASS assertions retained in original raw order")
    errors = {}
    raw_errors = {}
    for name, raw in sorted(raw_outputs.items()):
        if name.endswith((".txt", ".log")):
            raw_errors[name] = [line for line in raw.decode("utf-8", errors="strict").splitlines()
                                if line.startswith(("ERROR:", "SCRIPT ERROR:", "FAIL:", "coordinator: ERROR:"))]
    for peer in (0, 1):
        text = raw_outputs[f"net/peer-{peer}.log"].decode("utf-8", errors="strict")
        errors[f"peer-{peer}.log"] = [line for line in text.splitlines() if line.startswith(("ERROR:", "SCRIPT ERROR:"))]
    check(errors == receipt["peer_log_errors"] and len(errors["peer-0.log"]) == 4 and not errors["peer-1.log"],
          "all four unresolved host ENet errors retained")

    source_raw = {}
    for path, entry in sorted(manifest["sources"].items()):
        source_raw[path] = bound(entry, root)
    check(set(source_raw) == set(before) and all(digest(source_raw[p]) == h for p, h in before.items()),
          "actual dependency/coordinator source bytes still equal R4 runtime pins")
    coordinator = source_raw[source_key].decode("utf-8", errors="strict")
    literal = coordinator.split('const PEER_SOURCE := """', 1)[1].split('"""', 1)[0].encode("utf-8")
    check(digest(literal) == PEER, "exact unchanged embedded peer extension14466")
    peer_entry = manifest["peer_extension"]
    check(bound(peer_entry, root) == literal, "actual R4 peer-extension file equals embedded literal")
    r5_entry = manifest["r5_source"]
    r5 = bound(r5_entry, root).decode("utf-8", errors="strict")
    old = '\t\tif FileAccess.file_exists(path):\n\t\t\tout[path] = FileAccess.get_sha256(path)'
    new = '\t\tif not out.has(path) and FileAccess.file_exists(path):\n\t\t\tout[path] = FileAccess.get_sha256(path)'
    check(coordinator.count(old) == 1 and r5 == coordinator.replace(old, new, 1),
          "R5 differs only by out.has(path) dedup; original assertions/timers unchanged")
    assessment_raw = bound(manifest["reuse_assessment"], root)
    assessment = json_bytes(assessment_raw)
    check(assessment["sealed"] is True and assessment["source"] == HEAD and
          assessment["verdict"].startswith("REUSE ELIGIBLE for separate literal F17#5 verdict"),
          "sealed independent reuse assessment bound, original FAIL not replaced")

    check(set(hall["pairs"]) == {"joined", "reloaded"}, "same R4 joined/reloaded phases only")
    check(hall["source_sha256"] == R4 and hall["peer_source_sha256"] == PEER,
          "actual capture coordinator/peer source pins")
    hello = hall["hello"]
    check(len(hello) == 2 and hello == [p["hello"] for p in net["peers"]], "Hall/NET_RUN same two actual peer hellos")
    check(hello[0]["user_data_dir"] != hello[1]["user_data_dir"] and hello[0]["role"] == "host" and
          hello[1]["role"] == "client" and hello[0]["pid"] != hello[1]["pid"], "separate host/client processes and profiles")
    check(net["run_id"] == manifest["run_id"] and net["scene"] == "title", "same continuous actual title/ENet run")
    for index, item in enumerate(hello):
        check(item["main_sha"] == HEAD[:12] and exact_integer(item["peer"]) == index,
              f"actual peer{index} source/run identity")
        contained(original_root, item["user_data_dir"])

    captures = []
    for phase in ("joined", "reloaded"):
        pair = hall["pairs"][phase]
        check(set(pair) == {"host", "guest", "host_recheck", "guest_recheck"}, phase + " four own/recheck captures")
        for role in ("host", "guest", "host_recheck", "guest_recheck"):
            data = pair[role]
            captures.append(data)
            label = phase + " " + role
            pin = data["pin"]
            check(data["phase"] == phase and data["peer_source_sha256"] == PEER and
                  data["peer_runtime_path"] == hall["peer_runtime_path"], label + " own source/runtime/phase pins")
            for field in ("scene_instance", "hall_instance"):
                exact_integer(pin[field], 1)
            for field in ("session_epoch", "map_revision", "world_revision", "ledger_seq"):
                exact_integer(pin[field])
            check(pin["hosting"] is role.startswith("host") and
                  (exact_integer(pin["local_peer_id"], 1) == 1 if role.startswith("host") else
                   1 < exact_integer(pin["local_peer_id"], 1) < 2**31), label + " actual server/client ENet identity")
            rows = pin["registry_rows"]
            check(len(rows) == 2 and len({r["character_id"] for r in rows}) == 2 and
                  len({exact_integer(r["peer_id"], 1) for r in rows}) == 2,
                  label + " two distinct admitted stable identities")
            own = [r for r in rows if r["peer_id"] == pin["local_peer_id"]]
            check(len(own) == 1 and own[0]["character_id"] == pin["character_id"] and
                  all(r["realm"] == "meadows" for r in rows), label + " own admission/realm binding")
            counts = data["counts"]
            check(counts["villages"] == counts["halls"] == 1 and counts["arches"] == counts["pedestals"] == 8 and
                  8 <= exact_integer(counts["road_houses"]) <= 10, label + " actual mounted producer counts")
            producers = data["producers"]
            check(set(producers) == {"village_nodes", "hall_nodes", "arches", "shrines"} and
                  producers["village_nodes"] and producers["hall_nodes"], label + " complete village/Hall producer trees present")
            display = pin["display"]
            check(display["portal_unlocks"] == [] and display["shrine_display"] == {} and
                  display["fifth_arch_stirred"] is False, label + " lawful fresh locked/empty/sealed display state")
            arches = producers["arches"]
            check(len(arches) == 8 and {a["id"] for a in arches} == set(ARCH_IDS), label + " eight unique actual arches")
            for arch in arches:
                aid = arch["id"]
                expected = "open" if aid == "home" else "locked" if aid in ARCH_IDS[1:4] else "sealed"
                check(arch["state"] == expected and arch["state_sign"] == ("Home arch" if aid == "home" else expected.capitalize()),
                      label + " arch state/sign " + aid)
                check(arch["sign_visible"] is True and arch["state_sign_visible"] is True and
                      arch["surface_visible"] is True and bool(arch["sign"]) and arch["nodes"], label + " signed membrane/tree " + aid)
                check(arch["material"]["emission_enabled"] is (aid == "home"), label + " actual surface emission " + aid)
            shrines = producers["shrines"]
            check(len(shrines) == 8 and {s["biome"] for s in shrines} == set(BIOMES), label + " eight unique actual shrine biomes")
            for shrine in shrines:
                check(shrine["relic_displayed"] is False, label + " empty shrine " + shrine["biome"])
                nodes = shrine["nodes"]
                mesh = any(n.get("class") == "MeshInstance3D" and n.get("visible_in_tree") is True for n in nodes)
                sign = any(n.get("class") == "Label3D" and n.get("visible_in_tree") is True and bool(n.get("text")) for n in nodes)
                check(mesh and sign, label + " actual pedestal and biome sign " + shrine["biome"])
        host, guest = pair["host"], pair["guest"]
        for role in ("host", "guest"):
            check(pair[role]["pin"] == pair[role + "_recheck"]["pin"] and
                  pair[role]["producers"] == pair[role + "_recheck"]["producers"] and
                  pair[role]["counts"] == pair[role + "_recheck"]["counts"], phase + " " + role + " full own pin/producer recheck")
        check(host["pin"]["character_id"] != guest["pin"]["character_id"], phase + " distinct host/guest characters")
        for field in ("registry_rows", "world_id", "display", "map_revision", "session_epoch"):
            check(host["pin"][field] == guest["pin"][field], phase + " server/client " + field + " agreement")
        check(host["producers"] == guest["producers"] and host["counts"] == guest["counts"], phase + " full actual producer tree/count equality")

    joined, reloaded = hall["pairs"]["joined"], hall["pairs"]["reloaded"]
    for role in ("host", "guest"):
        check(joined[role]["producers"] == reloaded[role]["producers"], role + " producer persistence after disk Load/rejoin")
        for field in ("world_id", "character_id"):
            check(joined[role]["pin"][field] == reloaded[role]["pin"][field], role + " stable " + field)
        for field in ("scene_instance", "hall_instance"):
            check(joined[role]["pin"][field] != reloaded[role]["pin"][field], role + " exact positive new " + field)
    reload = hall["reload"]
    saved = hall["guest_save"]
    check(reload["verdict"] == saved["verdict"] == "PASS" and reload["id"] == "s8" and saved["id"] == "s6",
          "same actual host title Load/guest portable reader verdicts")
    rd, gd = reload["data"], saved["data"]
    check(rd["rebuilt"] is True and rd["same_world"] is True and rd["disk_display_matches"] is True and
          rd["load_result"]["ok"] is True and gd["load_result"]["ok"] is True, "real production save/Load/read flags")
    for role in ("host", "guest"):
        check(reloaded[role]["pin"]["character_load_result"]["ok"] is True, role + " production returning-character reader")
    for field, prefix in (("scene_instance", "scene"), ("hall_instance", "hall")):
        check(rd["old_" + prefix + "_instance"] == joined["host"]["pin"][field] and
              rd["new_" + prefix + "_instance"] == reloaded["host"]["pin"][field], "host title Load exact " + prefix + " binding")
    check(rd["world_id"] == joined["host"]["pin"]["world_id"] and
          gd["character_id"] == joined["guest"]["pin"]["character_id"], "saved actual world and guest identity")
    def saved_disk(peer, virtual, expected):
        require(virtual.startswith("user://"), "saved file is not original peer user path")
        path = contained(Path(hello[peer]["user_data_dir"]), Path(hello[peer]["user_data_dir"]) / virtual[7:])
        relative = str(path.relative_to(original_root)).replace("\\", "/")
        check(relative in raw_outputs and manifest["outputs"][relative]["sha256"] == expected, "original saved disk SHA/own profile binding")
        return json_bytes(raw_outputs[relative])
    world = saved_disk(0, rd["world_disk_path"], rd["world_disk_sha256"])
    character = saved_disk(1, gd["character_disk_path"], gd["character_disk_sha256"])
    check(world["world_id"] == rd["world_id"] and world["redesign_world"] == rd["saved_display"] ==
          reloaded["host"]["pin"]["display"] == reloaded["guest"]["pin"]["display"], "actual host split disk display equals reloaded peers")
    check(character["character_id"] == gd["character_id"] and character["realm"] == "meadows" and
          character["last_world_id"] == rd["world_id"], "actual saved guest portable file owns its admitted identity/world")
    milestones = ("peer 0 production_host:", "peer 1 production_join: title fresh", "peer 1 hall_leave_guest:",
                  "peer 0 expect_peers:", "peer 0 hall_reload_host:", "peer 1 production_join: title returning")
    cursor = -1
    for prefix in milestones:
        positions = [i for i, message in enumerate(pass_messages) if message.startswith(prefix)]
        check(len(positions) == 1 and positions[0] > cursor, "original continuous route milestone " + prefix)
        cursor = positions[0]
    # bool autosave_here has no separate JSON flag: pinned peer source returns FAIL
    # on false before _step_leave/title Load; the actual PASS verdict proves that branch.
    check('if not bool(game.call("autosave_here")):' in coordinator and
          '"production host autosave_here refused"' in coordinator, "bool autosave source branch bound to actual reload PASS")

    wanted = hall["producer_resource_hashes"]
    check(len(wanted) == 75 and wanted == manifest["resource_sha256"], "original exact 75-resource hash set")
    references = set()
    stack = [(hall["pairs"], 0)]
    visited = 0
    while stack:
        value, depth = stack.pop()
        visited += 1
        reads.budget()
        require(visited <= MAX_VALUE_NODES and depth <= 96, "producer metadata traversal bound exceeded")
        if isinstance(value, dict):
            stack.extend((v, depth + 1) for v in value.values())
        elif isinstance(value, list):
            stack.extend((v, depth + 1) for v in value)
        elif isinstance(value, str) and value.startswith("res://"):
            references.add(value.split("::", 1)[0])
        elif type(value) is float:
            require(math.isfinite(value), "nonfinite producer/pin value")
    existing = {p for p in references if contained(root, root / p[6:]).is_file()}
    check(existing == set(wanted), "all existing producer references resolve to exactly original75, no exclusions")
    computed = {}
    for resource in sorted(existing):
        path = contained(root, root / resource[6:])
        reads.match(path, wanted[resource])  # Canonical cache ensures SHA once per unique original resource.
        computed[resource] = reads.files[path][1]
    check(computed == wanted, "each unique original resource SHA recomputed once and equal")
    reads.unchanged()
    return {
        "finalizer_verdict": "PASS", "criterion": "F17#5 literal layout/arch/shrine agreement after join and reload",
        "scope": "Separate bounded R4 default-baseline functional metadata proof; independent acceptance/landing still required",
        "acceptance_credit": False, "original_smoke_verdict": "FAIL", "original_native_exit": 2,
        "original_budget_failure": hall["failures"], "original_native_errors": runs["native"]["errors"],
        "original_raw_error_lines": raw_errors,
        "original_pass_lines": 263, "original_transport_errors": errors, "F49_transport_clean": "OPEN",
        "r5_native_executed": False, "source_head": HEAD, "r4_source_sha256": R4, "peer_sha256": PEER,
        "recorded_engine_sha256": receipt["engine_sha256"],
        "input_manifest_sha256": manifest_sha, "captures_rescored": 8, "dependencies_bound": 36,
        "unique_resource_sha256": computed, "unique_resources_recomputed": 75,
        "source_inputs_assets_final_byte_equal": True, "checks": checks,
        "standalone_budget_seconds": MAX_SECONDS, "limitations": LIMITS,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    output = contained(PACKAGE / "results", args.output_dir)
    require(not output.exists(), "preserve existing finalizer output; select a new ignored results folder")
    try:
        result = prove(args.manifest_sha256)
        code = 0
    except (Refusal, OSError, ValueError, KeyError, TypeError, IndexError, RecursionError) as error:
        result = {"finalizer_verdict": "FAIL", "reason": str(error), "acceptance_credit": False,
                  "original_smoke_verdict": "FAIL", "original_native_exit": 2,
                  "F49_transport_clean": "OPEN", "limitations": LIMITS}
        code = 1
    output.mkdir(parents=True, exist_ok=False)
    raw = (json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
    (output / "review.json").write_bytes(raw)
    print(result["finalizer_verdict"] + " standalone metadata only; original R4 smoke remains FAIL")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
