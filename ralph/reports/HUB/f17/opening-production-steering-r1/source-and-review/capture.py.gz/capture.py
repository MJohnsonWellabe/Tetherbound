# Authoring only: byte snapshots and literal source edits. No Godot invocation.
from pathlib import Path
import hashlib, json, urllib.request
root = Path('D:/tetherbound/redesign-hub')
out = root / '.tmp/opening-production-steering-r1'
receipt_path = Path('D:/tetherbound/m1-contact-fix-r5/receipt.json')
receipt = json.loads(receipt_path.read_bytes().decode('utf-8', 'strict'))
parent = '95e6d5fa69b97514031fd4a0ef883d940732bb62'
assert Path('D:/tetherbound/source/.git/refs/heads/tb/hub').read_bytes().decode('utf-8','strict').strip() == parent
pins = {}
for rel, expected in receipt['source_before'].items():
    raw = (root / rel).read_bytes()
    raw.decode('utf-8', 'strict')
    assert hashlib.sha256(raw).hexdigest() == expected, rel
    dest = out / 'originals' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    pins[rel] = expected
for name in ('native.txt', 'receipt.json', 'parser.txt'):
    raw = (receipt_path.parent / name).read_bytes()
    raw.decode('utf-8','strict')
    dest = out / 'evidence' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
assert hashlib.sha256((out/'evidence/native.txt').read_bytes()).hexdigest() == receipt['runs'][1]['raw_sha256']
# Primary engine API contract, tag 4.7; retained bytes include upstream license.
for name in ('kinematic_collision_3d.cpp', 'character_body_3d.cpp', 'physics_body_3d.cpp'):
    url = 'https://raw.githubusercontent.com/godotengine/godot/4.7/scene/3d/physics/' + name
    raw = urllib.request.urlopen(url, timeout=30).read()
    raw.decode('utf-8','strict')
    dest = out/'api'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(raw)
(out/'parent-pins.json').write_text(json.dumps({'parent':parent,'tracked_source_sha256':pins},indent=2)+'\n',encoding='utf-8')
print('Captured 14 exact R5 source pins and three untouched R5 logs; API bytes archived.')