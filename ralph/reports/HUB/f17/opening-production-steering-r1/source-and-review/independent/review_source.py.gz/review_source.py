from pathlib import Path
import json,sys,hashlib,subprocess,re,io,os,math
sys.stdout.reconfigure(encoding='utf-8');p=Path(__file__).resolve().parent.parent;d=p/'independent';H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((p/n).read_bytes().decode('utf-8','strict'));checks=[]
def C(n,b,detail=''):checks.append({'check':n,'pass':bool(b),'detail':detail})
freeze=J('freeze.json');cause=J('cause-and-constraints.json');pins=J('parent-pins.json');parent=pins['parent'];patch=(p/'opening-production-steering.patch').read_bytes()
C('exact frozen patch db20',H(patch)=='db20d22b0ce867d2f7172981658bf4943f231cee150b13e1d2b75d2fa49c1c59')
C('exact freeze files all raw match',all(H((p/n).read_bytes())==h for n,h in freeze['files_sha256'].items()))
C('exact parent scope',parent=='95e6d5fa69b97514031fd4a0ef883d940732bb62' and cause['parent']==freeze['parent']==parent)
paths=list(pins['tracked_source_sha256']);keys=[parent+':'+n for n in paths];buf=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(keys)+'\n').encode()));gitblobs={};newline={}
for key in keys:
 header=buf.readline().decode().strip();gitblobs[key]=buf.read(int(header.rsplit(' ',1)[1]));assert buf.read(1)==b'\n'
for name,wanted in pins['tracked_source_sha256'].items():
 raw=(p/'originals'/name).read_bytes();git=gitblobs[parent+':'+name];C('original exact raw pin '+name,H(raw)==wanted)
 if raw!=git:newline[name]={'executed_raw':H(raw),'Git_parent':H(git)}
 C('original parent equivalent '+name,raw==git or raw.replace(b'\r\n',b'\n')==git.replace(b'\r\n',b'\n'))
 # Preserve exact original bytes, not reconstructed/normalized source.
 out=d/'originals'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
proposalpaths=list(cause['proposed_source_sha256']);C('only three declared helper paths',set(proposalpaths)=={'tests/helpers/opening_geometry_navigator.gd','tests/helpers/gate_a_npc_gather_segment.gd','tests/helpers/meadows_earned_team_segment.gd'})
for name,wanted in cause['proposed_source_sha256'].items():C('proposal exact hash '+name,H((p/'proposal'/name).read_bytes())==wanted)
# Apply the frozen unified diff in memory; do not modify checkout or invoke Git apply.
lines=patch.decode('utf-8','strict').splitlines(True);i=0;replayed={}
while i<len(lines):
 assert lines[i].startswith('--- a/');name=lines[i][6:].rstrip('\r\n');i+=1;assert lines[i].rstrip('\r\n')=='+++ b/'+name;i+=1;before=(p/'originals'/name).read_bytes().decode('utf-8','strict').splitlines(True);result=[];cursor=0
 while i<len(lines) and not lines[i].startswith('--- a/'):
  h=re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert h;start=int(h[1])-1;result.extend(before[cursor:start]);cursor=start;i+=1;used=0;added=0
  while i<len(lines) and not lines[i].startswith(('@@ ','--- a/')):
   line=lines[i];i+=1;kind=line[0];text=line[1:]
   if kind in [' ','-']:assert before[cursor]==text,(name,cursor);cursor+=1;used+=1
   if kind in [' ','+']:result.append(text);added+=1
  assert used==int(h[2] or 1) and added==int(h[4] or 1)
 result.extend(before[cursor:]);raw=''.join(result).encode('utf-8');replayed[name]=H(raw);C('lossless exact in-memory patch replay '+name,raw==(p/'proposal'/name).read_bytes())
C('patch exact declared after source map',replayed==cause['proposed_source_sha256'])
def functions(s):
 ls=s.splitlines(True);out={}
 for i,line in enumerate(ls):
  m=re.match(r'^func (\w+)\(',line)
  if not m:continue
  j=i+1
  while j<len(ls) and (not ls[j].strip() or ls[j][0].isspace()):j+=1
  out[m[1]]=''.join(ls[i:j]).rstrip().encode('utf-8')
 return out
navname='tests/helpers/opening_geometry_navigator.gd';before=(p/'originals'/navname).read_bytes().decode();nav=(p/'proposal'/navname).read_bytes().decode();bf=functions(before);af=functions(nav);allowed={'_init','reset','_native_tick_impl','_native_tick'};changed={n for n,b in bf.items() if b!=af[n]};C('only four original navigator functions changed',changed==allowed)
claimed=cause['unchanged']['preserved_original_function_sha256'];C('all original unchanged function bodies exact claimed hash',set(claimed)==set(bf)-allowed and all(bf[n]==af[n] and H(bf[n])==h for n,h in claimed.items()),str(len(claimed))+' bodies, including predictive geometry, doors, arrival/walk budget and diagnostics')
C('all original constants exact',before.split('class NativeTick')[0]==nav.split('class NativeTick')[0])
for name,old,new in [('tests/helpers/gate_a_npc_gather_segment.gd','_nav = NAVIGATOR.new(_tree, _player, _rig, _send_stick)','_nav = NAVIGATOR.new(_tree, _player, _rig, _send_stick, true) # Observe actual production steering.'),('tests/helpers/meadows_earned_team_segment.gd','_nav = NAV.new(tree, _player, _rig, _stick)','_nav = NAV.new(tree, _player, _rig, _stick, true) # Observe actual production steering.')]:
 b=(p/'originals'/name).read_bytes();a=(p/'proposal'/name).read_bytes();C(name+' all other caller bytes exact',b.count(old.encode())==1 and a==b.replace(old.encode(),new.encode(),1))
C('default predictive API retained false optin','production_steering: bool = false' in nav and 'if not _production_steering:\n\t\treturn _choose(point, tolerance)' in nav and 'if not _production_steering and not _supported_step(direction):' in nav)
C('main-thread actual pre and post guards','OS.get_thread_caller_id() != OS.get_main_thread_id()' in af['_native_tick'].decode() and 'OS.get_thread_caller_id() != OS.get_main_thread_id()' in af['_production_observe'].decode())
contract=af['_production_contract'].decode();C('same world group priority real script processing contract',all(x in contract for x in ['res://scripts/player/player_controller.gd','_body.is_physics_processing()','_body.can_process()','_tick.process_physics_priority != _body.process_physics_priority - 1','_observer.process_physics_priority != _body.process_physics_priority + 1','_body.get_parent() != _world','_tick.get_parent() != _world','_observer.get_parent() != _world']) and contract.count('Node.PROCESS_THREAD_GROUP_INHERIT')==3)
impl=af['_native_tick_impl'].decode();observe=af['_production_observe'].decode();C('arrival eligibility only after actual production observation',impl.index('_checked_start = not _production_steering')<impl.index('_production_pending = true') and '_checked_start = not refused() # Only AFTER actual controller movement.' in observe and '_production_pending = false' in observe and 'if _production_pending:' in af['_native_tick'].decode())
live=af['_observed_live_clear'].decode();C('actual full registered-body live query only', '_motion(_body.global_transform, Vector3.ZERO, true)' in live and af['_motion']==bf['_motion'] and af['_trainer_contract']==bf['_trainer_contract'] and af['_registered_body_contract']==bf['_registered_body_contract'])
C('live deep/nonfinite/contact/actual local shape refusal',all(x in live for x in ['_body.global_position.is_finite()','_body.velocity.is_finite()','_observed_live.get_travel().length() > _body.safe_margin + CONTACT_EPS','depth > _body.safe_margin + CONTACT_EPS','normal.length_squared()','_observed_live.get_collision_local_shape(index) != _capsule_index']))
C('production recovery attempts never credited','_recoveries_at_start != 0' in af['_init'].decode() and 'int(_body.call("unstick_count")) != _recoveries_at_start' in live)
C('actual grounded pre and post required','if not _body.is_on_floor():' in impl and 'elif not _body.is_on_floor():' in observe)
C('bounded native slide observations use actual shape owner','_body.get_slide_collision(slide)' in observe and 'collision.get_local_shape(index) != _cap' in observe and 'contacts > CONTACTS' in observe and 'count > CONTACTS' in observe)
C('original stall cap real XZ progress reset only after travel', '_stalled += 1' in observe and '_xz(_body.global_position).distance_to(_xz(_progress_at)) >= PROGRESS' in observe and 'if _stalled > 90:' in observe and 'const PROGRESS := 0.08' in (p/'originals/tests/helpers/stick_navigator.gd').read_bytes().decode())
C('road retry does not reset stall cap or bypass departure','_retry_at += STALL_FRAMES' in impl and 'if _production_steering and _departure.is_empty() and _stalled >= _retry_at:' in impl and '_observed_choice >= MAX_CHOICES' in af['_choose_route'].decode() and 'if _observed_choice == 0 or not _departure.is_empty():' in af['_choose_route'].decode())
C('post observation movement bounded by actual unchanged controller','_body.get_real_velocity() * _production_delta' in observe and '_xz(extra).length() > maxf(_probe, speed_cap * _production_delta) + skin' in observe and 'extra.y > _step_height + skin' in observe and 'extra.y < -_body.floor_snap_length - skin' in observe and '_step_height != 0.35 or _probe != 0.25' in nav)
C('shared10ms own pre post work and native query lifetime preserved','FRAME_QUERY_US - _pre_observe_us' in observe and 'Time.get_ticks_usec() > _deadline' in observe and af['_spend']==bf['_spend'])
# The diff contains no writes to player state, collision state, health, AI or progression.
added=[x[1:] for x in lines if x.startswith('+') and not x.startswith('+++')];writes=[x for x in added if re.search(r'\b(?:_body|_player)\.(?:global_position|position|global_transform|transform|velocity|collision_mask|collision_layer|safe_margin|floor_snap_length|floor_max_angle)\s*=(?!=)',x)]
C('no helper physical or gameplay state writes',not writes and not any('Input.action_' in x or 'shape.radius =' in x or 'shape.height =' in x for x in added))
controller=(p/'originals/scripts/player/player_controller.gd').read_bytes().decode();phys=functions(controller)['_physics_process'].decode();order=['move_and_slide()','_try_step_up(planned_motion)','_unwedge(planned_motion, before, delta)','_recover_if_entombed(delta)','_resolve_landing(falling_speed)'];C('actual production controller order pinned',all(phys.index(a)<phys.index(b) for a,b in zip(order,order[1:])))
base=(p/'originals/tests/helpers/stick_navigator.gd').read_bytes().decode();C('camera relative parsed joypad actual input remains exact','basis.inverse() * direction' in functions(base)['_push'].decode() and 'Input.parse_input_event(event)' in (p/'proposal/tests/helpers/meadows_earned_team_segment.gd').read_bytes().decode())
engine={str(f.relative_to(d/'engine-pinned')).replace('\\','/'):{'sha256':H(f.read_bytes()),'url':'https://github.com/godotengine/godot/blob/5b4e0cb0f/'+str(f.relative_to(d/'engine-pinned')).replace('\\','/')} for f in (d/'engine-pinned').rglob('*') if f.is_file()};readengine=lambda n:(d/'engine-pinned'/n).read_bytes().decode();scene=readengine('scene/main/scene_tree.cpp');node=readengine('scene/main/node.h');body=readengine('scene/3d/physics/character_body_3d.cpp');collision=readengine('scene/3d/physics/kinematic_collision_3d.cpp')
physics=scene[scene.index('bool SceneTree::physics_process('):scene.index('void SceneTree::iteration_end(')];C('exact engine signal before sorted callbacks',physics.index('emit_signal(SNAME("physics_frame"))')<physics.index('_process(true)') and 'nodes.sort_custom<Node::ComparatorWithPhysicsPriority>();' in scene and 'p_b->data.physics_process_priority > p_a->data.physics_process_priority' in node)
C('exact engine slide owner populated and localshape returns ownerObject','slide_colliders.write[p_bounce]->owner_id = get_instance_id();' in body and 'Object *KinematicCollision3D::get_local_shape' in collision and 'return owner->shape_owner_get_owner(ownerid);' in collision)
C('exact engine real velocity computed at end of moveandslide','real_velocity = get_position_delta() / delta;' in body)
rec=J('evidence/receipt.json');runs={x['label']:x for x in rec['runs']};C('original R5 parserPASS/nativeFAIL preserved',runs['parser']['native_exit']==0 and runs['native']['native_exit']==1 and len(runs['native']['errors'])==3)
for name in ['native.txt','receipt.json','parser.txt']:C('original R5 raw evidence '+name,(p/'evidence'/name).read_bytes()==Path('D:/tetherbound/m1-contact-fix-r5',name).read_bytes())
native=(p/'evidence/native.txt').read_bytes().decode();diag=[json.loads(x.split(' ',1)[1]) for x in native.splitlines() if x.startswith('OPENING_CONTACT_DIAG ')][0];travel=math.sqrt(sum(x*x for x in diag['motion']['travel']));C('actual original37micrometre recovery observation preserved',abs(travel-cause['cause']['zero_motion_travel_m'])<1e-15)
failed=[x for x in checks if not x['pass']];verdict='SOURCE HOLD' if failed else 'SOURCE PASS';report={'sealed':True,'verdict':verdict,'patch_sha256':H(patch),'parent':parent,'cause_sha256':H((p/'cause-and-constraints.json').read_bytes()),'freeze_sha256':H((p/'freeze.json').read_bytes()),'source_after_sha256':cause['proposed_source_sha256'],'checks':checks,'failed':failed,'exact_preserved_original_functions':claimed,'original_to_Git_line_endings':newline,'engine_primary_sources':engine,'engine_runs':0,'source_scope':'Only M1 constructor optin to ordinary camera-relative stick with actual pre/post physical observation. Original predictive APIs remain available unchanged; only four existing navigator functions changed, appended observation/planning methods, two caller constructor arguments.','minimum_remaining_gate':'ROOT necessary cheap parser then ONE unchanged-budget seed4/no-checkpoints fresh uninterrupted production title→starter→practice catch→village gather→camp→three beds→three tournament rounds. No wider classifier retry, broad unit/fullCI or extra hypothetical physics suite solely this helper correction.','limits':['No runtime/criterion/F17#4 credit. All prior actual FAIL retained.','Observed cached floor flags describe move_and_slide and can precede production step-up; not a post-step floor-support theorem.','Zero-motion live contacts reject observed deep overlap, saturation/nonfinite/shape divergence; no all-backend/concave/dynamic geometry theorem.','Standard ground walking and callback priority assumptions source-bound; real production timing/contact caps may still conservatively fail.','Actual full contact cache sums over slides and can conservatively exceed8; full route must run.','Direct/author-road choices are provisional and may fail greedy bends within existing90frame/request/plan/query/time limits.','10ms covers own pre/post work, excluding intervening production execution; native calls cooperatively bounded, not interruptible.','Metadata/log records do not prove no-snag or any earned milestone; original real player assertions remain necessary.']}
for name,raw in [('review.json',(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode()),('strict-review.txt',(verdict+' — opening ordinary production steering\n\n'+json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())]:
 out=d/name;assert not out.exists();pending=d/(name+'.pending');pending.write_bytes(raw);os.replace(pending,out)
print(json.dumps({'verdict':verdict,'checks':len(checks),'failed':failed,'review_sha256':H((d/'review.json').read_bytes())}))
