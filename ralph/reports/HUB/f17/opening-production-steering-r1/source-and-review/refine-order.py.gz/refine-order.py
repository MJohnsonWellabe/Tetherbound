from pathlib import Path
p=Path('D:/tetherbound/redesign-hub/.tmp/opening-production-steering-r1/author.py')
s=p.read_bytes().decode('utf-8','strict')
old='\t\t_production_delta = delta\n\t\tif _production_pending:'
new='\t\t_production_delta = delta\n\t\tif OS.get_thread_caller_id() != OS.get_main_thread_id():\n\t\t\t_native_tick_impl(delta) # Uses the existing deferred stop on wrong thread.\n\t\t\treturn\n\t\tif _production_pending:'
assert s.count(old)==1
s=s.replace(old,new)
# Two source backslashes inside author.py produce one continuation in GDScript.
lines=s.splitlines(True)
fixed=[]
for line in lines:
    if line.rstrip('\r\n').endswith(' \\') and ('speed_cap' in line or 'slide_motion' in line or '_xz(extra)' in line):
        line=line.rstrip('\r\n')+'\\\n'
    fixed.append(line)
p.write_bytes(''.join(fixed).encode('utf-8'))