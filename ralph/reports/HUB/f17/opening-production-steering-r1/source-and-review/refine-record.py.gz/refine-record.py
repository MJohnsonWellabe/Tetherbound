from pathlib import Path
p=Path('D:/tetherbound/redesign-hub/.tmp/opening-production-steering-r1/author.py')
s=p.read_bytes().decode('utf-8','strict')
old='''\tprint("OPENING_PRODUCTION_OBSERVATION " + JSON.stringify({"acceptance": false,'''
new='''\tvar slides: Array = []
\tfor slide in mini(CONTACTS, _body.get_slide_collision_count()):
\t\tvar collision: KinematicCollision3D = _body.get_slide_collision(slide)
\t\tif collision == null:
\t\t\tbreak
\t\tfor index in mini(CONTACTS - slides.size(), collision.get_collision_count()):
\t\t\tslides.append({"slide": slide, "normal": _contact_vector(collision.get_normal(index)),
\t\t\t\t"point": _contact_vector(collision.get_position(index)), "swept_depth": collision.get_depth(),
\t\t\t\t"collider_rid": str(collision.get_collider_rid(index)), "collider_shape": collision.get_collider_shape_index(index)})
\t\tif slides.size() == CONTACTS:
\t\t\tbreak
\tprint("OPENING_PRODUCTION_OBSERVATION " + JSON.stringify({"acceptance": false,'''
assert s.count(old)==1
s=s.replace(old,new)
s=s.replace('''\t\t"swept_depth": _observed_slide_depth, "recoveries": int(_body.call("unstick_count")),''', '''\t\t"swept_depth": _observed_slide_depth, "slide_contacts": slides,
\t\t"safe_margin": _body.safe_margin, "floor_angle": _body.floor_max_angle, "snap": _body.floor_snap_length, "mask": _body.collision_mask,
\t\t"recoveries": int(_body.call("unstick_count")) if _body.has_method("unstick_count") else -1,''')
p.write_bytes(s.encode('utf-8'))