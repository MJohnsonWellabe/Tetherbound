from pathlib import Path
p=Path('D:/tetherbound/redesign-hub/.tmp/opening-production-steering-r1/author.py')
s=p.read_bytes().decode('utf-8','strict')
anchor="replace('\\t_checked_start = true\\n\\tvar direction := _request',"
assert s.count(anchor)==1
insert="""replace('\\tif not can_walk():\\n\\t\\t_drive.call(0.0, 0.0)\\n\\t\\treturn', '''\\tif not can_walk():
\\t\\tif _production_steering:
\\t\\t\\t_checked_start = false
\\t\\t_drive.call(0.0, 0.0)
\\t\\treturn''')
"""
s=s.replace(anchor,insert+anchor)
p.write_bytes(s.encode('utf-8'))