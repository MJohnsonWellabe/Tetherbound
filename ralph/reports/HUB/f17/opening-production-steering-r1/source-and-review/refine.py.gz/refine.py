from pathlib import Path
out=Path('D:/tetherbound/redesign-hub/.tmp/opening-production-steering-r1')
p=out/'author.py'
s=p.read_bytes().decode('utf-8','strict')
s=s.replace('var _production_before := Vector3.ZERO\nvar _pre_observe_us', 'var _production_before := Vector3.ZERO\nvar _production_delta := 0.0\nvar _pre_observe_us')
s=s.replace('\t\tvar began: int = Time.get_ticks_usec()\n\t\tif _production_pending:', '\t\tvar began: int = Time.get_ticks_usec()\n\t\t_production_delta = delta\n\t\tif _production_pending:')
s=s.replace('''\t\t_observed_frames += 1
\t\t_observed_distance += _body.global_position.distance_to(_production_before)''','''\t\t# Cached real velocity is computed by move_and_slide before the production
\t\t# step-up. Read it; never write it. Additional motion must fit that actual
\t\t# controller's step/drop bounds, so a respawn/pose jump cannot earn travel.
\t\tvar speed_cap: float = float(_body.get("_max_speed"))
\t\tvar slide_motion: Vector3 = _body.get_real_velocity() * _production_delta
\t\tvar extra: Vector3 = _body.global_position - _production_before - slide_motion
\t\tvar skin: float = _body.safe_margin + CONTACT_EPS
\t\tif not is_finite(_production_delta) or _production_delta <= 0.0 or not is_finite(speed_cap) or speed_cap <= 0.0 \\
\t\t\t\tor not slide_motion.is_finite() or not extra.is_finite() \\
\t\t\t\tor speed_cap * _production_delta > MAX_EDGE \\
\t\t\t\tor slide_motion.length() > speed_cap * _production_delta + _body.floor_snap_length + skin \\
\t\t\t\tor _xz(extra).length() > maxf(_probe, speed_cap * _production_delta) + skin \\
\t\t\t\tor extra.y > _step_height + skin or extra.y < -_body.floor_snap_length - skin:
\t\t\t_stop_geometry("actual movement exceeded production slide/step/drop bounds")
\tif not refused():
\t\t_observed_frames += 1
\t\t_observed_distance += _body.global_position.distance_to(_production_before)''')
s=s.replace('''\t\t"on_floor": _body.is_on_floor(), "on_wall": _body.is_on_wall(), "on_ceiling": _body.is_on_ceiling(),''','''\t\t"on_floor": _body.is_on_floor(), "on_wall": _body.is_on_wall(), "on_ceiling": _body.is_on_ceiling(),
\t\t"actual_delta": _contact_vector(_body.global_position - _production_before),
\t\t"slide_motion": _contact_vector(_body.get_real_velocity() * _production_delta),''')
p.write_bytes(s.encode('utf-8'))
print('Added live controller motion bounds to ignored authoring input only.')