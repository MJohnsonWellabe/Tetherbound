from pathlib import Path
import hashlib, json, re, math
root=Path('D:/tetherbound/redesign-hub')
out=root/'.tmp/opening-production-steering-r1'
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((out/'parent-pins.json').read_bytes().decode('utf-8','strict'))
for rel in ('data/config/building_prefabs.json','data/config/movement.json','scenes/player/player.tscn'):
    raw=(root/rel).read_bytes(); raw.decode('utf-8','strict')
    p=out/'originals'/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(raw)
    pins['tracked_source_sha256'][rel]=sha(raw)
assert Path('D:/tetherbound/source/.git/refs/heads/tb/hub').read_bytes().decode('utf-8','strict').strip()==pins['parent']
for rel,h in pins['tracked_source_sha256'].items():
    assert sha((root/rel).read_bytes())==h, 'SOURCE DRIFT: '+rel
    assert sha((out/'originals'/rel).read_bytes())==h
# Replay lossless unified patch into memory, never onto tracked paths.
lines=(out/'opening-production-steering.patch').read_bytes().decode('utf-8','strict').splitlines(True)
i=0; replayed={}
while i<len(lines):
    assert lines[i].startswith('--- a/')
    rel=lines[i][6:].rstrip('\r\n'); i+=1
    assert lines[i]=='+++ b/'+rel+'\n'; i+=1
    before=(out/'originals'/rel).read_bytes().decode('utf-8','strict').splitlines(True)
    result=[]; cursor=0
    while i<len(lines) and not lines[i].startswith('--- a/'):
        header=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n',lines[i]); assert header,lines[i]
        start=int(header[1])-1; result.extend(before[cursor:start]); cursor=start; i+=1
        removed=added=0
        while i<len(lines) and not lines[i].startswith(('@@ ','--- a/')):
            tag=lines[i][0]; content=lines[i][1:]
            if tag in (' ','-'):
                assert before[cursor]==content,(rel,cursor)
                cursor+=1; removed+=1
            if tag in (' ','+'):
                result.append(content); added+=1
            assert tag in (' ','+','-'); i+=1
        assert removed==int(header[2] or 1)
        assert added==int(header[4] or 1)
    result.extend(before[cursor:]); raw=''.join(result).encode('utf-8')
    assert raw==(out/'proposal'/rel).read_bytes(), rel
    replayed[rel]=sha(raw)
# Byte audit only, not a parser or execution of GDScript.
rel='tests/helpers/opening_geometry_navigator.gd'
before=(out/'originals'/rel).read_bytes().decode('utf-8','strict')
after=(out/'proposal'/rel).read_bytes().decode('utf-8','strict')
def functions(s):
    lines=s.splitlines(True); result={}
    for i,line in enumerate(lines):
        m=re.match(r'^func (\w+)\(',line)
        if not m: continue
        body=[line]; j=i+1
        while j<len(lines) and (not lines[j].strip() or lines[j][0].isspace()):
            body.append(lines[j]); j+=1
        result[m[1]]=''.join(body).rstrip().encode('utf-8')
    return result
bf=functions(before); af=functions(after)
changed={'_init','reset','_native_tick_impl','_native_tick'}
unchanged={name:sha(raw) for name,raw in bf.items() if name not in changed}
for name in unchanged: assert bf[name]==af[name], name
assert before.split('class NativeTick')[0]==after.split('class NativeTick')[0], 'original constants changed'
for rel,old,new in (
('tests/helpers/gate_a_npc_gather_segment.gd','_nav = NAVIGATOR.new(_tree, _player, _rig, _send_stick)','_nav = NAVIGATOR.new(_tree, _player, _rig, _send_stick, true) # Observe actual production steering.'),
('tests/helpers/meadows_earned_team_segment.gd','_nav = NAV.new(tree, _player, _rig, _stick)','_nav = NAV.new(tree, _player, _rig, _stick, true) # Observe actual production steering.'),
):
    raw=(out/'originals'/rel).read_bytes()
    assert raw.replace(old.encode(),new.encode())==(out/'proposal'/rel).read_bytes()
# Numeric description of the preserved actual observation, never a runtime test.
diag=[json.loads(line.split(' ',1)[1]) for line in (out/'evidence/native.txt').read_bytes().decode('utf-8','strict').splitlines() if line.startswith('OPENING_CONTACT_DIAG ')][0]
travel=math.sqrt(sum(v*v for v in diag['motion']['travel']))
record={
 'schema':1,'state':'FROZEN_PROPOSAL_ONLY; INDEPENDENT SOURCE GATE AND ACTUAL PATH REQUIRED',
 'parent':pins['parent'],'effective_permissions':{'approval_policy':'never','sandbox_mode':'danger-full-access'},
 'proposed_path_owner':'ROOT; three tracked paths proposed only, no tracked changes performed',
 'proposed_source_sha256':replayed,
 'cause':{'prior_actual_result':'R5 native FAIL, exit 1, three ERROR and zero SCRIPT ERROR; preserved, not superseded',
  'receipt':'D:/tetherbound/m1-contact-fix-r5/receipt.json','native':'D:/tetherbound/m1-contact-fix-r5/native.txt',
  'actual_live_pose':diag['live_pose']['origin'],'on_floor':diag['body']['is_on_floor'],
  'zero_motion_travel_m':travel,'safe_fraction':diag['motion']['safe'],'unsafe_fraction':diag['motion']['unsafe'],
  'same_terrain_shape':41,'depths':[c['depth'] for c in diag['motion']['contacts']],
  'failed_guard':'downward contact cone, despite shallow live skin and grounded controller',
  'approach_change':'Keep predictive/default APIs intact; M1 explicitly opts into bounded genuine stick steering and post-controller observation. Do not broaden paired-normal classifier.'},
 'execution_order':['SceneTree.physics_frame resumes callers and queues requests','NativeTick at trainer priority -1 validates actual registered state and sends ordinary camera-relative stick','Unchanged production controller: move_and_slide, step-up, unwedge, recovery, landing','ProductionObserve at trainer priority +1 validates actual final state and collisions before the next physics_frame arrival check'],
 'physical_authority':{'helper_pose_velocity_hp_ai_progression_writes':False,'production_collision_response_unchanged':True,
  'live_overlap_check':'Two bounded zero-motion registered-body recovery queries per requested walking frame (before/after); original margin, mask, capsule, owners, world, saturation and local-shape identity; reject nonfinite/deep overlap or recovery > skin. No predicted landing/floor-cone gate in M1 mode.',
  'floor':'Require actual is_on_floor before and after production; this flag reflects move_and_slide, and can precede production step-up. Not a theorem of post-step floor support.',
  'actual_slide_owner':'Populated CharacterBody3D.get_slide_collision cache supplies owner_id. KinematicCollision3D.get_local_shape returns shape owner Object, compared to actual CollisionShape3D, never integer index.',
  'swept_depth':'Record actual swept depth, do not equate unsafe-motion depth to penetration at live final pose; deep live checks use zero-motion native result.',
  'movement':'Observe cached get_real_velocity times delta before production step-up; bound additional actual displacement by unchanged 0.35 rise, 0.4 snap and 0.25/actual max-speed step reach. Detect recovery attempts with unstick_count; no count reset or disabling production.',
  'stalls':'0.08m XZ progress and original >90 requested-frame stall refusal; bounded authored-road retry every 26 stalled frames does not reset that cap. Mandatory departure cannot detour to road nodes.'},
 'unchanged':{'gather_budget':1800,'team_approach_budget':3600,'max_walk_budget':3600,'held_wait_limit':36000,
  'max_edge_m':180,'road_input_limit':64,'candidate_limit':8,'plan_lifetime':256,'request_lifetime':24000,
  'native_queries_per_frame':96,'native_queries_lifetime':250000,'native_contacts':8,'helper_work_deadline_us':10000,
  'deadline':'Shared pre/post helper work allowance; intervening production execution is excluded. Native calls remain cooperatively checked before/after, not interruptible.',
  'preserved_original_function_sha256':unchanged,
  'callers':'Only one constructor opt-in each; all door/gate departure, source/tool/equip/input, starter/catch/camp/three beds/three rounds and other progression assertions are byte-identical.',
  'fresh_opening_and_whole_M1_smoke':'Unchanged; no third constructor seam needed.',
  'no_teleports_grants_checkpoints_shrinking_exclusions_masks_collision_ai_changes_skips':True},
 'logging':'First eight actual observations, each 90th and one failure; each record limits live and slide contacts to eight. Position, actual progress, grounded/wall/ceiling signals, native live and actual slide normals/points/depths/shape identities, recovery count and budgets. No acceptance/no-snag claim.',
 'unproved_and_conservative_limits':['No engine, parser, import, tests, GPU or native execution performed. This proposal is not SOURCEPASS or F17#4 credit.',
  'Callback ordering and standard grounded production path are source-bound assumptions; changed process groups/priorities/disabled callbacks or skipped observation refuse.',
  'Actual capsule recovery queries may still conservatively refuse contact saturation, deep live contacts or slow native calls; no all-terrain interior or complete future-route theorem is claimed.',
  'Grounded flag/cache semantics, native raw/concave/dynamic contact behavior, small terrain drops, production step/recovery observations and timed query cost need the one serialized real run.',
  'Direct/authored-road choices are provisional, can meet limited-road bends or greedy dead ends and fail within unchanged budgets. Actual production collisions enforce walls and closed doors.',
  'Observed displacement does not itself prove no snag, route completion or earned progression. The full uninterrupted fresh player chain and original milestones must actually pass.'],
 'next_owner_action':'Independently inspect/apply exact patch, one cheap parser if source gate passes, then one necessary original-budget fresh actual M1 path in ROOT serialized engine queue. All prior FAILs and source gates remain retained; F17#4 remains OPEN until full chain passes.',
 'prior_evidence_preserved':['D:/tetherbound/m1-shape-r1','D:/tetherbound/m1-shape-r2','D:/tetherbound/m1-shape-r3','D:/tetherbound/m1-contact-r4','D:/tetherbound/m1-contact-fix-r5','D:/tetherbound/redesign-hub/.tmp/opening-contact-fix-r1','D:/tetherbound/redesign-hub/.tmp/independent-opening-review/shape-correction-root-r1','D:/tetherbound/redesign-hub/.tmp/hall-agreement-finalizer-r1'],
 'byte_verification_only':{'lossless_patch_replay':True,'pinned_sources_second_read_equal':True,'17_pinned_tracked_sources_unchanged':True,'whole_worktree_cold_read_performed':False},
 'primary_api_urls':['https://raw.githubusercontent.com/godotengine/godot/4.7/scene/3d/physics/'+name for name in ('kinematic_collision_3d.cpp','character_body_3d.cpp','physics_body_3d.cpp')]
}
(out/'parent-pins.json').write_bytes((json.dumps(pins,indent=2)+'\n').encode())
(out/'cause-and-constraints.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
(out/'rationale.txt').write_bytes(('Frozen ignored proposal against '+pins['parent']+' only.\n'
 'The same grounded Terrain skin case failed after two classifier approaches. M1 now opts into real-controller observation; predictive diagnostics remain unchanged.\n'
 'The helper sends ordinary stick before production physics and observes final pose/floor/native overlap and populated slide contacts afterward. Production alone moves the trainer.\n'
 'Recoveries, deep live overlap, lost floor, stale callbacks, excessive displacement, stall, route/query/deadline caps fail explicitly. Mandatory mounted departure/doors and all earned assertions/budgets remain.\n'
 'Source assumptions and conservative refusals are detailed in cause-and-constraints.json. No runtime/parser/source PASS, no no-snag or acceptance claim. ROOT independent source gate and necessary real whole path remain.\n'
 'opening-production-steering.patch replays byte-exact to the three proposal files. Original source and failed logs were read twice and remain unchanged.\n').encode())
# Recheck raw originals and pinned live sources immediately before freeze.
for name in ('native.txt','parser.txt','receipt.json'):
    assert (out/'evidence'/name).read_bytes()==(Path('D:/tetherbound/m1-contact-fix-r5')/name).read_bytes()
for rel,h in pins['tracked_source_sha256'].items(): assert sha((root/rel).read_bytes())==h, rel
assert Path('D:/tetherbound/source/.git/refs/heads/tb/hub').read_bytes().decode('utf-8','strict').strip()==pins['parent']
manifest={'schema':1,'parent':pins['parent'],'state':'FROZEN_PROPOSAL_ONLY','patch_sha256':sha((out/'opening-production-steering.patch').read_bytes()),'files_sha256':{}}
for p in sorted(out.rglob('*')):
    if p.is_file() and p.name!='freeze.json':
        p.read_bytes().decode('utf-8','strict')
        manifest['files_sha256'][p.relative_to(out).as_posix()]=sha(p.read_bytes())
(out/'freeze.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print(json.dumps({'parent':pins['parent'],'patch_sha256':manifest['patch_sha256'],'freeze_sha256':sha((out/'freeze.json').read_bytes()),'proposed_source_sha256':replayed,'preserved_original_functions':len(unchanged),'tracked_source_pins_verified':len(pins['tracked_source_sha256'])},indent=2))