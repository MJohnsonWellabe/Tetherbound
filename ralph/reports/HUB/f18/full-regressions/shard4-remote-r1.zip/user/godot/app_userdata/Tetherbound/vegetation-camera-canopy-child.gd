extends SceneTree
func _initialize():
	call_deferred("run")
func run():
	var test = load("res://tests/test_vegetation_camera_canopy.gd").new()
	for method in test.CASES:
		test._setup_fixture()
		await physics_frame
		await physics_frame
		test.call(method)
		test._free_fixture()
	print("CANOPY_RESULT=" + JSON.stringify({"assertions":test.assertion_count,"failures":test.failures}))
	quit(0 if test.failures.is_empty() else 1)
