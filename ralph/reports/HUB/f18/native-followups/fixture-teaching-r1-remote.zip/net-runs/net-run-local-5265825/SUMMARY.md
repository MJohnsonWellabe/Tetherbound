# Net smoke run local-5265825

Scene: title
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2469 exited=true unexpected_exit=false
- peer 1 (client) pid=2470 exited=true unexpected_exit=false

ALL CHECKS PASSED
