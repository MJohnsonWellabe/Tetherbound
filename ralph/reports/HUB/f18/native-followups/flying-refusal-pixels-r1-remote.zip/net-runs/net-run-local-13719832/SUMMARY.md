# Net smoke run local-13719832

Scene: title
Peers: 1
Net conditions: clean (no proxy)

- peer 0 (host) pid=2330 exited=false unexpected_exit=false

FAILURES:
- peer 0 f18_fixture: no verdict
- F18 traversal refusal peer logs have no engine/script errors (peer 0: ERROR: x1)
