# Net smoke run local-8127503

Scene: title
Peers: 1
Net conditions: clean (no proxy)

- peer 0 (host) pid=2302 exited=false unexpected_exit=false

FAILURES:
- peer 0 f18_traversal_refusal: no verdict
