# Net smoke run local-5862275

Scene: title
Peers: 1
Net conditions: clean (no proxy)

- peer 0 (host) pid=2467 exited=true unexpected_exit=false

ALL CHECKS PASSED
