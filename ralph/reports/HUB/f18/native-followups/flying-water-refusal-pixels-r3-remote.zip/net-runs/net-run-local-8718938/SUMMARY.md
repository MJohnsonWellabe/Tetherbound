# Net smoke run local-8718938

Scene: title
Peers: 1
Net conditions: clean (no proxy)

- peer 0 (host) pid=2339 exited=true unexpected_exit=false

ALL CHECKS PASSED
