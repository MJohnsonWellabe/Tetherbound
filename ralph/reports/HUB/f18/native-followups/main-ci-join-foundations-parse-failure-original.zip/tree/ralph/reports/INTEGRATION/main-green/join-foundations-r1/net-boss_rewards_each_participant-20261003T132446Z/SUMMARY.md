# Net smoke run net-20261003T132446Z-2513

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2537 exited=true unexpected_exit=true
- peer 1 (client) pid=2538 exited=true unexpected_exit=false

FATAL: ERROR: peer exited (peer 0, pid 2537)
