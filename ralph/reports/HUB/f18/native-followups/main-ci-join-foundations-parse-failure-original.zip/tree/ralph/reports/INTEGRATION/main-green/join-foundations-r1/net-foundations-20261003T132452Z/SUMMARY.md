# Net smoke run net-20261003T132452Z-2562

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2588 exited=true unexpected_exit=true
- peer 1 (client) pid=2589 exited=true unexpected_exit=false

FATAL: ERROR: peer exited (peer 0, pid 2588)
