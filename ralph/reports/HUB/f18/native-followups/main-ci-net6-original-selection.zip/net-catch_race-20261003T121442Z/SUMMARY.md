# Net smoke run net-20261003T121442Z-3468

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=3493 exited=true unexpected_exit=false
- peer 1 (client) pid=3494 exited=true unexpected_exit=false

FAILURES:
- guest received exactly one creature only after the confirmed caught finish
- guest received the host-confirmed canonical identity and stats; only caught_on_day is stamped at grant
