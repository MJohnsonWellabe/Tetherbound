# Net smoke run net-20261003T120428Z-2454

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2479 exited=true unexpected_exit=false
- peer 1 (client) pid=2480 exited=true unexpected_exit=false

FATAL: ERROR: peer 1 reported ERROR: 
