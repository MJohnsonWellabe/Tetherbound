# Net smoke run local-7880202

Scene: title
Peers: 1
Net conditions: clean (no proxy)

- peer 0 (host) pid=2559 exited=false unexpected_exit=false

FAILURES:
- peer 0 f18_traversal_refusal: no verdict
- F18 traversal refusal peer logs have no engine/script errors (peer 0: ERROR: x1)
