# Net smoke run local-10103169

Scene: world
Peers: 3
Net conditions: clean (no proxy)

- peer 0 (host) pid=19732 exited=false unexpected_exit=false
- peer 1 (client) pid=4392 exited=false unexpected_exit=false
- peer 2 (client) pid=13936 exited=false unexpected_exit=false

FATAL: ERROR: not every peer said hello within 180 s
