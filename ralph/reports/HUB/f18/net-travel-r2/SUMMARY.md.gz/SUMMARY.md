# Net smoke run local-10432311

Scene: title
Peers: 3
Net conditions: clean (no proxy)

- peer 0 (host) pid=12036 exited=true unexpected_exit=true
- peer 1 (client) pid=1968 exited=true unexpected_exit=false
- peer 2 (client) pid=15632 exited=true unexpected_exit=false

FATAL: ERROR: peer exited (peer 0, pid 12036)
