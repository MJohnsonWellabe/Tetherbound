# Net smoke run net-20261003T024739Z-2885

Scene: title
Peers: 3
Net conditions: clean (no proxy)

- peer 0 (host) pid=2911 exited=true unexpected_exit=false
- peer 1 (client) pid=2912 exited=true unexpected_exit=false
- peer 2 (client) pid=2913 exited=true unexpected_exit=false

FAILURES:
- peer 1 f18_touch: touch needs actual stone and ordinary world input
- F18 gameplay peer logs have no errors/warnings (peer 0: WARNING: x9; peer 1: WARNING: x17; peer 2: WARNING: x9)
