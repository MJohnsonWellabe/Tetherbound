# Net smoke run net-20261003T025536Z-3508

Scene: world
Peers: 3
Net conditions: clean (no proxy)

- peer 0 (host) pid=3535 exited=true unexpected_exit=false
- peer 1 (client) pid=3536 exited=true unexpected_exit=false
- peer 2 (client) pid=3537 exited=true unexpected_exit=false

FAILURES:
- the traveller never wrote a world file (["slot-0"])
