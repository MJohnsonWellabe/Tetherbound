# Net smoke run net-20261003T025853Z-3793

Scene: world
Peers: 3
Net conditions: clean (no proxy)

- peer 0 (host) pid=3818 exited=true unexpected_exit=false
- peer 1 (client) pid=3819 exited=true unexpected_exit=false
- peer 2 (client) pid=3820 exited=true unexpected_exit=false

ALL CHECKS PASSED
