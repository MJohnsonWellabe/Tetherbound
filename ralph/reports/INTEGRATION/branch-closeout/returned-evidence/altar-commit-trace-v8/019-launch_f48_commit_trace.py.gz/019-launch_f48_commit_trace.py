from pathlib import Path
import hashlib,json,os,subprocess,sys
primary=Path(r"D:/tetherbound/foundations-batch-check")
sys.path.insert(0,str(primary/"tools/net"))
from f48_ci_runner import configuration_overlay
profile_path=Path(r"D:/tetherbound/r3-f48/.tmp/f48-preboss-measured-v3-producer/profile.json")
expected="478a3ff3e465447b625737f4d17ae05e6b12fcb1c92cd4bc8a14ffe1713da015"
if hashlib.sha256(profile_path.read_bytes()).hexdigest()!=expected: raise ValueError("Immutable measured profile changed")
profile=json.loads(profile_path.read_bytes())
output=primary/".tmp/closeout/f48-complete-input-producer-commit-trace-v8"
if output.exists(): raise ValueError("Fresh native output required")
output.mkdir(parents=True)
coordinator=output/"coordinator-home";coordinator.mkdir()
env=dict(os.environ,TB_BUILD_PHASE_TRACE="1",TB_ALTAR_COMMIT_TRACE="1",TB_F48_PROFILE=str(profile_path),TB_PROOF_OUT=str(output/"proof"),TB_NET_OUT_DIR=str(output/"net-run"),TB_F48_PROCESS_PYTHON=sys.executable,APPDATA=str(coordinator),LOCALAPPDATA=str(coordinator),XDG_DATA_HOME=str(coordinator))
command=[r"C:/Users/mattj/.cache/tetherbound-tools/godot-4.7/Godot_v4.7-stable_win64_console.exe","--headless","--path",str(primary),"--script","res://tools/net/f48_prepare.gd"]
with configuration_overlay(primary,profile) as pins:
    (output/"invocation.json").write_text(json.dumps({"command":command,"profile_sha256":expected,"native_ground_source":json.loads((profile_path.parent/"source.json").read_bytes()),"effective_configuration":pins,"acceptance_credit":False},indent=2)+"\n",encoding="utf-8")
    with (output/"coordinator.log").open("wb") as log:
        result=subprocess.run(command,cwd=primary,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
print(json.dumps({"exit_code":result.returncode,"output":str(output),"acceptance_credit":False}))
sys.exit(result.returncode)
