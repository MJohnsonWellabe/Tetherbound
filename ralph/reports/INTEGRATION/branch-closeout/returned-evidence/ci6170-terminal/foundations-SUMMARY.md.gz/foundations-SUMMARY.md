# Net smoke run net-20261001T153343Z-2238

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2262 exited=true unexpected_exit=false
- peer 1 (client) pid=2263 exited=true unexpected_exit=false

FAILURES:
- peer 0 foundations_state roundtrip: host autosave_here refused
