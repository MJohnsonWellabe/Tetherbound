# Net smoke run net-20261001T153750Z-2691

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2714 exited=true unexpected_exit=false
- peer 1 (client) pid=2715 exited=true unexpected_exit=false

ALL CHECKS PASSED
