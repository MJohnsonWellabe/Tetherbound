# Net smoke run local-7902035

Scene: title
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=20528 exited=true unexpected_exit=false
- peer 1 (client) pid=144 exited=true unexpected_exit=false

FAILURES:
- #17 peer 0 f48_assert_altar_build -> FAIL -- Actual paid Altar bootstrap; no earned campaign credit. Wrong original accepted Altar transaction identity/receipt/price; memory: paid build changed an owned card/progression or did not persist exactly one receipt; disk: wrong exact item debit stone; disk: wrong exact item debit rootstone; disk: wro
