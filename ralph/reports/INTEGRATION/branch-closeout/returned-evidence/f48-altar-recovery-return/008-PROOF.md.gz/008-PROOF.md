# Two-peer proof: F48 genuine before-operation input producer

**Verdict: FAIL** (exit 1)

Scenario: `D:/tetherbound/foundations-batch-check/.tmp/closeout/f48-complete-input-producer-menu-trace-v6/coordinator-home/Godot/app_userdata/Tetherbound/f48-prepare_inputs-scenario.json`  
Run: `local-7902035`  
Rendered: no (headless)

Original full loop/oracles plus detached actual input snapshots; all24cut tests still required. DISCLOSED initial mechanics fixture: actual retained v28 characters/owned cards; added initial material stock, paid station records and starting pose. No earned campaign claim. Native producer, routes and terrain validation OPEN. See fixture-manifest.json. Native8a distinct v28 starter9 mechanics characters and immutable legacyboss rows. Detached initial preboss3legacygates, stock, measuredpose/stationorigins and11runtimefields disclosed. NO earned campaign/portal/key/relic/catch/feast/paidAltar claims. Explicit pre-boss legacy mechanics gates removed only in detached initial fixture; original rewards and all personal data retained. INITIAL Kitchen Spice rack attachment is a disclosed mechanics station fixture, not an earned upgrade/payment/transaction; real Master recipe, cooking and feed still required. One initial Basic Orb per actual character is disclosed stock for the real catch producer, never a caught companion or provenance grant. Explicit source-derived INPUT producer routes: actor/owned-ally placement, paused real Alpha RNG, real announced boss join, self-HP aid and ally placement, enemy HP ceiling0. No ordinary survival/balance/campaign credit. Captured source and every actual journal/owner write/ACK must be native; NOT a complete CI bundle.

## Failures

- #17 peer 0 f48_assert_altar_build -> FAIL -- Actual paid Altar bootstrap; no earned campaign credit. Wrong original accepted Altar transaction identity/receipt/price; memory: paid build changed an owned card/progression or did not persist exactly one receipt; disk: wrong exact item debit stone; disk: wrong exact item debit rootstone; disk: wro

| # | Peer | Step | Expected | Verdict | Detail |
|---|---|---|---|---|---|
| 1 | 0 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 1 | 1 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 2 | 0 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | loaded peer-0 (captured directory (split path)) as slot 0; realm 'meadows' booted as 'world'; character 'character-626300bee616b52bfa1d40ab32fb776a' |
| 3 | 1 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | Restored only authentic portable character through production owner; no world or locator copied |
| 4 | 0 | host | PASS | PASS | hosting udp/28901 as peer 1 |
| 5 | 1 | production_join | PASS | PASS | title returning entry built 'MeadowsPlayground' first, then JoinDriver joined 127.0.0.1:28901 as peer 470126850 after 394 frames |
| 6 | 0 | expect_peers | PASS | PASS | registry reports 2 peer(s) after 0 frames (0.0 s) |
| 6 | 1 | expect_peers | PASS | PASS | registry reports 2 peer(s) after 0 frames (0.0 s) |
| 7 | 0 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 7 | 1 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 8 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_open' x1 |
| 9 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 30 physics frames |
| 10 | 0 | f48_button — bootstrap_altar: ordinary input | PASS | PASS | pressed 'ui_accept' x1 |
| 11 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 15 physics frames |
| 12 | 0 | f48_build_cell — bootstrap_altar: ordinary input | PASS | PASS | pressed 'ui_accept' x1 |
| 13 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 30 physics frames |
| 14 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_place' x1 |
| 15 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 180 physics frames |
| 16 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_cancel' x1 |
| 17 | 0 | f48_assert_altar_build | PASS | FAIL **(unexpected)** | Actual paid Altar bootstrap; no earned campaign credit. Wrong original accepted Altar transaction identity/receipt/price; memory: paid build changed an owned card/progression or did not persist exactly one receipt; disk: wrong exact item debit stone; disk: wrong exact item debit rootstone; disk: wrong exact item debit ironwood; disk: paid build changed an owned card/progression or did not persist exactly one receipt; disk: accepted full after carrier differs from real owner; Accepted original before carrier differs from admitted source; disk_world: accepted journal absent or changed; disk_world: exact paid Altar record absent or duplicated |

## Captured files

- `f48-observations/f48_assert_altar_build-20528-449842017.json`
- `f48-witnesses/character-626300bee616b52bfa1d40ab32fb776a/initial-bootstrap.json`
- `f48-witnesses/character-a79c7bee9128c2ef03d266ce0352c666/initial-bootstrap.json`
