# Net smoke run local-7900939

Scene: title
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=4892 exited=false unexpected_exit=false
- peer 1 (client) pid=21028 exited=true unexpected_exit=false

FATAL: ERROR: peer silent (peer 0, no heartbeat for >15 s)
