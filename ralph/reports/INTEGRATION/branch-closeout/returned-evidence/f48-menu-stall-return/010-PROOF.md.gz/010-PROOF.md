# Two-peer proof: F48 genuine before-operation input producer

**Verdict: FAIL** (exit 2)

Scenario: `D:/tetherbound/foundations-batch-check/.tmp/closeout/f48-complete-input-producer-measured-v5/coordinator-home/Godot/app_userdata/Tetherbound/f48-prepare_inputs-scenario.json`  
Run: `local-7900939`  
Rendered: no (headless)

Original full loop/oracles plus detached actual input snapshots; all24cut tests still required. DISCLOSED initial mechanics fixture: actual retained v28 characters/owned cards; added initial material stock, paid station records and starting pose. No earned campaign claim. Native producer, routes and terrain validation OPEN. See fixture-manifest.json. Native8a distinct v28 starter9 mechanics characters and immutable legacyboss rows. Detached initial preboss3legacygates, stock, measuredpose/stationorigins and11runtimefields disclosed. NO earned campaign/portal/key/relic/catch/feast/paidAltar claims. Explicit pre-boss legacy mechanics gates removed only in detached initial fixture; original rewards and all personal data retained. INITIAL Kitchen Spice rack attachment is a disclosed mechanics station fixture, not an earned upgrade/payment/transaction; real Master recipe, cooking and feed still required. One initial Basic Orb per actual character is disclosed stock for the real catch producer, never a caught companion or provenance grant. Explicit source-derived INPUT producer routes: actor/owned-ally placement, paused real Alpha RNG, real announced boss join, self-HP aid and ally placement, enemy HP ceiling0. No ordinary survival/balance/campaign credit. Captured source and every actual journal/owner write/ACK must be native; NOT a complete CI bundle.

## Failures

- #9 peer 0 wait (bootstrap_altar: ordinary input) -> ERROR -- ERROR: peer silent (peer 0, no heartbeat for >15 s)
- ERROR: peer silent (peer 0, no heartbeat for >15 s)

| # | Peer | Step | Expected | Verdict | Detail |
|---|---|---|---|---|---|
| 1 | 0 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 1 | 1 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 2 | 0 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | loaded peer-0 (captured directory (split path)) as slot 0; realm 'meadows' booted as 'world'; character 'character-626300bee616b52bfa1d40ab32fb776a' |
| 3 | 1 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | Restored only authentic portable character through production owner; no world or locator copied |
| 4 | 0 | host | PASS | PASS | hosting udp/35521 as peer 1 |
| 5 | 1 | production_join | PASS | PASS | title returning entry built 'MeadowsPlayground' first, then JoinDriver joined 127.0.0.1:35521 as peer 2132142502 after 414 frames |
| 6 | 0 | expect_peers | PASS | PASS | registry reports 2 peer(s) after 0 frames (0.0 s) |
| 6 | 1 | expect_peers | PASS | PASS | registry reports 2 peer(s) after 0 frames (0.0 s) |
| 7 | 0 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 7 | 1 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 8 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_open' x1 |
| 9 | 0 | wait — bootstrap_altar: ordinary input | PASS | ERROR **(unexpected)** | ERROR: peer silent (peer 0, no heartbeat for >15 s) |

## Captured files

- `f48-witnesses/character-626300bee616b52bfa1d40ab32fb776a/initial-bootstrap.json`
- `f48-witnesses/character-a79c7bee9128c2ef03d266ce0352c666/initial-bootstrap.json`
