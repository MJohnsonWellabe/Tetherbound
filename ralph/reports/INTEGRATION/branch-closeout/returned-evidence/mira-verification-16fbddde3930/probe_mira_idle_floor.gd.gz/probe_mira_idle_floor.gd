extends SceneTree

const PLAYER := preload("res://scripts/player/player_controller.gd")

class ZeroFlatIdleGravity extends "res://scripts/player/player_controller.gd":
	func _apply_gravity(delta: float) -> void:
		if is_on_floor() and get_floor_normal().is_equal_approx(up_direction) \
				and Input.get_vector("move_left", "move_right", "move_forward", "move_back") == Vector2.ZERO:
			velocity.y = 0.0
		else:
			super._apply_gravity(delta)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var space := Node3D.new()
	root.add_child(space)
	var floor_body := StaticBody3D.new()
	floor_body.position = Vector3(26.0, 0.77, 2.0)
	var floor_shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(3.98, 0.30, 5.98)
	floor_shape.shape = box
	floor_body.add_child(floor_shape)
	space.add_child(floor_body)
	for mode: String in ["original_controller", "zero_flat_idle_gravity"]:
		var body: CharacterBody3D = PLAYER.new() if mode == "original_controller" else ZeroFlatIdleGravity.new()
		body.name = "DiagnosticPlayer"
		body.position = Vector3(27.0260849, 0.922, 3.00220108)
		body.floor_max_angle = 0.7854
		body.floor_snap_length = 0.4
		var collision := CollisionShape3D.new()
		collision.name = "Collision"
		collision.position.y = 0.9
		var capsule := CapsuleShape3D.new()
		capsule.height = 1.8
		capsule.radius = 0.4
		collision.shape = capsule
		body.add_child(collision)
		space.add_child(body)
		for index in 180:
			await physics_frame
			if index in [1, 2, 10, 30, 90, 179]:
				var parameters := PhysicsTestMotionParameters3D.new()
				parameters.from = body.global_transform
				parameters.motion = Vector3.ZERO
				parameters.margin = body.safe_margin
				parameters.recovery_as_collision = true
				parameters.max_collisions = 8
				var result := PhysicsTestMotionResult3D.new()
				var hit := PhysicsServer3D.body_test_motion(body.get_rid(), parameters, result)
				print("MIRA_IDLE_FLOOR_DIAGNOSTIC=" + JSON.stringify({
					"diagnostic_only": true, "synthetic_pose_and_box": true,
					"mode": mode, "frame": index, "foot": body.global_position.y,
					"floor_top": floor_body.global_position.y + box.size.y * 0.5,
					"normal": str(body.get_floor_normal()), "grounded": body.is_on_floor(),
					"vertical_velocity": body.velocity.y, "hit": hit,
					"recovery": str(result.get_travel()), "recovery_length": result.get_travel().length(),
					"skin": body.safe_margin, "original_skin_check": result.get_travel().length() <= body.safe_margin + 0.00001,
					"contact_count": result.get_collision_count(),
				}))
		body.queue_free()
		await process_frame
	space.queue_free()
	await process_frame
	quit(0)
