# Net smoke run root-two_peers_boot-b1c6bb934e92

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=21256 exited=true unexpected_exit=false
- peer 1 (client) pid=16668 exited=true unexpected_exit=false

ALL CHECKS PASSED
