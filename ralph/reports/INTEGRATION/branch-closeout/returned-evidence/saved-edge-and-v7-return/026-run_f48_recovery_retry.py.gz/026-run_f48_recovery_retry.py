import datetime,hashlib,json,pathlib,re,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parents[2]
launcher=root/'.tmp/closeout/launch_f48_recovery_retry.py'
profile=pathlib.Path('D:/tetherbound/r3-f48/.tmp/f48-preboss-measured-v3-producer/profile.json')
exe=pathlib.Path('C:/Users/mattj/.cache/tetherbound-tools/godot-4.7/Godot_v4.7-stable_win64_console.exe')
owner='01a0f573-f081-7673-8b74-fd466ebdff9e';lock=pathlib.Path('D:/tetherbound/RENDER_LOCK.json')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def live():return subprocess.check_output(['powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'Godot' }).Count"],text=True).strip()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert live()=='0' and not json.loads(lock.read_text(encoding='utf-8-sig')).get('held_by')
assert not git('status','--porcelain','--untracked-files=no')
head=git('rev-parse','HEAD')
assert digest(profile)=='478a3ff3e465447b625737f4d17ae05e6b12fcb1c92cd4bc8a14ffe1713da015'
assert digest(exe)=='d8055fb8c7e7f5010d7439ec69be051554055dae55a265f8647bd7301c34161c'
paths=[p for p in git('ls-files','-z').split('\0') if p and (p=='project.godot' or (p.split('/')[0] in {'scripts','autoload','tests','tools','scenes','data','shaders','addons'} and pathlib.Path(p).suffix in {'.gd','.json','.tscn','.tres','.cfg','.gdextension','.gdshader','.gdshaderinc'}))]
def closure():return {p:digest(root/p) for p in paths}
before=closure();configuration={root/'data/config'/pathlib.Path(r['file']).name:(root/'data/config'/pathlib.Path(r['file']).name).read_bytes() for r in json.loads(profile.read_bytes())['test_configuration']}
out=root/'.tmp/closeout'/('f48-recovery-wrapper-'+head[:12]);out.mkdir(exist_ok=False)
receipt={'head':head,'source_before':before,'launcher':str(launcher),'launcher_sha256':digest(launcher),'profile_sha256':digest(profile),'engine_sha256':digest(exe),'watchdog_seconds':3900,'watchdog_basis':'Original full input-producer scenario3600 plus build300; internal heartbeat and transaction bounds unchanged','acceptance_credit':False}
def save():(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
save();lock.write_text(json.dumps({'held_by':owner,'operation':'Actual co-op menu phase attribution and original durable input producer','head':head,'since':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n',encoding='utf-8')
start=time.monotonic();proc=None
try:
    with (out/'wrapper.log').open('wb') as stream:
        proc=subprocess.Popen([sys.executable,str(launcher)],cwd=root,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        receipt['pid']=proc.pid;save()
        try:proc.wait(timeout=3900)
        except subprocess.TimeoutExpired:
            receipt['timed_out']=True;subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True);proc.wait(timeout=30)
    receipt['exit']=proc.returncode
finally:
    receipt['elapsed_seconds']=time.monotonic()-start
    receipt['engine_handles_after']=live()
    if receipt['engine_handles_after']=='0':
        overlay_lock=root/'.tmp/f48-native-overlay.lock'
        if overlay_lock.exists():
            overlay_owner=json.loads(overlay_lock.read_text())
            assert proc is not None and overlay_owner['pid']==proc.pid,'Refuse foreign overlay lock recovery'
            for path,original in configuration.items():path.write_bytes(original);assert path.read_bytes()==original
            overlay_lock.unlink();receipt['owned_watchdog_configuration_recovery']=True
        assert all(p.read_bytes()==b for p,b in configuration.items())
        receipt['source_after']=closure();receipt['source_unchanged']=receipt['source_after']==before
        assert receipt['source_unchanged'] and git('rev-parse','HEAD')==head and not git('status','--porcelain','--untracked-files=no')
        if json.loads(lock.read_text(encoding='utf-8-sig')).get('held_by')==owner:lock.write_text('{}\n',encoding='utf-8')
    logs=list(out.glob('*.log'))+list((root/'.tmp/closeout/f48-complete-input-producer-recovery-v7').rglob('*.log'))
    receipt['logs']=[{'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size,'errors':[s for s in p.read_text(encoding='utf-8',errors='replace').splitlines() if re.search(r'SCRIPT ERROR|Parse Error|^ERROR:|ObjectDB instances leaked|resources still in use',s,re.I)]} for p in logs]
    save()
print(json.dumps({k:v for k,v in receipt.items() if k not in {'source_before','source_after','logs'}},indent=2),flush=True)
raise SystemExit(1 if receipt.get('exit',1) or receipt.get('timed_out') or receipt['engine_handles_after']!='0' or not receipt.get('source_unchanged') or any(r['errors'] for r in receipt['logs']) else 0)
