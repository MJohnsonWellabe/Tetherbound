# Net smoke run net-20261001T124344Z-3024

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=3048 exited=false unexpected_exit=false
- peer 1 (client) pid=3049 exited=true unexpected_exit=false

FAILURES:
- both peers felled the Warden (no verdict)
