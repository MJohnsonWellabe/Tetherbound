# Net smoke run root-veridian_relic_key-cf1bf765b398

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=21172 exited=true unexpected_exit=false
- peer 1 (client) pid=19564 exited=true unexpected_exit=false

FATAL: ERROR: peer 0 reported ERROR: shared trainer HP fixture is not bound to this opponent
