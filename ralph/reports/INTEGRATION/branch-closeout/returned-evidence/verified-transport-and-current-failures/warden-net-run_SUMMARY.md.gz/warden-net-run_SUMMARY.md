# Net smoke run root-veridian_relic_key-83d9dada76b6

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=5576 exited=false unexpected_exit=false
- peer 1 (client) pid=19416 exited=true unexpected_exit=false

FAILURES:
- both peers felled the Warden (no verdict)
