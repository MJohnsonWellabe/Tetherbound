# Net smoke run root-veridian_relic_key-624b1031217b

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=20024 exited=true unexpected_exit=false
- peer 1 (client) pid=20408 exited=true unexpected_exit=false

ALL CHECKS PASSED
