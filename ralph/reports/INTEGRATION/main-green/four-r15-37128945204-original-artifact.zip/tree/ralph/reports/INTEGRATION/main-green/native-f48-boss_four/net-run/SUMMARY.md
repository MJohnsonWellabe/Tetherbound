# Net smoke run f48-actual-2591

Scene: title
Peers: 4
Net conditions: clean (no proxy)

- peer 0 (host) pid=2602 exited=true unexpected_exit=false
- peer 1 (client) pid=2603 exited=true unexpected_exit=false
- peer 2 (client) pid=2604 exited=true unexpected_exit=false
- peer 3 (client) pid=2605 exited=true unexpected_exit=false

FAILURES:
- #36 peer 0 f48_fixture_trainer_fight (boss_fight: disclosed mechanics fixture) -> FAIL -- the battle never resolved in 8760 frames (45 swings, 1 of their creatures met, 4 still queued); enemy=burrowback hp=0.000/242.000 quick_ready=false fighting=true active_hp=177.600 fainted=false refusal={ "kind": "strike_intent", "code": "pending_vitals", "reason": "The original health change is stil
