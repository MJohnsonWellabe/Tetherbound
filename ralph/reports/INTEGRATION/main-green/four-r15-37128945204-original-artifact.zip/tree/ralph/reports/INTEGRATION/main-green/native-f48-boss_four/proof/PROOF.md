# Two-peer proof: F48 genuine four-peer boss input producer

**Verdict: FAIL** (exit 1)

Scenario: `/home/runner/work/Tetherbound/Tetherbound/ralph/reports/INTEGRATION/main-green/native-f48-boss_four/coordinator-home/godot/app_userdata/Tetherbound/f48-prepare_boss_four-scenario.json`  
Run: `f48-actual-2591`  
Rendered: no (headless)

Original four-peer boss oracle after exact input retention; no earned campaign credit. DISCLOSED initial mechanics fixture: actual retained v28 characters/owned cards; added initial material stock, paid station records and starting pose. No earned campaign claim. Native producer, routes and terrain validation OPEN. See fixture-manifest.json. Original native shared_boss saves retained by the prior integration session. These are disclosed mechanics starter-level-9 sources, not earned redesigned campaign checkpoints. No new character, UID, level, receipt or outcome is synthesized. The existing fixture producer separately discloses initial stock, physical setup and legacy pre-boss flags. Explicit pre-boss legacy mechanics gates removed only in detached initial fixture; original rewards and all personal data retained. INITIAL Kitchen Spice rack attachment is a disclosed mechanics station fixture, not an earned upgrade/payment/transaction; real Master recipe, cooking and feed still required. One initial Basic Orb per actual character is disclosed stock for the real catch producer, never a caught companion or provenance grant. Four original distinct participants. Disclosed named actor/ally placement, actual announced boss joins and self-HP aid. No enemy HP ceiling, authored outcome or earned campaign credit.

## Failures

- #36 peer 0 f48_fixture_trainer_fight (boss_fight: disclosed mechanics fixture) -> FAIL -- the battle never resolved in 8760 frames (45 swings, 1 of their creatures met, 4 still queued); enemy=burrowback hp=0.000/242.000 quick_ready=false fighting=true active_hp=177.600 fainted=false refusal={ "kind": "strike_intent", "code": "pending_vitals", "reason": "The original health change is stil

| # | Peer | Step | Expected | Verdict | Detail |
|---|---|---|---|---|---|
| 1 | 0 | f48_watch_owner_saves | PASS | PASS | Read-only producer actual owner BOOL-save observer |
| 1 | 1 | f48_watch_owner_saves | PASS | PASS | Read-only producer actual owner BOOL-save observer |
| 1 | 2 | f48_watch_owner_saves | PASS | PASS | Read-only producer actual owner BOOL-save observer |
| 1 | 3 | f48_watch_owner_saves | PASS | PASS | Read-only producer actual owner BOOL-save observer |
| 2 | 0 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 2 | 1 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 2 | 2 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 2 | 3 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 3 | 0 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | loaded peer-0 (captured directory (split path)) as slot 0; realm 'meadows' booted as 'world'; character 'character-626300bee616b52bfa1d40ab32fb776a' |
| 4 | 1 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | Restored only authentic portable character through production owner; no world or locator copied |
| 5 | 2 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | Restored only authentic portable character through production owner; no world or locator copied |
| 6 | 3 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | Restored only authentic portable character through production owner; no world or locator copied |
| 7 | 0 | host | PASS | PASS | hosting udp/32201 as peer 1 |
| 8 | 1 | production_join | PASS | PASS | title returning entry built 'MeadowsPlayground' first, then JoinDriver joined 127.0.0.1:32201 as peer 1694863812 after 114 frames |
| 9 | 2 | production_join | PASS | PASS | title returning entry built 'MeadowsPlayground' first, then JoinDriver joined 127.0.0.1:32201 as peer 1202188119 after 142 frames |
| 10 | 3 | production_join | PASS | PASS | title returning entry built 'MeadowsPlayground' first, then JoinDriver joined 127.0.0.1:32201 as peer 670459903 after 158 frames |
| 11 | 0 | expect_peers | PASS | PASS | registry reports 4 peer(s) after 0 frames (0.0 s) |
| 11 | 1 | expect_peers | PASS | PASS | registry reports 4 peer(s) after 0 frames (0.0 s) |
| 11 | 2 | expect_peers | PASS | PASS | registry reports 4 peer(s) after 0 frames (0.0 s) |
| 11 | 3 | expect_peers | PASS | PASS | registry reports 4 peer(s) after 0 frames (0.0 s) |
| 12 | 0 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 12 | 1 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 12 | 2 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 12 | 3 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 13 | 0 | f48_assert_snapshot — Read actual memory/disk carriers before any capture autosave | PASS | PASS | Read-only explicit input source unchanged_original_admitted_disk_no_initial_memory_disk_convergence_or_saved_live_care_bond_claim:  |
| 13 | 1 | f48_assert_snapshot — Read actual memory/disk carriers before any capture autosave | PASS | PASS | Read-only explicit input source unchanged_original_admitted_disk_no_initial_memory_disk_convergence_or_saved_live_care_bond_claim:  |
| 13 | 2 | f48_assert_snapshot — Read actual memory/disk carriers before any capture autosave | PASS | PASS | Read-only explicit input source unchanged_original_admitted_disk_no_initial_memory_disk_convergence_or_saved_live_care_bond_claim:  |
| 13 | 3 | f48_assert_snapshot — Read actual memory/disk carriers before any capture autosave | PASS | PASS | Read-only explicit input source unchanged_original_admitted_disk_no_initial_memory_disk_convergence_or_saved_live_care_bond_claim:  |
| 14 | 0 | f48_capture_durable — Retain exact actual owner BOOL-saved input bytes without autosave repair; no earned campaign credit | PASS | PASS | Copied exact saved input bytes from unchanged original admitted disk; no initial memory/disk convergence or saved live care/bond claim; no autosave repair |
| 14 | 1 | f48_capture_durable — Retain exact actual owner BOOL-saved input bytes without autosave repair; no earned campaign credit | PASS | PASS | Copied exact saved input bytes from unchanged original admitted disk; no initial memory/disk convergence or saved live care/bond claim; no autosave repair |
| 14 | 2 | f48_capture_durable — Retain exact actual owner BOOL-saved input bytes without autosave repair; no earned campaign credit | PASS | PASS | Copied exact saved input bytes from unchanged original admitted disk; no initial memory/disk convergence or saved live care/bond claim; no autosave repair |
| 14 | 3 | f48_capture_durable — Retain exact actual owner BOOL-saved input bytes without autosave repair; no earned campaign credit | PASS | PASS | Copied exact saved input bytes from unchanged original admitted disk; no initial memory/disk convergence or saved live care/bond claim; no autosave repair |
| 15 | 0 | f48_assert | PASS | PASS | Exact durable assertions: passed |
| 16 | 0 | f48_deploy_owned — boss_prepare_0: ordinary input | PASS | PASS | Ordinary recall input must deploy an original owned companion without changing party UIDs |
| 17 | 0 | f48_fixture_approach — boss_prepare_0: disclosed mechanics fixture | PASS | PASS | Disclosed authored-site placement; actual actor floor/proximity required before ordinary prompt |
| 18 | 1 | f48_assert | PASS | PASS | Exact durable assertions: passed |
| 19 | 1 | f48_deploy_owned — boss_prepare_1: ordinary input | PASS | PASS | Ordinary recall input must deploy an original owned companion without changing party UIDs |
| 20 | 1 | f48_fixture_approach — boss_prepare_1: disclosed mechanics fixture | PASS | PASS | Disclosed authored-site placement; actual actor floor/proximity required before ordinary prompt |
| 21 | 2 | f48_assert | PASS | PASS | Exact durable assertions: passed |
| 22 | 2 | f48_deploy_owned — boss_prepare_2: ordinary input | PASS | PASS | Ordinary recall input must deploy an original owned companion without changing party UIDs |
| 23 | 2 | f48_fixture_approach — boss_prepare_2: disclosed mechanics fixture | PASS | PASS | Disclosed authored-site placement; actual actor floor/proximity required before ordinary prompt |
| 24 | 3 | f48_assert | PASS | PASS | Exact durable assertions: passed |
| 25 | 3 | f48_deploy_owned — boss_prepare_3: ordinary input | PASS | PASS | Ordinary recall input must deploy an original owned companion without changing party UIDs |
| 26 | 3 | f48_fixture_approach — boss_prepare_3: disclosed mechanics fixture | PASS | PASS | Disclosed authored-site placement; actual actor floor/proximity required before ordinary prompt |
| 27 | 0 | press — boss_start: ordinary input | PASS | PASS | pressed 'interact' x1 |
| 28 | 0 | wait — boss_start: ordinary input | PASS | PASS | waited 45 physics frames |
| 29 | 0 | f48_dialogue — boss_start: ordinary input | PASS | PASS | Actual named conversation completion by ordinary interact input.  |
| 30 | 0 | wait — boss_start: ordinary input | PASS | PASS | waited 90 physics frames |
| 31 | 1 | f48_fixture_join_boss — boss_join_1: disclosed mechanics fixture | PASS | PASS | joined 1:1 beside 'burrowback' at (17.6, 7658.2) |
| 32 | 2 | f48_fixture_join_boss — boss_join_2: disclosed mechanics fixture | PASS | PASS | joined 1:1 beside 'burrowback' at (17.6, 7658.2) |
| 33 | 3 | f48_fixture_join_boss — boss_join_3: disclosed mechanics fixture | PASS | PASS | joined 1:1 beside 'burrowback' at (17.6, 7658.2) |
| 34 | 0 | probe encounter — Actual host encounter before victory | PASS + {"kind":"boss","phase":"active"} | PASS | {"available":true,"bound_id":"1:1","fighting":true,"host_now_ms":609775.0,"host_strike_receipts":[],"host_strike_transaction":{},"id":"1:1","joinable":[],"kind":"boss","my_creature_hp":136.352827876519,"my_creature_max_hp":177.6,"my_creature_pos":[12.0408172607422,6.17213344573975,7660.619140625],"opponent_card":{"attack":30.0,"base_attack":15.0,"base_defence":23.0,"base_hp":110.0,"battles_fought":0.0,"bond":0.0,"boost_attack":0.0,"boost_defence":0.0,"boost_hp":0.0,"caught_on_day":0.0,"creature_type":"ground","defence":46.0,"display_name":"Burrowback","distance_m_together":0.0,"energy":0.0,"fainted":false,"feeds_together":0.0,"happiness":55.0,"hp":242.0,"iv_attack":0.5,"iv_defence":0.5,"iv_hp":0.5,"known_moves":["burrow_strike","tremor_roll","ultimate_ground_wall","shove","quake_ring","rock_throw"],"landmarks_visited_together":0.0,"level":21.0,"levels_gained_with_you":0.0,"loadout_last_e |
| 35 | 0 | f48_participants | PASS | PASS | Actual host participant identities: ["character-626300bee616b52bfa1d40ab32fb776a", "character-a79c7bee9128c2ef03d266ce0352c666", "character-219d55c08e26227b4ccba505c7b3c409", "character-92a3946dcc1ebef20650b2c4f6675001"] |
| 36 | 0 | f48_fixture_trainer_fight — boss_fight: disclosed mechanics fixture | PASS | FAIL **(unexpected)** | the battle never resolved in 8760 frames (45 swings, 1 of their creatures met, 4 still queued); enemy=burrowback hp=0.000/242.000 quick_ready=false fighting=true active_hp=177.600 fainted=false refusal={ "kind": "strike_intent", "code": "pending_vitals", "reason": "The original health change is still being saved." } bound=1:1; actual_round_diagnostic=user://ordinary-round-failure-2602-24911.json saved=true |

## Captured files

- `f48-fallback-completions/character-219d55c08e26227b4ccba505c7b3c409/completion-2604-1.json`
- `f48-fallback-completions/character-219d55c08e26227b4ccba505c7b3c409/completion-2604-2.json`
- `f48-fallback-completions/character-219d55c08e26227b4ccba505c7b3c409/completion-2604-3.json`
- `f48-fallback-completions/character-626300bee616b52bfa1d40ab32fb776a/completion-2602-1.json`
- `f48-fallback-completions/character-626300bee616b52bfa1d40ab32fb776a/completion-2602-2.json`
- `f48-fallback-completions/character-92a3946dcc1ebef20650b2c4f6675001/completion-2605-1.json`
- `f48-fallback-completions/character-92a3946dcc1ebef20650b2c4f6675001/completion-2605-2.json`
- `f48-fallback-completions/character-92a3946dcc1ebef20650b2c4f6675001/completion-2605-3.json`
- `f48-fallback-completions/character-a79c7bee9128c2ef03d266ce0352c666/completion-2603-1.json`
- `f48-fallback-completions/character-a79c7bee9128c2ef03d266ce0352c666/completion-2603-2.json`
- `f48-fallback-completions/character-a79c7bee9128c2ef03d266ce0352c666/completion-2603-3.json`
- `f48-fallback-completions/character-a79c7bee9128c2ef03d266ce0352c666/completion-2603-4.json`
- `f48-fixture-approaches/2602-warden_aldis-561333756.json`
- `f48-fixture-approaches/2603-warden_aldis-566654021.json`
- `f48-fixture-approaches/2604-warden_aldis-572597786.json`
- `f48-fixture-approaches/2605-warden_aldis-579791795.json`
- `f48-fixture-fights/2602-warden_aldis-1372187735.json`
- `f48-observations/f48_assert-2602-552875824.json`
- `f48-observations/f48_assert-2603-562097247.json`
- `f48-observations/f48_assert-2604-567068595.json`
- `f48-observations/f48_assert-2605-572830574.json`
- `f48-observations/f48_assert_snapshot-2602-547986028.json`
- `f48-observations/f48_assert_snapshot-2603-548869220.json`
- `f48-observations/f48_assert_snapshot-2604-549468836.json`
- `f48-observations/f48_assert_snapshot-2605-550014421.json`
- `f48-owner-saves/character-626300bee616b52bfa1d40ab32fb776a/owner-1cd439d369037f2bb38a21d3ea36477dada0a98f8a9dcad5fe8e916e41c8dec1-1.json`
- `f48-owner-saves/character-a79c7bee9128c2ef03d266ce0352c666/owner-8b3fd1699681206223204f12820fe87367596eb3eac46cbc1c81bde62df0afb4-1.json`
- `f48-passive/actual-2602.jsonl`
- `f48-passive/actual-2603.jsonl`
- `f48-passive/actual-2604.jsonl`
- `f48-passive/actual-2605.jsonl`
- `f48-witnesses/character-219d55c08e26227b4ccba505c7b3c409/admitted.json`
- `f48-witnesses/character-626300bee616b52bfa1d40ab32fb776a/admitted.json`
- `f48-witnesses/character-92a3946dcc1ebef20650b2c4f6675001/admitted.json`
- `f48-witnesses/character-a79c7bee9128c2ef03d266ce0352c666/admitted.json`
- `peer-0/f48-boss-four-input/characters/redesign-v28/character-626300bee616b52bfa1d40ab32fb776a/character.json`
- `peer-0/f48-boss-four-input/saves/redesign-v28/characters/character-626300bee616b52bfa1d40ab32fb776a/character.json`
- `peer-0/f48-boss-four-input/saves/redesign-v28/slot_0.json`
- `peer-0/f48-boss-four-input/saves/redesign-v28/worlds/slot-0/world.json`
- `peer-0/f48-boss-four-input/worlds/redesign-v28/slot-0/world.json`
- `peer-1/f48-boss-four-input/characters/redesign-v28/character-a79c7bee9128c2ef03d266ce0352c666/character.json`
- `peer-1/f48-boss-four-input/saves/redesign-v28/characters/character-a79c7bee9128c2ef03d266ce0352c666/character.json`
- `peer-2/f48-boss-four-input/characters/redesign-v28/character-219d55c08e26227b4ccba505c7b3c409/character.json`
- `peer-2/f48-boss-four-input/saves/redesign-v28/characters/character-219d55c08e26227b4ccba505c7b3c409/character.json`
- `peer-2/f48-boss-four-input/saves/redesign-v28/slot_0.json`
- `peer-2/f48-boss-four-input/saves/redesign-v28/worlds/slot-0/world.json`
- `peer-3/f48-boss-four-input/characters/redesign-v28/character-92a3946dcc1ebef20650b2c4f6675001/character.json`
- `peer-3/f48-boss-four-input/saves/redesign-v28/characters/character-92a3946dcc1ebef20650b2c4f6675001/character.json`
- `peer-3/f48-boss-four-input/saves/redesign-v28/slot_0.json`
- `peer-3/f48-boss-four-input/saves/redesign-v28/worlds/slot-0/world.json`
