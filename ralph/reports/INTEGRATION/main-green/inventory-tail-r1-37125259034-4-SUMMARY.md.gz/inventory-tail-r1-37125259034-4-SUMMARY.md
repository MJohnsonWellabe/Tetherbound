# Net smoke run net-20261003T131206Z-2472

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2497 exited=true unexpected_exit=false
- peer 1 (client) pid=2498 exited=true unexpected_exit=false

ALL CHECKS PASSED
