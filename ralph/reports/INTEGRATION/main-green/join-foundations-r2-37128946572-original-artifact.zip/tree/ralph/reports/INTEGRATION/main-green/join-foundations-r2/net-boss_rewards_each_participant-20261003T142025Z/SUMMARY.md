# Net smoke run net-20261003T142025Z-2793

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2820 exited=true unexpected_exit=false
- peer 1 (client) pid=2821 exited=true unexpected_exit=false

FAILURES:
- the host's record now holds 2 participants (got 1)
- peer 0 beat Bryn's whole team (the battle never resolved in 2160 frames (13 swings, 1 of their creatures met, 1 still queued); enemy=bramblebun hp=0.000/100.700 quick_ready=false fighting=true active_hp=118.324 fainted=false refusal={  } bound=1:1; actual_round_diagnostic=user://ordinary-round-failure-2820-2522.json saved=true)
