# Net smoke run net-20261003T142356Z-3086

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=3112 exited=true unexpected_exit=false
- peer 1 (client) pid=3113 exited=true unexpected_exit=false

FAILURES:
- peer 1 production_join : no verdict
