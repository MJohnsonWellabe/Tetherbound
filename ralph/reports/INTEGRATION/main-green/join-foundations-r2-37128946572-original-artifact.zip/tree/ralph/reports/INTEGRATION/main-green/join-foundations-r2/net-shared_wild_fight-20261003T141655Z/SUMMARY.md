# Net smoke run net-20261003T141655Z-2498

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2524 exited=true unexpected_exit=false
- peer 1 (client) pid=2525 exited=true unexpected_exit=false

ALL CHECKS PASSED
