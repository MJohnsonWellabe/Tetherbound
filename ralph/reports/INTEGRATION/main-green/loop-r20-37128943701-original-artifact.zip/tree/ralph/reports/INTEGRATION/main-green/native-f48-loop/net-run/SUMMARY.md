# Net smoke run f48-actual-2258

Scene: title
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2269 exited=true unexpected_exit=false
- peer 1 (client) pid=2270 exited=true unexpected_exit=false

FAILURES:
- #25 peer 1 f48_fixture_capture -> FAIL -- Actual shared Alpha catch must create exactly one durable source companion; no offered/provenance grant. Owner plan: owner_action_baseline_conflict
