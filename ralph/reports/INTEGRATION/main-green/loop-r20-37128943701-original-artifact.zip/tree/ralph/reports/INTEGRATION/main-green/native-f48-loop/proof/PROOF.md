# Two-peer proof: F48 genuine before-operation input producer

**Verdict: FAIL** (exit 1)

Scenario: `/home/runner/work/Tetherbound/Tetherbound/ralph/reports/INTEGRATION/main-green/native-f48-loop/coordinator-home/godot/app_userdata/Tetherbound/f48-prepare_inputs-scenario.json`  
Run: `f48-actual-2258`  
Rendered: no (headless)

Original full loop/oracles plus detached actual input snapshots; all24cut tests still required. DISCLOSED initial mechanics fixture: actual retained v28 characters/owned cards; added initial material stock, paid station records and starting pose. No earned campaign claim. Native producer, routes and terrain validation OPEN. See fixture-manifest.json. Original native shared_boss saves retained by the prior integration session. These are disclosed mechanics starter-level-9 sources, not earned redesigned campaign checkpoints. No new character, UID, level, receipt or outcome is synthesized. The existing fixture producer separately discloses initial stock, physical setup and legacy pre-boss flags. Explicit pre-boss legacy mechanics gates removed only in detached initial fixture; original rewards and all personal data retained. INITIAL Kitchen Spice rack attachment is a disclosed mechanics station fixture, not an earned upgrade/payment/transaction; real Master recipe, cooking and feed still required. One initial Basic Orb per actual character is disclosed stock for the real catch producer, never a caught companion or provenance grant. Explicit source-derived INPUT producer routes: actor/owned-ally placement, paused real Alpha RNG, real announced boss join, self-HP aid and ally placement, enemy HP ceiling0. No ordinary survival/balance/campaign credit. Captured source and every actual journal/owner write/ACK must be native; NOT a complete CI bundle.

## Failures

- #25 peer 1 f48_fixture_capture -> FAIL -- Actual shared Alpha catch must create exactly one durable source companion; no offered/provenance grant. Owner plan: owner_action_baseline_conflict

| # | Peer | Step | Expected | Verdict | Detail |
|---|---|---|---|---|---|
| 1 | 0 | f48_watch_owner_saves — Arm actual saved-edge observation before production admission; no save or ACK | PASS | PASS | Read-only producer actual owner BOOL-save observer |
| 1 | 1 | f48_watch_owner_saves — Arm actual saved-edge observation before production admission; no save or ACK | PASS | PASS | Read-only producer actual owner BOOL-save observer |
| 2 | 0 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 2 | 1 | f48_require_configuration — Pin disclosed effective mechanics configuration before any saved-input admission | PASS | PASS | Exact effective test configuration pinned separately; production defaults unchanged |
| 3 | 0 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | loaded peer-0 (captured directory (split path)) as slot 0; realm 'meadows' booted as 'world'; character 'character-626300bee616b52bfa1d40ab32fb776a' |
| 4 | 1 | load_save — DISCLOSED saved-input setup; original guest character only, no borrowed world | PASS | PASS | Restored only authentic portable character through production owner; no world or locator copied |
| 5 | 0 | host | PASS | PASS | hosting udp/28361 as peer 1 |
| 6 | 1 | production_join | PASS | PASS | title returning entry built 'MeadowsPlayground' first, then JoinDriver joined 127.0.0.1:28361 as peer 546173039 after 96 frames |
| 7 | 0 | expect_peers | PASS | PASS | registry reports 2 peer(s) after 0 frames (0.0 s) |
| 7 | 1 | expect_peers | PASS | PASS | registry reports 2 peer(s) after 0 frames (0.0 s) |
| 8 | 0 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 8 | 1 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 9 | 0 | f48_watch_altar_save — Read-only actual transaction owner BOOL-save edge; no care exclusions or state writes | PASS | PASS | Read-only exact host/owner save edges armed before original paid build input |
| 10 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_open' x1 |
| 11 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 30 physics frames |
| 12 | 0 | f48_button — bootstrap_altar: ordinary input | PASS | PASS | pressed 'ui_accept' x1 |
| 13 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 15 physics frames |
| 14 | 0 | f48_build_cell — bootstrap_altar: ordinary input | PASS | PASS | pressed 'ui_accept' x1 |
| 15 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 30 physics frames |
| 16 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_place' x1 |
| 17 | 0 | wait — bootstrap_altar: ordinary input | PASS | PASS | waited 180 physics frames |
| 18 | 0 | press — bootstrap_altar: ordinary input | PASS | PASS | pressed 'build_cancel' x1 |
| 19 | 0 | f48_assert_altar_build | PASS | PASS | Actual paid Altar bootstrap; no earned campaign credit.  |
| 20 | 1 | f48_assert | PASS | PASS | Exact durable assertions: passed |
| 21 | 0 | f48_assert_snapshot — Read actual memory/disk carriers before any capture autosave | PASS | PASS | Read-only explicit input source actual_owner_BOOL_edge_full_canonical_after_and_accepted_ACK:  |
| 21 | 1 | f48_assert_snapshot — Read actual memory/disk carriers before any capture autosave | PASS | PASS | Read-only explicit input source unchanged_original_admitted_disk_no_initial_memory_disk_convergence_or_saved_live_care_bond_claim:  |
| 22 | 0 | f48_capture_durable — Retain exact actual owner BOOL-saved input bytes without autosave repair; no earned campaign credit | PASS | PASS | Copied exact saved input bytes from actual newer owner BOOL-save/accepted ACK with full canonical after carriers; no autosave repair |
| 22 | 1 | f48_capture_durable — Retain exact actual owner BOOL-saved input bytes without autosave repair; no earned campaign credit | PASS | PASS | Copied exact saved input bytes from unchanged original admitted disk; no initial memory/disk convergence or saved live care/bond claim; no autosave repair |
| 23 | 0 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 23 | 1 | f48_witness | PASS | PASS | Read actual files without autosave; full immutable witness retained |
| 24 | 0 | f48_fixture_capture | PASS | PASS | paused host runtime; next roll 0.012550 is below min catch bound 0.020000 |
| 25 | 1 | f48_fixture_capture | PASS | FAIL **(unexpected)** | Actual shared Alpha catch must create exactly one durable source companion; no offered/provenance grant. Owner plan: owner_action_baseline_conflict |

## Captured files

- `f48-altar-save-edges/character-626300bee616b52bfa1d40ab32fb776a/after_host_write_before_delivery.json`
- `f48-altar-save-edges/character-626300bee616b52bfa1d40ab32fb776a/after_owner_write_before_ack.json`
- `f48-observations/f48-capture-host-diagnostic-25-200043337.json`
- `f48-observations/f48_assert-2270-171282610.json`
- `f48-observations/f48_assert_altar_build-2269-170809672.json`
- `f48-observations/f48_assert_snapshot-2269-171696254.json`
- `f48-observations/f48_assert_snapshot-2270-172371941.json`
- `f48-observations/f48_fixture_capture-2269-177075091.json`
- `f48-observations/f48_fixture_capture-2270-195461573.json`
- `f48-owner-saves/character-626300bee616b52bfa1d40ab32fb776a/owner-74ad9fbd5737256dac22e69a20fdde0a50e15fb5eebb059a0df37175e5b85621-2.json`
- `f48-owner-saves/character-626300bee616b52bfa1d40ab32fb776a/owner-aa5f66bf60f75b5103863d0a4688b0ca48cd1197410e325bc23f58d0466d697a-1.json`
- `f48-owner-saves/character-a79c7bee9128c2ef03d266ce0352c666/owner-1bc064bbc0c6202858a43222f234830c70c0335a2fb06433a126431e2bc0d425-3.json`
- `f48-owner-saves/character-a79c7bee9128c2ef03d266ce0352c666/owner-1bc064bbc0c6202858a43222f234830c70c0335a2fb06433a126431e2bc0d425-4.json`
- `f48-owner-saves/character-a79c7bee9128c2ef03d266ce0352c666/owner-6ffcdc924fa78bf1c0fcf1962a84a0003bd27962f44632b4a5cfb84950776132-2.json`
- `f48-owner-saves/character-a79c7bee9128c2ef03d266ce0352c666/owner-da44f1f6e61caf94483e48abf5bab1692b54703eedc0439d3d7679f17741a2ab-1.json`
- `f48-passive/actual-2269.jsonl`
- `f48-passive/actual-2270.jsonl`
- `f48-witnesses/character-626300bee616b52bfa1d40ab32fb776a/admitted.json`
- `f48-witnesses/character-626300bee616b52bfa1d40ab32fb776a/initial-bootstrap.json`
- `f48-witnesses/character-a79c7bee9128c2ef03d266ce0352c666/admitted.json`
- `f48-witnesses/character-a79c7bee9128c2ef03d266ce0352c666/initial-bootstrap.json`
- `peer-0/actual-paid-altar/characters/redesign-v28/character-626300bee616b52bfa1d40ab32fb776a/character.json`
- `peer-0/actual-paid-altar/saves/redesign-v28/slot_0.json`
- `peer-0/actual-paid-altar/worlds/redesign-v28/slot-0/world.json`
- `peer-1/actual-paid-altar/characters/redesign-v28/character-a79c7bee9128c2ef03d266ce0352c666/character.json`
