# Net smoke run net-20261003T125909Z-2519

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2544 exited=false unexpected_exit=false
- peer 1 (client) pid=2545 exited=true unexpected_exit=false

FAILURES:
- the host's ONE record holds 2 participants (got 1)
- the join re-derived the record's scaling row to the two-player one (1.0000, configured 1.1000)
- the two of them put his first creature down and he sent out his second (no verdict)
