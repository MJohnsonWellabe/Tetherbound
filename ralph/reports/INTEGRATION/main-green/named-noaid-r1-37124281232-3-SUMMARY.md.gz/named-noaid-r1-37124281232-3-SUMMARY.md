# Net smoke run net-20261003T131005Z-3532

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=3557 exited=true unexpected_exit=false
- peer 1 (client) pid=3558 exited=true unexpected_exit=false

FAILURES:
- the host's record now holds 2 participants (got 1)
- peer 0 beat Bryn's whole team (the battle never resolved in 2164 frames (12 swings, 1 of their creatures met, 1 still queued); enemy=bramblebun hp=0.000/100.700 quick_ready=false fighting=true active_hp=120.105 fainted=false refusal={  } bound=1:1)
