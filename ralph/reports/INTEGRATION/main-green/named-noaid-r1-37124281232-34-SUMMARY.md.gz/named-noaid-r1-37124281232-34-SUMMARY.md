# Net smoke run net-20261003T130222Z-2824

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2849 exited=false unexpected_exit=false
- peer 1 (client) pid=2850 exited=true unexpected_exit=false

FAILURES:
- both peers felled the Warden (no verdict)
