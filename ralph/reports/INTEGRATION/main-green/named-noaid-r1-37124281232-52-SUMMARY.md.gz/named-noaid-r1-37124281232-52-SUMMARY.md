# Net smoke run net-20261003T130612Z-3151

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=3176 exited=false unexpected_exit=false
- peer 1 (client) pid=3177 exited=true unexpected_exit=false

FAILURES:
- both peers felled the Warden (no verdict)
