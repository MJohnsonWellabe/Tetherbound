# Net smoke run net-20261003T141655Z-2270

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2294 exited=true unexpected_exit=false
- peer 1 (client) pid=2295 exited=true unexpected_exit=false

FAILURES:
- client entered Stormwood
