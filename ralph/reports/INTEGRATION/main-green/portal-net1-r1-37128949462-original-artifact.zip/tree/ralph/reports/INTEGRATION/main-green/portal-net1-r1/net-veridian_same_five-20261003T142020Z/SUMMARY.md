# Net smoke run net-20261003T142020Z-2569

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2593 exited=true unexpected_exit=false
- peer 1 (client) pid=2594 exited=true unexpected_exit=false

FAILURES:
- peer 0 stands in the Meadows before portal entry ('')
- peer 0 completed actual Hall portal owner-save/permit/grounded arrival (Game.enter_realm('cloudreach') refused from 'meadows' (can_enter=true); The arrival anchor is obstructed.)
