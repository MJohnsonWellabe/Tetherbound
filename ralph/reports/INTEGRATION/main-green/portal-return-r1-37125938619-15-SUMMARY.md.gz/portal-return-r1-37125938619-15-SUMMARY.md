# Net smoke run net-20261003T132514Z-2615

Scene: water
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2639 exited=true unexpected_exit=false
- peer 1 (client) pid=2640 exited=true unexpected_exit=true

FATAL: ERROR: peer exited (peer 1, pid 2640)
