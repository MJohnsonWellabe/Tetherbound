# Net smoke run net-20261003T125945Z-2473

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2499 exited=true unexpected_exit=false
- peer 1 (client) pid=2500 exited=true unexpected_exit=false

FAILURES:
- the guest followed the host into Cloudreach (Game.enter_realm('cloudreach') refused from 'meadows' (can_enter=true); Your authoritative travel state is not ready.)
