# Net smoke run net-20261003T130915Z-3388

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=3413 exited=true unexpected_exit=false
- peer 1 (client) pid=3414 exited=true unexpected_exit=false

FAILURES:
- peer 1 enter_realm: Game.enter_realm('stormwood') refused from 'meadows' (can_enter=true); Actual correlated saved/arrived completion missing within original budget
