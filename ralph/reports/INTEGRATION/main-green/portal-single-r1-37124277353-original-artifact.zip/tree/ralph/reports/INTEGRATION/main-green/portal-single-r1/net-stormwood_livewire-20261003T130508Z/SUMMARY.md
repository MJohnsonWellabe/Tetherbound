# Net smoke run net-20261003T130508Z-2976

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=3001 exited=true unexpected_exit=false
- peer 1 (client) pid=3002 exited=true unexpected_exit=false

FAILURES:
- client entered Stormwood
