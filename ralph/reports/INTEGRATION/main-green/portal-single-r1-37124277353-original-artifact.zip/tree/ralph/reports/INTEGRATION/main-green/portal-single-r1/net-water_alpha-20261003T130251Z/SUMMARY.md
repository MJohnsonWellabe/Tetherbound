# Net smoke run net-20261003T130251Z-2769

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2795 exited=true unexpected_exit=false
- peer 1 (client) pid=2796 exited=true unexpected_exit=false

FAILURES:
- Client enters Water through Game.enter_realm
