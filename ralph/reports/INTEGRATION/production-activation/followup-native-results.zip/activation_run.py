import datetime, hashlib, json, os, pathlib, re, subprocess, sys, time

root = pathlib.Path(__file__).resolve().parents[1]
out = root / '.tmp' / 'activation' / sys.argv[1]
out.mkdir(parents=True, exist_ok=False)
timeout = int(sys.argv[2])
engine = pathlib.Path('C:/Users/mattj/.cache/tetherbound-tools/godot-4.7/Godot_v4.7-stable_win64_console.exe')
command = [str(engine), '--headless', '--path', str(root), *sys.argv[3:]]
lease = pathlib.Path('D:/tetherbound/RENDER_LOCK.json')
owner = '01a0fb61-4561-7643-812d-d525e93112b9'
held = json.loads(lease.read_text(encoding='utf-8-sig'))
if held.get('held_by'):
    raise SystemExit('Engine lease already held')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
paths = subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'scripts', 'data', 'tests', 'scenes', 'project.godot'], cwd=root).decode().split('\0')
paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z', 'autoload', 'scripts', 'data', 'tests', 'scenes'], cwd=root).decode().split('\0')
paths = [p for p in paths if p and pathlib.Path(p).suffix in {'.gd', '.json', '.tscn', '.tres', '.godot'}]
def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths if (root / p).is_file()}
before = hashes()
receipt = {'head': head, 'command': command, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_before': before}
env = os.environ.copy()
env.update(APPDATA=str(out / 'user'), LOCALAPPDATA=str(out / 'local-user'))
lease.write_text(json.dumps({'held_by': owner, 'operation': sys.argv[1], 'since_utc': receipt['started_utc']}))
try:
    started = time.monotonic()
    with (out / 'engine.log').open('wb') as log:
        proc = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        receipt['pid'] = proc.pid
        print(json.dumps({'pid': proc.pid, 'log': str(out / 'engine.log')}), flush=True)
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            receipt['timed_out'] = True
            subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
            proc.wait(timeout=30)
    raw = (out / 'engine.log').read_bytes()
    lines = raw.decode('utf-8', errors='replace').splitlines()
    errors = [s for s in lines if re.search(r'SCRIPT ERROR|Parse Error|^ERROR:|Failed to load|ObjectDB instances leaked|resources still in use', s, re.I)]
    after = hashes()
    receipt.update(exit=proc.returncode, elapsed_seconds=time.monotonic()-started, errors=errors,
                   source_unchanged=before == after, changed_during_run=[p for p in set(before) | set(after) if before.get(p) != after.get(p)],
                   log_sha256=hashlib.sha256(raw).hexdigest(), source_after=after)
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps({k: receipt[k] for k in ['head','exit','elapsed_seconds','source_unchanged','changed_during_run','errors']}), flush=True)
    print('\n'.join(lines[-25:]), flush=True)
finally:
    if json.loads(lease.read_text()).get('held_by') == owner:
        lease.write_text('{}\n')
raise SystemExit(1 if receipt.get('timed_out') or receipt.get('exit') or receipt.get('errors') else 0)
