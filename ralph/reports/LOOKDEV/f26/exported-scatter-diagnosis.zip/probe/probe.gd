extends SceneTree
const SCATTER := preload("res://scripts/world/stormwood_scatter.gd")
const BAKE := preload("res://scripts/world/scatter_bake.gd")
func _initialize() -> void:
	var output := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output="):
			output = argument.trim_prefix("--output=")
	var manifest: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/scatter/stormwood/manifest.json"))
	var sources: Array[Dictionary] = []
	for path: String in SCATTER.SOURCES:
		sources.append({"path": path, "exists": FileAccess.file_exists(path), "text_length": FileAccess.get_file_as_string(path).length()})
	var missing: Array[String] = []
	for pair: Array in manifest.get("regions", []):
		var path := "res://data/scatter/stormwood/region_%d_%d.bin" % [int(pair[0]), int(pair[1])]
		if not FileAccess.file_exists(path):
			missing.append(path)
	var fingerprint := SCATTER.fingerprint()
	var fresh := BAKE.is_fresh("stormwood", int(SCATTER.config().seed), fingerprint)
	var result := {"fingerprint": fingerprint, "manifest_fingerprint": manifest.get("config_fingerprint", 0),
		"fresh": fresh, "sources": sources, "manifest_regions": manifest.get("regions", []).size(), "missing_regions": missing}
	var file := FileAccess.open(output, FileAccess.WRITE)
	if file == null:
		quit(3)
		return
	file.store_string(JSON.stringify(result, "\t") + "\n")
	file.close()
	print("STORMWOOD PACK FRESHNESS: ", fresh, "; missing regions=", missing.size())
	quit(0 if fresh else 1)
