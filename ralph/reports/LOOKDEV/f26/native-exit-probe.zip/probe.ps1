param([string]$ProbeRoot)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1')
$package = 'D:/tetherbound/.artifacts/f26-ally-a799297b2-20261004T225752Z/package'
$rows = @()
foreach ($cacheHandle in @($false,$true)) {
  $name = if ($cacheHandle) { 'cached-handle' } else { 'original-handle' }
  $arguments = '--headless -- --f26-route --biome=meadows --preset=Medium --source-commit=a799297b21001c84bef6f941230b24297dace6bc --output=' + $ProbeRoot.Replace([char]92,[char]47) + '/' + $name
  $process = Start-Process -FilePath (Join-Path $package 'Tetherbound.exe') -WorkingDirectory $package -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $ProbeRoot ($name+'.stdout.log')) -RedirectStandardError (Join-Path $ProbeRoot ($name+'.stderr.log'))
  if ($cacheHandle) { $savedHandle = $process.Handle }
  if (-not $process.WaitForExit(60000)) { & taskkill.exe /PID $process.Id /T /F | Out-Null; throw 'Probe timeout' }
  $before = $process.ExitCode
  $process.Refresh()
  $after = $process.ExitCode
  $rows += @{case=$name; pid=$process.Id; before_refresh=$before; after_refresh=$after; expected=2; cached_handle=$cacheHandle}
}
$rows | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $ProbeRoot 'exit-codes.json') -Encoding UTF8
$rows | ConvertTo-Json -Depth 8
