# Net smoke run f26-perf-flag-bd761aaa-20261005

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=4620 exited=true unexpected_exit=false
- peer 1 (client) pid=12136 exited=true unexpected_exit=false

ALL CHECKS PASSED
