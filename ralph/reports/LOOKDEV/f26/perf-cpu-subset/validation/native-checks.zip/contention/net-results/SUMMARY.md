# Net smoke run f26-perf-cpu-29237b-20261005

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=12732 exited=true unexpected_exit=false
- peer 1 (client) pid=11292 exited=true unexpected_exit=false

ALL CHECKS PASSED
