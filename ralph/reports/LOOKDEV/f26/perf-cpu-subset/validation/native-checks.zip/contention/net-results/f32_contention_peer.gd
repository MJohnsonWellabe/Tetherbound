extends "res://tools/net/peer_runner.gd"

const F32_SITES := preload("res://scripts/world/renewable_site_catalog.gd")
var _f32_node: Node3D
var _f32_site := ""
var _f32_realm := ""
var _f32_press := ""
var _f32_settled: Array = []
var _f32_connected := false

func _execute_step(msg: Dictionary) -> Dictionary:
	var action := str(msg.get("action", ""))
	var args: Dictionary = (msg.get("args", {}) as Dictionary)
	if action == "f32_stand":
		return await _f32_stand(args)
	if action == "f32_diag_portal_flag":
		# DIAGNOSTIC FIXTURE ONLY (TB_F32_DIAG_PORTAL_FLAG=1): flips the host's
		# in-memory session config so `_rpc_travel_lifecycle` stops dropping
		# guest samples. Never acceptance evidence; the shipped flag is false.
		var session: Node = root.get_node(^"Game").get("session")
		(session.get("_config") as Dictionary)["redesign_portal_runtime_enabled"] = true
		return {"verdict": "PASS", "detail": "DIAGNOSTIC: host in-memory redesign_portal_runtime_enabled=true (portal_runtime_ready=%s)" % str(session.call("portal_runtime_ready"))}
	if action == "f32_portal_refused":
		# Accepting guest travel samples must not open portals: with the shipped
		# flag off, the Home Key and every portal action still refuse.
		var session: Node = root.get_node(^"Game").get("session")
		var ready: bool = session.call("portal_runtime_ready") == true
		var key := str(session.call("home_key_refusal"))
		var action_reply: Dictionary = session.call("request_portal_action", {"kind": "home_key_finish"})
		var ok: bool = not ready and key == "The Home Key is not ready yet." and action_reply.get("ok") != true
		return {"verdict": "PASS" if ok else "FAIL",
			"detail": "portal_runtime_ready=%s home_key='%s' portal_action=%s" % [str(ready), key, str(action_reply)]}
	if action == "f32_press":
		var at := float(args.get("at_unix_ms", 0.0))
		if at > 0.0:
			_f32_press_at.call_deferred(at)
			return {"verdict": "PASS", "detail": "armed press for %.0f" % at}
		return _f32_press_now()
	return await super._execute_step(msg)

func _execute_probe(msg: Dictionary) -> Variant:
	if str(msg.get("what", "")) == "f32_node":
		return _f32_probe((msg.get("args", {}) as Dictionary))
	if str(msg.get("what", "")) == "f32_diag":
		return _f32_diag()
	return await super._execute_probe(msg)

func _f32_resources() -> Node:
	var game := root.get_node_or_null(^"Game")
	if game == null or game.get("session") == null: return null
	return (game.get("session") as Node).get_node_or_null(^"FoundationComposition/Resources")

func _f32_stand(args: Dictionary) -> Dictionary:
	_f32_site = str(args.get("site", ""))
	_f32_node = null
	_f32_press = ""
	_f32_settled = []
	_f32_realm = str(args.get("realm", "meadows"))
	var spec := F32_SITES.by_id(_f32_realm, _f32_site)
	var player := _probe.call("player") as CharacterBody3D
	var world := current_scene
	var resources := _f32_resources()
	if spec.is_empty() or player == null or world == null or resources == null or not world.has_method("ground_height_at"):
		return {"verdict": "ERROR", "detail": "site/player/world/Resources missing (spec %s)" % str(not spec.is_empty())}
	if not _f32_connected:
		resources.get_node(^"SourceService").connect("settled", func(op: String, id: String, action_id: String, verdict: Dictionary) -> void:
			if op == "node" and id == _f32_site:
				_f32_settled.append({"action_id": action_id, "verdict": verdict.duplicate(true), "unix_ms": Time.get_unix_time_from_system() * 1000.0}))
		_f32_connected = true
	var at := Vector2(float(spec.at[0]), float(spec.at[1]))
	var offset: Array = args.get("offset", [0.0, 6.0]) as Array
	var approach: Array = args.get("approach", [1.3, 0.0]) as Array
	# Mount from the disclosed 6 m start, like the native material smoke.
	for target: Vector2 in [at + Vector2(float(offset[0]), float(offset[1])), at + Vector2(float(approach[0]), float(approach[1]))]:
		var ground := float(world.call("ground_height_at", target.x, target.y))
		REMOTE_CREATURE_TP.teleport_body(player as PhysicsBody3D, Vector3(target.x, ground + 0.3, target.y))
		player.velocity = Vector3.ZERO
		for i in 45: await physics_frame
		if _f32_node == null:
			(resources.get("_mount_retry") as Dictionary).erase(_f32_realm)
			resources.call("_mount_realm", _f32_realm, player)
			_f32_node = resources.call("_source", _f32_realm, _f32_site)
	if _f32_node == null:
		var mount: Node = null
		for child: Node in world.find_children("RenewableResources", "", true, false): mount = child
		var why: Variant = mount.call("census").get("refusals", {}).get(_f32_site, "no mount") if mount != null else "no RenewableResources mount"
		return {"verdict": "FAIL", "detail": "site %s not mounted: %s" % [_f32_site, str(why)]}
	for i in 60: await physics_frame
	var d := player.global_position.distance_to(_f32_node.global_position)
	return {"verdict": "PASS" if d <= 2.4 else "FAIL",
		"detail": "mounted %s; trainer %.2f m from node at %s" % [_f32_site, d, str(_f32_node.global_position)]}

## Host-side admission inputs for every remote peer, and this peer's own
## registry view. Read-only: `host_context` stages nothing.
func _f32_diag() -> Dictionary:
	var game := root.get_node_or_null(^"Game")
	var resources := _f32_resources()
	if game == null or resources == null: return {}
	var session: Node = game.get("session")
	var view: Dictionary = session.call("homestead_personal_view")
	var out := {"local_peer": int(session.call("local_peer_id")), "view_registry_revision": view.get("registry_revision"),
		"view_character": view.get("character_id"), "peers": []}
	var lifecycle0: Node = resources.get_parent().get_node(^"TravelLifecycle")
	out.local_sample_empty = (lifecycle0.call("local_sample") as Dictionary).is_empty()
	out.portal_runtime_ready = session.call("portal_runtime_ready")
	if not bool(session.call("is_host")):
		var sample: Dictionary = lifecycle0.call("local_sample")
		sample.sequence = 1
		out.sample_valid = preload("res://scripts/net/foundation_travel_lifecycle.gd").valid_sample(sample)
		var types := {}
		for field: Variant in sample: types[str(field)] = type_string(typeof(sample[field]))
		out.sample_types = types
		out.snapshot_ready = session.call("snapshot_ready")
		out.is_active = session.call("is_active")
		return out
	var key := "resource:%s:%s" % [_f32_realm, _f32_site]
	var intent := {"operation": "node", "request": {"site_id": _f32_site, "expected_stock_revision": 0, "action_id": "0123456789abcdef0123456789abcdef"}}
	var lifecycle: Node = resources.get_parent().get_node(^"TravelLifecycle")
	var registry: RefCounted = session.get("_registry")
	for row: Dictionary in registry.call("rows"):
		var peer := int(row.get("peer_id", 0))
		var actor: CharacterBody3D = resources.call("_body", peer)
		var source: Node3D = resources.call("_source", _f32_realm, _f32_site)
		var character := str(session.call("_authority_character", peer))
		var authority: RefCounted = session.get("_character_authority")
		var safety: Dictionary = lifecycle.call("local_sample") if peer == int(session.call("local_peer_id")) else lifecycle.call("host_context", peer)
		var context: Dictionary = resources.call("host_context", peer, key, intent)
		out.peers.append({"peer": peer, "character": character, "authority_revision": int(authority.call("revision", character)) if authority != null else -1,
			"actor": actor != null, "actor_pos": str(actor.global_position) if actor != null else "",
			"distance": actor.global_position.distance_to(source.global_position) if actor != null and source != null else -1.0,
			"safety": safety, "in_combat": session.call("_altar_peer_in_combat", peer),
			"admitted": not (session.call("admitted_character_state", peer) as Dictionary).is_empty(),
			"context_empty": context.is_empty(), "context_expected_revision": context.get("expected_revision"),
			"lifecycle": _f32_lifecycle_diag(lifecycle, session, game, peer)})
	return out

func _f32_lifecycle_diag(lifecycle: Node, session: Node, game: Node, peer: int) -> Dictionary:
	if peer == int(session.call("local_peer_id")): return {}
	var observation: Dictionary = (lifecycle.get("_observations") as Dictionary).get(peer, {})
	var out := {"observation": not observation.is_empty()}
	if observation.is_empty(): return out
	var sample: Dictionary = observation.sample
	out.age_ms = Time.get_ticks_msec() - int(observation.seen_at)
	out.character_ok = sample.character_id == session.call("_authority_character", peer)
	out.epoch_ok = sample.session_epoch == session.call("_altar_current_epoch")
	out.world_ok = sample.world_instance_id == game.get("world").reward_delivery_namespace
	var actor: Node = lifecycle.call("remote_body", peer)
	out.actor = actor != null
	if actor != null:
		out.net_realm = str(actor.get("net_realm"))
		out.sample_realm = str(sample.realm)
		out.physics = actor.is_physics_processing()
		out.aquatic = actor.get("aquatic") != null
	out.personal = not (session.get("_character_authority").call("state", sample.character_id) as Dictionary).is_empty()
	var halls := 0
	for hall: Node in get_nodes_in_group("crossing_halls"): halls += 1
	out.crossing_halls = halls
	return out

func _f32_press_at(at_unix_ms: float) -> void:
	while Time.get_unix_time_from_system() * 1000.0 < at_unix_ms:
		await physics_frame
	_f32_press_now()

func _f32_press_now() -> Dictionary:
	var game := root.get_node_or_null(^"Game")
	if game == null or _f32_node == null or not is_instance_valid(_f32_node):
		_f32_press = "no_node"
		return {"verdict": "ERROR", "detail": "no mounted node"}
	if not bool(_f32_node.call("_renewable_ready", game)):
		# The node's own gate refuses a depleted source before any request.
		_f32_press = "not_ready"
	else:
		_f32_press = "submitted"
	var prompt := _f32_node.get_node_or_null(^"Interactable")
	if prompt == null:
		return {"verdict": "ERROR", "detail": "node has no Interactable"}
	prompt.emit_signal("activated")
	return {"verdict": "PASS", "detail": "pressed (%s)" % _f32_press}

func _f32_counts(slots: Variant, items: Array) -> Dictionary:
	var out := {}
	for item: Variant in items: out[str(item)] = 0
	if slots is Array:
		for slot: Variant in slots:
			if slot is Dictionary and out.has(str(slot.get("id", ""))):
				out[str(slot.id)] += int(slot.get("n", 0))
	return out

func _f32_probe(args: Dictionary) -> Dictionary:
	var game := root.get_node_or_null(^"Game")
	if game == null: return {}
	var items: Array = args.get("items", []) as Array
	var session: Node = game.get("session")
	var world: RefCounted = game.get("world")
	var local: RefCounted = game.get("local")
	var character := str(local.get("character_id"))
	var inv: RefCounted = game.get("inventory")
	var counts := {}
	for item: Variant in items: counts[str(item)] = int(inv.call("count", str(item)))
	var receipts: Array = []
	for r: Variant in (local.get("redesign_character") as Dictionary).get("transaction_receipts", []):
		if str(r).contains(":f32:"): receipts.append(str(r))
	var rows: Array = []
	for value: Variant in (world.get("reward_deliveries") as Dictionary).values():
		if value is Dictionary and value.get("action") == "resource" \
			and (value.get("intent", {}) as Dictionary).get("request", {}).get("site_id") == _f32_site:
			rows.append({"status": value.get("status"), "character_id": value.get("character_id"),
				"receipt": value.get("receipt"), "action_id": value.intent.request.get("action_id")})
	var saver: RefCounted = game.get("save_system")
	var disk_character: Dictionary = {}
	var disk_world_stock: Variant = null
	var disk_world_rows := 0
	if saver != null:
		saver.call("finish_fallback")
		var saved: Dictionary = (saver.call("characters") as RefCounted).call("read", character)
		var disk_receipts: Array = []
		for r: Variant in (saved.get("redesign_character", {}) as Dictionary).get("transaction_receipts", []):
			if str(r).contains(":f32:"): disk_receipts.append(str(r))
		disk_character = {"present": not saved.is_empty(), "counts": _f32_counts(saved.get("inventory", []), items), "receipts": disk_receipts}
		if bool(session.call("is_host")):
			var wsaved: Dictionary = (saver.call("worlds") as RefCounted).call("read", str(world.get("world_id")))
			disk_world_stock = (wsaved.get("redesign_world", {}) as Dictionary).get("node_cycles", {}).get("sites", {}).get(_f32_realm + ":" + _f32_site, null)
			for value: Variant in (wsaved.get("reward_deliveries", {}) as Dictionary).values():
				if value is Dictionary and value.get("action") == "resource" \
					and (value.get("intent", {}) as Dictionary).get("request", {}).get("site_id") == _f32_site: disk_world_rows += 1
	var resources := _f32_resources()
	return {"character_id": character, "is_host": bool(session.call("is_host")), "day": int(game.get("day")),
		"stock": resources.call("stock", _f32_realm, _f32_site) if resources != null else {},
		"node": _f32_node != null and is_instance_valid(_f32_node),
		"ready": bool(_f32_node.call("_renewable_ready", game)) if _f32_node != null and is_instance_valid(_f32_node) else null,
		"claiming": bool(_f32_node.get("_claiming")) if _f32_node != null and is_instance_valid(_f32_node) else null,
		"pending": (resources.get("_pending") as Dictionary).size() if resources != null else -1,
		"press": _f32_press, "settled": _f32_settled.duplicate(true), "counts": counts, "receipts": receipts,
		"rows": rows, "disk_character": disk_character, "disk_world_stock": disk_world_stock, "disk_world_rows": disk_world_rows}
