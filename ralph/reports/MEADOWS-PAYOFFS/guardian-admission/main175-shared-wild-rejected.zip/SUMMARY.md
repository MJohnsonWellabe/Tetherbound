# Net smoke run net-20260921T111003Z-3065

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=3086 exited=true unexpected_exit=false
- peer 1 (client) pid=3087 exited=true unexpected_exit=false

FAILURES:
- host refused a fresh rapid intent against its own deadline
- host accepted the fresh monotonic action
- host retained its resolved charged-move lock instead of the forged zero cooldown
- refused replay/rapid intents changed neither accepted action nor deadline
