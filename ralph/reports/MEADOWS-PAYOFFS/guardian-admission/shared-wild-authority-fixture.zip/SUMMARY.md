# Net smoke run wild-authority-fixed-01

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=12804 exited=true unexpected_exit=false
- peer 1 (client) pid=16692 exited=true unexpected_exit=false

ALL CHECKS PASSED
