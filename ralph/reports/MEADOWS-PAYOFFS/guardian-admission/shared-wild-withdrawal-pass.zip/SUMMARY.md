# Net smoke run wild-withdrawal-fixed-01

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=9924 exited=true unexpected_exit=false
- peer 1 (client) pid=16676 exited=true unexpected_exit=false

ALL CHECKS PASSED
