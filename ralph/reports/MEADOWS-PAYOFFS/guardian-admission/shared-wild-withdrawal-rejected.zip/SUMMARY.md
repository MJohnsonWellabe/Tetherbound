# Net smoke run net-20260921T121916Z-2765

Scene: world
Peers: 2
Net conditions: clean (no proxy)

- peer 0 (host) pid=2786 exited=true unexpected_exit=false
- peer 1 (client) pid=2787 exited=true unexpected_exit=false

FAILURES:
- A's last-participant withdrawal removed its host runtime
